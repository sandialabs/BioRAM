# Java BioRAM

## Building

The source to the Java BioRAM is in `./src/main/java`. It uses Apache Maven as 
its build system, which Eclipse or NetBeans can import (possibly requiring 
plugins). Note that the GUI forms use NetBeans' visual form builder (these are 
of extension `*.form` in `gov.sandia.bioram.forms`).

## File format

BioRAM (the Java version) uses a file format inspired by compressed archives 
like those of MS Office (docx, xlsx, etc). All `*.raml` files are zip files 
containing a file `model.xml` with the profile and a `media/` directory storing 
images (like the plot backgrounds and the front page logo). The schema for 
`model.xml` is stored in `src/main/xsd/dataModel.xsd` (with documentation 
built-in). Both profile and response files use the same XML schema (in fact, a 
profile can contain responses to allow, for example, a list of built-in 
chemical specifications). Though the files can be the same, the software will 
only load responses from the file if "Load Responses" is selected instead of 
"Load Profile", in which case the profile will also be loaded. A common source 
of confusion in this scheme occurs if a response file is saved over a profile 
(since they are so similar) --- the saved file then only contains responses, so 
upon attempting to load the profile on subsequent loads, an error is 
encountered. The problem is that "Save Responses" only saves responses, not the 
profile information. In retrospect, a different file type should have been 
specified for responses to prevent situations like this from occurring, but as 
it stands, user discipline will have to separate responses from profiles.

The .NET version of BioRAM's file format is a text file containing profile 
information in a fixed format. Responses are a different file type and cannot 
be included in profiles. The schema of both file types can be found by 
inspecting its commented source code in `Utility.cs`.

## Translations

The `util` directory contains some tools written in support of BioRAM, mainly 
for automating translations. Unfortunately, as the translated questionnaires 
typically are in MS Word format, a very non-semantic means of storing data, no 
one-size-fits-all solution could be created, as each translated data source (MS 
Word file) had its own unique quirks in its internal format. Even if each file 
did have the same format, without any identifying information for which 
questions are which, the approach taken was to assume the questions are in 
identical order as the original model (true in all cases encountered, since the 
same MS Word original was used as a template for translators) and match them 
blindly according to this assumption. Nevertheless, the converting code in 
`util/translatedQuestionMover` provides a strong starting point, in practice 
likely only requiring slight modification (if any) to convert a new 
translation. This requires the document first be saved as an HTML file inside 
MS Word (HTML is easier to manipulate than MS Word's somewhat opaque file 
format and still quite structured).
