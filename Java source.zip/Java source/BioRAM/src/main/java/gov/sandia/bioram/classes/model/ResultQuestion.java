/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gov.sandia.bioram.classes.model;

import java.text.NumberFormat;
import gov.sandia.bioram.xml.ObjectFactory;

/**
 *
 * @author danbowe
 */
public class ResultQuestion extends ResultObject {
  QuestionSetQuestion referenceQuestion;

  /**
   * Used in question set creation, where we want to use the raw weight of
   * the referenced category
   * @param referenceQuestion
   */
  public ResultQuestion(QuestionSetQuestion referenceQuestion) {
    this(referenceQuestion.getDefaultWeight(), referenceQuestion);
  }

  /**
   * Used for deserialization, where we may already know the raw weight
   * @param rawWeight
   * @param referenceQuestion
   */
  public ResultQuestion(Double rawWeight, QuestionSetQuestion referenceQuestion) {
    super(rawWeight, true);
    this.referenceQuestion = referenceQuestion;
  }

  public QuestionSetQuestion getReferenceQuestion() {
    return this.referenceQuestion;
  }

  @Override
  public double getScore() {
    return (this.referenceQuestion.getScore() * this.getWeight());
  }

  @Override
  public String toString() {
    String weightStr = NumberFormat.getInstance().format(this.getWeight());
    return "<html><font color=\"rgb(" +
            this.getColor().getRed() + "," + this.getColor().getGreen() + "," + this.getColor().getBlue() +
            ")\">[" + weightStr + "] " + this.referenceQuestion.getUserObject().toString() + "</font></html>";
  }

  @Override
  public void toJAXB(gov.sandia.bioram.xml.ResultMathOpExponent.Children children) {
    ObjectFactory of = new ObjectFactory();
    gov.sandia.bioram.xml.ResultQuestion rq = of.createResultQuestion();
    rq.setQuestionUUID(this.referenceQuestion.getUUID().toString());
    rq.setRawWeight(this.getRawWeight());

    children.getResultMathOpAddOrResultMathOpSubtractOrResultMathOpMultiply().add(rq);
  }
}
