/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gov.sandia.bioram.classes.model;

import gov.sandia.bioram.xml.ObjectFactory;

/**
 *
 * @author danbowe
 */
public class ResultMathOpMin extends ResultMathOp {
  public ResultMathOpMin(double rawWeight, String title, boolean normalizeChildren) {
    super(rawWeight, title, normalizeChildren);
    this.mathOpTypeKey = "Minimum";
  }

  @Override
  public double getScore() {
    double tempScore = 0;
    if (this.getChildCount() > 0) {
      tempScore = ((ResultObject)this.getChildAt(0)).getScore();
      for (int i = 0; i < this.getChildCount(); i++) {
        tempScore = Math.min(tempScore, ((ResultObject)this.getChildAt(i)).getScore());
      }
    }
    return (tempScore * this.getWeight());
  }

  @Override
  public void toJAXB(gov.sandia.bioram.xml.ResultMathOpExponent.Children children) {
    ObjectFactory of = new ObjectFactory();
    gov.sandia.bioram.xml.ResultMathOpMin rmom = of.createResultMathOpMin();
    rmom.setTitle(this.getTitle());
    rmom.setRawWeight(this.getRawWeight());
    rmom.setNormalizeChildren(this.getNormalizeChildren());
    rmom.setChildren(of.createResultMathOpExponentChildren());

    children.getResultMathOpAddOrResultMathOpSubtractOrResultMathOpMultiply().add(rmom);

    for (int i = 0; i < this.getChildCount(); i++) {
      ResultObject ro = (ResultObject)this.getChildAt(i);

      ro.toJAXB(rmom.getChildren());
    }
  }
}
