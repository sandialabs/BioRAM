/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gov.sandia.bioram.classes.model.charts;

import gov.sandia.bioram.classes.model.QuestionSetModule;
import gov.sandia.bioram.classes.model.RamModel;
import gov.sandia.bioram.classes.model.ResultProfile;
import gov.sandia.bioram.classes.model.randomclasses.BackgroundGraphTable.ResponseHashMapTableCellRenderer;
import gov.sandia.bioram.classes.model.randomclasses.RamFileMarshal;
import gov.sandia.bioram.classes.model.randomclasses.RamDataTable;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;
import java.text.NumberFormat;
import java.util.List;
import java.util.ResourceBundle;
import java.util.UUID;
import javax.imageio.ImageIO;
import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import org.apache.commons.lang.StringEscapeUtils;
import org.jfree.chart.ChartPanel;
import gov.sandia.bioram.xml.ObjectFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.labels.StandardXYItemLabelGenerator;
import org.jfree.chart.labels.StandardXYToolTipGenerator;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYDataItem;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import gov.sandia.bioram.xml.RamModel.Chart;
import gov.sandia.bioram.xml.RamModel.Chart.DataPoint;

/**
 * Might not use this...
 * @author danbowe
 */
public class RamChart extends JFreeChart {
  private static class CustomTooltipText extends StandardXYToolTipGenerator {
    @Override
    public String generateToolTip(XYDataset dataset, int series, int item) {
      XYSeriesCollection seriesCol = (XYSeriesCollection)dataset;

      XYDataItem dataItem = seriesCol.getSeries(series).getDataItem(item);
      if (dataItem instanceof ChartDataItem) {
        return ((ChartDataItem)dataItem).getToolTipText();
      } else {
        return super.generateLabelString(dataset, series, item);
      }
    }
  }

  /**
   * Used in report creation to put numbers on each data item.  This class
   * is only instantiated from ReportGenerator as of its creation.
   */
  public static class NumberedXYItemLabelGenerator extends StandardXYItemLabelGenerator {

    /**
     * Create labels that show up as the item index (1-based)
     */
    @Override
    public String generateLabel(XYDataset dataset, int series, int item) {
      return Integer.toString(item + 1);
    }
  }

  public RamChart() {
    super(new XYPlot(
            new XYSeriesCollection(),
            new NumberAxis(),
            new NumberAxis(),
            new XYLineAndShapeRenderer(false, true)));
    this.setTitle("");
    this.getXYPlot().setDomainGridlinesVisible(false);
    this.getXYPlot().setRangeGridlinesVisible(false);
    // this.getLegend().setVisible(true);
    this.getXYPlot().getRenderer().setBaseToolTipGenerator(new CustomTooltipText());
  }

  /**
   * Represents the constructor used to create a chart from a RAML file.  Note
   * there are other sections that need to be loaded before this will
   * load the charts (result profiles and images).
   * 
   * @param model a reference to the RamModel.  This is necessary to get the 
   * references to the ResultProfiles for the X and Y axes.  This also means
   * that if the model is being parsed in, the result profiles need to be
   * parsed in before the charts.
   * 
   * @param marshal This is an active context from where the ramMLChart came
   * from.  It's needed to load the background images.  Note this means the
   * context should've loaded the images from a saved file first.
   * 
   * @param ramMLChart the JAXB Chart object, where the data will be transferred
   * from to populate this chart.
   */
  public RamChart(RamModel model, RamFileMarshal marshal, Chart ramMLChart) {
    this(); // Call my designated initializer [constructor]

    this.setTitle(ramMLChart.getChartTitle());

    String bgPath = ramMLChart.getBackgroundImagePath();
    if (bgPath != null) {
      this.getXYPlot().setBackgroundImage(marshal.getImage(bgPath));
    }
    // X (min,max,title) Y (min,max,title)
    // DataPoint (legendTitle, XUUID, YUUID)

    // X Axis
    this.getXYPlot().getDomainAxis().setLabel(ramMLChart.getXAxis().getTitle());
    this.getXYPlot().getDomainAxis().setLowerBound(ramMLChart.getXAxis().getMin());
    this.getXYPlot().getDomainAxis().setUpperBound(ramMLChart.getXAxis().getMax());

    // Y Axis
    this.getXYPlot().getRangeAxis().setLabel(ramMLChart.getYAxis().getTitle());
    this.getXYPlot().getRangeAxis().setLowerBound(ramMLChart.getYAxis().getMin());
    this.getXYPlot().getRangeAxis().setUpperBound(ramMLChart.getYAxis().getMax());

    for (DataPoint dp : ramMLChart.getDataPoint()) {
      ResultProfile xRP = model.getRPByUUID(UUID.fromString(dp.getXResultProfileUUID()));
      ResultProfile yRP = model.getRPByUUID(UUID.fromString(dp.getYResultProfileUUID()));
      ChartDataSeries cds = new ChartDataSeries(xRP, yRP, dp.getLegendTitle());
      ((XYSeriesCollection) ((XYPlot)this.getPlot()).getDataset()).addSeries(cds);
    }
  }

  /**
   * Used to display the data series as a list in the ResponseForm, below the
   * chart.
   *
   * @return
   */
  public DefaultListModel getDataPointsAsListModel() {
      DefaultListModel dpList = new DefaultListModel();
      int numDataPoints = ((XYSeriesCollection)((XYPlot)this.getPlot()).getDataset()).getSeriesCount();
      for (int i = 0; i < numDataPoints; i++) {
        ChartDataSeries cdp = (ChartDataSeries)((XYSeriesCollection)((XYPlot)this.getPlot()).getDataset()).getSeries(i);
        dpList.addElement(cdp);

        // TODO: add legend items to the list
//        LegendItem li = ((XYLineAndShapeRenderer)((XYPlot)rc.getPlot()).getRenderer()).getLegendItem(0, i);
//
//        li.get
      }

      return dpList;
  }

  /**
   *
   * @param tableData the data to plot
   * @param selectedSeries which series should be plotted here?  If this is null,
   * all series are plotted
   */
  public void setDataPoints(RamDataTable tableData, List<ChartDataSeries> selectedSeries) {

    // for each data series (that is, XY pair of Result Profiles)
    for (Object obj : ((XYSeriesCollection) ((XYPlot) this.getPlot()).getDataset()).getSeries()) {
      ((XYSeries)obj).clear(); // reset the data series

      if ((obj instanceof ChartDataSeries) && (selectedSeries.contains((ChartDataSeries)obj) || selectedSeries == null)) {
        // for each row in the tableData (each combo of modules)
        for (int row = 0; row < tableData.getRowCount(); row++) {
          double x = 0, y = 0;
          ChartDataSeries series = (ChartDataSeries) obj;
          StringBuilder ttText = new StringBuilder("<html><b>" + series.getKey() + "</b><ul>"); // tool tip text
          StringBuilder legendHTML = new StringBuilder("");
          String ttX = ResourceBundle.getBundle("lang/FormStrings").getString("XAxis");
          String ttY = ResourceBundle.getBundle("lang/FormStrings").getString("YAxis");

          // Loop across the tableData and extract useful information, like tooltip information
          for (int col = 0; col < tableData.getColumnCount(); col++) {
            Object data = tableData.getValueAt(row, col);
            Object dataType = tableData.getObjectForColumn(col);

            if (dataType instanceof QuestionSetModule) {
              Color c = ResponseHashMapTableCellRenderer.getTextColor(data);
              String dataString = "<font color=\"rgb(" + c.getRed() + "," + c.getGreen() + "," + c.getBlue() + 
                      ")\">" + StringEscapeUtils.escapeXml(ResponseHashMapTableCellRenderer.getText(data)) + "</font>";
              ttText.append(("<li><b>" + dataType + ":</b> " + dataString + "</li>").toString());
              legendHTML.append(("<b>" + 
                      StringEscapeUtils.escapeXml(dataType.toString()) + ":</b> " +
                      StringEscapeUtils.escapeXml(ResponseHashMapTableCellRenderer.getText(data)) + "").toString());
            }
            if (dataType == series.getXRP()) {
              x = ((Double) data).doubleValue();
              String numStr = NumberFormat.getInstance().format(x);
              ttX = "<b>" + ttX + ":</b> " + dataType + " (" + numStr + ")";
            }
            if (dataType == series.getYRP()) {
              y = ((Double) tableData.getValueAt(row, col)).doubleValue();
              String numStr = NumberFormat.getInstance().format(y);
              ttY = "<b>" + ttY + ":</b> " + dataType + " (" + numStr + ")";
            }
          }
          ttText.append(("</ul>" + "<ul><li>" + ttX + "</li><li>"+ ttY + "</li></ul></html>").toString());
          series.add(new ChartDataItem(x, y, ttText.toString(), legendHTML.toString()));
        }
      }
    }
  }

  @Override
  public String toString() {
    return this.getTitle().getText();
  }

  /**
   * Note that one important detail that this method does not fill out is the
   * path to this chart's background image.  This is because that's the
   * marshaler's task (determining where images should be stored in the
   * ZIP file).  Note then, that the Marshaler should take the additional step
   * of saving the image and setting the backgroundImagePath property on this
   * JAXB Chart.
   *
   * @return a JAXB representation of this chart.
   */
  public gov.sandia.bioram.xml.RamModel.Chart toJAXB() {
    ObjectFactory of = new ObjectFactory();
    gov.sandia.bioram.xml.RamModel.Chart chart = of.createRamModelChart();

    gov.sandia.bioram.xml.RamModel.Chart.XAxis xAxis = of.createRamModelChartXAxis();
    xAxis.setMax(this.getXYPlot().getDomainAxis().getUpperBound());
    xAxis.setMin(this.getXYPlot().getDomainAxis().getLowerBound());
    xAxis.setTitle(this.getXYPlot().getDomainAxis().getLabel());
    chart.setXAxis(xAxis);

    gov.sandia.bioram.xml.RamModel.Chart.YAxis yAxis = of.createRamModelChartYAxis();
    yAxis.setMax(this.getXYPlot().getRangeAxis().getUpperBound());
    yAxis.setMin(this.getXYPlot().getRangeAxis().getLowerBound());
    yAxis.setTitle(this.getXYPlot().getRangeAxis().getLabel());
    chart.setYAxis(yAxis);

    int numDataPoints = ((XYSeriesCollection)((XYPlot)this.getPlot()).getDataset()).getSeriesCount();
    for (int i = 0; i < numDataPoints; i++) {
      ChartDataSeries cdp = (ChartDataSeries)((XYSeriesCollection)((XYPlot)this.getPlot()).getDataset()).getSeries(i);
      gov.sandia.bioram.xml.RamModel.Chart.DataPoint ramMLDP = of.createRamModelChartDataPoint();

      ramMLDP.setLegendTitle((String)cdp.getKey());
      ramMLDP.setXResultProfileUUID(cdp.getXRP().getUuid().toString());
      ramMLDP.setYResultProfileUUID(cdp.getYRP().getUuid().toString());

      chart.getDataPoint().add(ramMLDP);
    }

    chart.setChartTitle(this.getTitle().getText());
    return chart;
  }
}

class RamChartTester {
  private RamChart rc;

  public RamChartTester() {
    RamModel model = this.getRamModel();
    this.rc = (RamChart)model.getChartsListModel().getElementAt(1);


    ChartPanel cp = new ChartPanel(this.rc);
    cp.setSize(new Dimension(400, 400));

    JFrame frame = new JFrame();
    frame.add(cp);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setLocationRelativeTo(null);
    frame.pack();
    frame.setVisible(true);
  }

  public static void main(String args[]) {
    RamChartTester uut = new RamChartTester();
    uut.writeDataPointToFile(new File("C:/Users/danbowe/Desktop/"));
  }

  public void writeDataPointToFile(File f) {
    for (int i = 0; i < this.rc.getXYPlot().getSeriesCount(); i++) {
      XYLineAndShapeRenderer r = (XYLineAndShapeRenderer)rc.getXYPlot().getRenderer();
      Rectangle b = r.getSeriesShape(i).getBounds();
      BufferedImage bi = new BufferedImage((int)b.getWidth()*2, (int)b.getHeight()*2, BufferedImage.TYPE_INT_ARGB);

      Graphics2D g = (Graphics2D)bi.getGraphics();
      g.scale(2, 2);
      g.translate(-b.getX(), -b.getY());
      g.setPaint(r.lookupSeriesPaint(i));
      g.setStroke(r.lookupSeriesOutlineStroke(i));
      g.fill(r.lookupSeriesShape(i));

      try {
        ImageIO.write(bi, "png", new File(f, i + ".png"));
      } catch(Exception e) {
        e.printStackTrace();
      }
    }
  }

  public RamModel getRamModel() {
    try {
      File fp = new File("C:/Users/danbowe/Documents/testModel.raml");
      RamFileMarshal marshal = new RamFileMarshal(fp);
      return marshal.getRamModel();
    } catch (Exception e) {
      e.printStackTrace();
    }
    return null;
  }
}