/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gov.sandia.bioram.forms.dnd;

import gov.sandia.bioram.classes.model.QuestionSetModule;
import gov.sandia.bioram.classes.model.QuestionSetQuestion;
import gov.sandia.bioram.forms.ProfileEditorForm.TreeType;
import javax.swing.JTree;
import javax.swing.TransferHandler;
import javax.swing.tree.TreePath;

/**
 * Intended for the questionSetTree
 * @author danbowe
 */
public class QuestionSetTreeTransferHandler extends TreeTransferHandler {
  TreeUpdateable treeUpdateable;

  public QuestionSetTreeTransferHandler(QuestionSetModule currModule, TreeUpdateable treeUpdateable) {
    super(currModule, TreeType.QuestionSet);
    this.treeUpdateable = treeUpdateable;
  }

  /**
   * If this came from a Question Set tree and I'm not trying to make a question
   * a parent of something, this is acceptable.
   * @param ts
   * @return
   */
  @Override
  public boolean canImport(TransferHandler.TransferSupport ts) {
    try {
      TransferableTreePaths t = (TransferableTreePaths)ts.getTransferable().getTransferData(TransferableTreePaths.objFlavor);
      TreePath dropPath = ((JTree.DropLocation)ts.getDropLocation()).getPath();

      if (t.getOriginatingTree() == TreeType.QuestionSet) {
        return (dropPath == null) ? true : !(dropPath.getLastPathComponent() instanceof QuestionSetQuestion);
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return false;
  }

  @Override
  public boolean importData(TransferHandler.TransferSupport ts) {
    boolean importSuccessful = super.importData(ts);
    if (importSuccessful) {
      this.treeUpdateable.updateQuestionSetTree();
      this.treeUpdateable.updateResultProfileTree();
    }

    return importSuccessful;
  }

}// </editor-fold>

