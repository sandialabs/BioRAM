/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gov.sandia.bioram.classes.model;

import java.awt.Color;
import java.text.NumberFormat;
import gov.sandia.bioram.xml.ObjectFactory;

/**
 *
 * @author danbowe
 */
public class ResultMathOpConstant extends ResultMathOp {
  double constant;

  public ResultMathOpConstant(double rawWeight, String title, double constant) {
    super(rawWeight, title, true);
    this.constant = constant;
    this.mathOpTypeKey = "Constant";

    String constStr = NumberFormat.getInstance().format(this.constant);
    this.extraToStringInfo = ", " + constStr;
  }

  public double getConstant() {
    return this.constant;
  }

  @Override
  public double getScore() {
    return (this.constant * this.getWeight());
  }

  // Same as ResultObject - We specifically don't want children for this, so ResultMathOp's getColor doesn't cut it
  @Override
  public Color getColor() {
    return (this.children != null && !this.children.isEmpty()) ? this.errorColor : this.rawColor;
  }

  @Override
  public void toJAXB(gov.sandia.bioram.xml.ResultMathOpExponent.Children children) {
    ObjectFactory of = new ObjectFactory();
    gov.sandia.bioram.xml.ResultMathOpConstant rmoc = of.createResultMathOpConstant();
    rmoc.setConstant(this.getConstant());
    rmoc.setRawWeight(this.getRawWeight());
    rmoc.setTitle(this.getTitle());

    children.getResultMathOpAddOrResultMathOpSubtractOrResultMathOpMultiply().add(rmoc);
  }
}
