/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gov.sandia.bioram.classes.model.randomclasses;

import gov.sandia.bioram.classes.model.QuestionSetModule;
import gov.sandia.bioram.classes.model.QuestionSetRoot;
import gov.sandia.bioram.classes.model.RamModel;
import gov.sandia.bioram.classes.model.ResultObject;
import gov.sandia.bioram.classes.model.ResultProfile;
import gov.sandia.bioram.classes.model.ResultReference;
import gov.sandia.bioram.classes.model.ResultTitle;
import gov.sandia.bioram.classes.model.charts.RamChart;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLDecoder;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import javax.imageio.ImageIO;
import javax.xml.bind.JAXB;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
import org.apache.commons.compress.archivers.zip.ZipFile;
import org.apache.commons.compress.utils.IOUtils;
import gov.sandia.bioram.xml.ObjectFactory;
import gov.sandia.bioram.xml.RamModel.ModelInformation;
import gov.sandia.bioram.xml.RamModel.QuestionModule;
import gov.sandia.bioram.xml.RamModel.QuestionModule.ResponseSet;
import gov.sandia.bioram.xml.RamModel.QuestionModule.ResponseSet.Response;

/**
 * Encapsulates the environment of the writeToJAXB file directory structure.  This
 * also involves adding media - you simply add the image to this object and it
 * returns an identifier for it.  To writeToJAXB the ramML JAXB object, you pass it
 * to this object and it calls the method to marshal it to XML.
 * 
 * There are two forms of this:
 *   Marshal
 *     Output: the RAML file, zipped and written to disk
 *     Input: the raw RamModel.
 *     Task: convert the RamModel to a ramML
 *   Unmarshal
 *     Output: the raw RamModel
 *     Input: the raw RAML file
 *
 * This represents an adapter between the JAXB and POJO versions of the ram
 * models.
 *
 * @author danbowe
 */
public class RamFileMarshal {
  /**
   * This is the images (media) directory of the zipped RAML file
   */
  private static final String MediaPath = "media";// + File.separator;
  private static final String sep = "/"; // Directory separator
  /**
   * The path to the actual model file.
   */
  private static final String ModelPath = "model.xml";

  private RamModel ramModel;
  private gov.sandia.bioram.xml.RamModel ramMLModel;
  private final Map<String, Image> imageMap = new HashMap<String, Image>();

  
  public RamFileMarshal(File ramJAXBFile) throws IOException {
    File tmpDir = RamFileMarshal.createDirectoryFromZip(ramJAXBFile);
    this.ramMLModel = JAXB.unmarshal(new File(tmpDir, ModelPath), gov.sandia.bioram.xml.RamModel.class);
    this.ramModel = new RamModel();

    // Load the images to imageMap (assumes all files in here are images)
    File mediaDir = new File(tmpDir, MediaPath);
    if (mediaDir.exists()) {
      for (File fp : mediaDir.listFiles()) {
        this.imageMap.put(MediaPath + sep + fp.getName(), ImageIO.read(fp));
      }
    }
    // At this point, we're done with the actual file - everything should be loaded into memory.
    RamFileMarshal.removeDirectory(tmpDir);

    // Bind the front matter, if it exists
    ModelInformation mi = ramMLModel.getModelInformation();
    if (mi != null) {
      String imagePath = ramMLModel.getModelInformation().getFrontImagePath();
      this.ramModel.setFrontImage(this.imageMap.get(imagePath));
      this.ramModel.setFrontHTMLText(ramMLModel.getModelInformation().getFrontHTML());
    }

    // Bind the QuestionSetModules
    for (QuestionModule qm : ramMLModel.getQuestionModule()) {
      this.ramModel.addModule(new QuestionSetModule(qm));
    }

    // TODO: Verify that I'm denormalizing correctly upon parsing, especially in ResultTitles
    // Bind the Result Profiles
    for (gov.sandia.bioram.xml.RamModel.ResultProfile rpML : ramMLModel.getResultProfile()) {
      ResultProfile rp = new ResultProfile(this.ramModel, rpML);
      this.ramModel.addResultProfile(rp);
    }
    // Now that all RPs have been parsed, fix up refUUIDs in ResultReferences to point to RP instances
    this.findRPInstancesForRPUUIDsForResultRefs();


    // Bind the Charts
    for (gov.sandia.bioram.xml.RamModel.Chart chart : ramMLModel.getChart()) {
      RamChart rc = new RamChart(this.ramModel, this, chart);
      this.ramModel.addChart(rc);
    }
  }

  /**
   * To connect ResultReferences to instances, we have to do this after
   * all RPs have been parsed in.  This accesses the ramModel variable and
   * connects those instances to ResultReferences (if they can be found).
   *
   * TODO: Delete ResRefs when deleting a result profile
   * TODO: Detect circular refs when creating result refs
   */
  private void findRPInstancesForRPUUIDsForResultRefs() {
    for (Object obj : this.ramModel.getResultProfilesListModel().toArray()) {
      ResultProfile rp = (ResultProfile)obj;

      Enumeration e = ((ResultTitle)rp.getRoot()).depthFirstEnumeration();

      for (ResultObject currRO = (ResultObject)e.nextElement(); e.hasMoreElements(); currRO = (ResultObject)e.nextElement()) {
        if (currRO instanceof ResultReference) {
          ResultReference rr = (ResultReference)currRO;
          // This is the only time ever this function should be called
          UUID refUUID = rr.getRefUUID();
          ResultProfile referencedRP = this.ramModel.getRPByUUID(refUUID);

          if (!ResultReference.isCircularResultReference(rp, referencedRP)) {
            rr.setRefRP(referencedRP);
          } else {
            System.err.println("Not adding ResultReference due to circular reference");
          }
        }
      }
    }

  }
  
  /**
   * Loads the JAXB RAML file and only checks the responses section, adding it
   * to the model.
   * 
   * @param model The model to add the responses to
   * @param ramlFile The RAML file with the responses to add
   */
  public static void addResponsesToModel(RamModel model, File ramlFile) throws IOException {
    // Unpack the file
    File tmpDir = RamFileMarshal.createDirectoryFromZip(ramlFile);
    gov.sandia.bioram.xml.RamModel ramMLModel = JAXB.unmarshal(new File(tmpDir, ModelPath), gov.sandia.bioram.xml.RamModel.class);
    RamFileMarshal.removeDirectory(tmpDir);

    if (ramMLModel.getModelInformation() != null) {
      model.setNames(ramMLModel.getModelInformation().getNames());
      model.setProcedure(ramMLModel.getModelInformation().getProcedure());
    }

    for (QuestionModule qm : ramMLModel.getQuestionModule()) {
      UUID uuidCurrentRAMLQM = UUID.fromString(qm.getQuestionSetRoot().getUuid());

      // Find the corresponding qm in the model
      for (Object obj : model.getModulesListModel().toArray()) {
        QuestionSetModule qsm = (QuestionSetModule)obj;
        UUID uuidCurrentQSM = ((QuestionSetRoot)qsm.getRoot()).getUUID();
        
        // If they do match, then this is the QuestionSetModule we're looking for
        if (uuidCurrentQSM.equals(uuidCurrentRAMLQM)) {
          // Now parse in the response sets
          for (ResponseSet rs : qm.getResponseSet()) {
            qsm.saveResponses(new SavedResponsesHashMap(rs), true);
          }
        }
      }
    }
  }

  public static void writeResponsesToJAXB(RamModel model, File ramlOutputFile) throws IOException {
    ObjectFactory of = new ObjectFactory();
    gov.sandia.bioram.xml.RamModel ramMLModel = of.createRamModel();

    gov.sandia.bioram.xml.RamModel.ModelInformation mi = of.createRamModelModelInformation();
    mi.setNames(model.getNames());
    mi.setProcedure(model.getProcedure());
    ramMLModel.setModelInformation(mi);

    for (Object obj : model.getModulesListModel().toArray()) {
      QuestionSetModule qsm = (QuestionSetModule) obj;
      
      if (qsm.getSavedResponseComboBoxModel().getSize() > 0) {
        QuestionModule qmML = of.createRamModelQuestionModule();
        QuestionSetRoot qsRoot = (QuestionSetRoot) qsm.getRoot();
        gov.sandia.bioram.xml.QuestionSetRoot rootML = of.createQuestionSetRoot();

        rootML.setUuid(qsRoot.getUUID().toString()); // Most important property to set
        qmML.setQuestionSetRoot(rootML);

        // Now copy the actual responses
        for (int i = 0; i < qsm.getSavedResponseComboBoxModel().getSize(); i++) {
          SavedResponsesHashMap resp = (SavedResponsesHashMap) qsm.getSavedResponseComboBoxModel().getElementAt(i);

          ResponseSet rsML = of.createRamModelQuestionModuleResponseSet();
          rsML.setResponseSetName(resp.getName());

          for (UUID uuidKey : resp.keySet()) {
            Response r = of.createRamModelQuestionModuleResponseSetResponse();
            r.setUuid(uuidKey.toString());
            r.setValue(resp.get(uuidKey).score);
            rsML.getResponse().add(r);
          }
          qmML.getResponseSet().add(rsML);
        }
        ramMLModel.getQuestionModule().add(qmML);
      }
    }

    // Write results to JAXB
    File tmp = RamFileMarshal.createTempDirectory();
    JAXB.marshal(ramMLModel, new File(tmp, ModelPath));
    RamFileMarshal.createZipFromDirectory(tmp, ramlOutputFile);
    RamFileMarshal.removeDirectory(tmp);
  }

  public RamModel getRamModel() {
    return this.ramModel;
  }

  public gov.sandia.bioram.xml.RamModel getJAXBRamModel() {
    return this.ramMLModel;
  }

  /**
   * Represents the constructor used for saving a RamModel to a file.
   */
  public RamFileMarshal(RamModel ramModel) {
    ObjectFactory of = new ObjectFactory();
    this.ramMLModel = of.createRamModel();
    this.ramModel = ramModel;

    // Write the model information
    ModelInformation mi = of.createRamModelModelInformation();
    mi.setFrontHTML(this.ramModel.getFrontHTMLText());
    if (this.ramModel.getFrontImage() != null) {
      String imagePath = this.addImage(this.ramModel.getFrontImage());
      mi.setFrontImagePath(imagePath);
    }
    ramMLModel.setModelInformation(mi);

    // Write the QuestionSetModules to JAXB
    for (Object qsm : this.ramModel.getModulesListModel().toArray()) {
      ramMLModel.getQuestionModule().add(((QuestionSetModule)qsm).toJAXB());
    }

    // Write the Result Profiles to JAXB
    for (Object rp : this.ramModel.getResultProfilesListModel().toArray()) {
      ramMLModel.getResultProfile().add(((ResultProfile)rp).toJAXB());
    }

    // Now write the charts out to JAXB
    for (Object obj : this.ramModel.getChartsListModel().toArray()) {
      RamChart ramChart = (RamChart)obj;
      gov.sandia.bioram.xml.RamModel.Chart chart = ramChart.toJAXB();

      if (ramChart.getXYPlot().getBackgroundImage() != null) {
        String imagePath = this.addImage(ramChart.getXYPlot().getBackgroundImage());
        chart.setBackgroundImagePath(imagePath);
      }
      ramMLModel.getChart().add(chart);
    }
  }

  /**
   * Adds this image to the file's map, names it something random (a UUID), then
   * returns this random name that becomes its new reference.
   *
   * @param image The image to writeToJAXB
   * @return the identifier for the image.
   */
  private String addImage(Image image) {
    String imagePath = MediaPath + sep + UUID.randomUUID() + ".png";
    this.imageMap.put(imagePath, image);
    return imagePath;
  }


  public static void createZipFromDirectory(File directory, File zipFile) throws IOException {
    FileOutputStream fOut = null;
    BufferedOutputStream bOut = null;
    ZipArchiveOutputStream zipOut = null;
    
    try {
      fOut = new FileOutputStream(zipFile);
      bOut = new BufferedOutputStream(fOut);
      zipOut = new ZipArchiveOutputStream(bOut);

      for (File fp : directory.listFiles()) {
        addFileToZip(zipOut, fp, "");
      }
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      zipOut.finish();

      zipOut.close();
      bOut.close();
      fOut.close();
    }
  }
          
 
  /**
   * Creates a directory in the system temp folder
   * 
   * @return
   * @throws IOException
   */
  public static File createTempDirectory() throws IOException {
    File tmp = File.createTempFile(UUID.randomUUID().toString(), null);
    tmp.delete(); // Delete the flat file so I can make a directory instead

    // Create directory structure
    tmp.mkdir();
    return tmp;
  }

  public void writeToJAXB(File savePath) {
    try {
      File tmp = RamFileMarshal.createTempDirectory();
      JAXB.marshal(this.ramMLModel, new File(tmp, ModelPath));

      // Save all the images to the media directory with png compression
      new File(tmp, MediaPath).mkdirs();
      for (String pathKey : this.imageMap.keySet()) {
        File imageFile = new File(tmp, pathKey);
        ImageIO.write((BufferedImage) this.imageMap.get(pathKey), "png", imageFile);
      }

      RamFileMarshal.createZipFromDirectory(tmp, savePath);
      RamFileMarshal.removeDirectory(tmp);
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  /**
   * A Utility function to copy files (including folders) from one file to
   * another.  This is a step above IOUtils.Copy(InputStream, InputStream)
   * (from the Apache Compress Commons) in abstraction.
   *
   * @param src
   * @param dest
   * @throws IOException
   */
  public static void deepCopy(File src, File dest) throws IOException {
    if (src.isDirectory()) {
      //if directory not exists, create it
      if (!dest.exists()) {
        dest.mkdir();
      } else {
        dest.delete(); // Overwrite automatically
      }

      //list all the directory contents
      String files[] = src.list();

      for (String file : files) {
        //construct the src and dest file structure
        File srcFile = new File(src, file);
        File destFile = new File(dest, file);
        //recursive copy
        deepCopy(srcFile, destFile);
      }

    } else {
      //if file, then copy it
      //Use bytes stream to support all file types
      InputStream in = new FileInputStream(src);
      OutputStream out = new FileOutputStream(dest);

      byte[] buffer = new byte[1024];

      int length;
      //copy the file content in bytes
      while ((length = in.read(buffer)) > 0) {
        out.write(buffer, 0, length);
      }

      in.close();
      out.close();
    }
  }

  public void SerializeObject(Object object, File path) {
    try {
      ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(path));
      oos.writeObject(object);
      oos.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public Image getImage(String pathKey) {
    return this.imageMap.get(pathKey);
  }

  /**
   * Creates a directory with a random UUID name containing the contents of
   * the zip file.
   *
   * @param inputZipFile
   * @return
   * @throws IOException
   */
  public static File createDirectoryFromZip(File inputZipFile) throws IOException {
    ZipFile zipFile = null;
    File outDir = null;

    try {
      zipFile = new ZipFile(inputZipFile);
      outDir = File.createTempFile(UUID.randomUUID().toString(), null);
      outDir.delete(); // I want a directory, not a flat file
      outDir.mkdir();

      Enumeration<ZipArchiveEntry> zipEnum = zipFile.getEntries();
      while (zipEnum.hasMoreElements()) {
        ZipArchiveEntry entry = zipEnum.nextElement();
        if (entry.isDirectory()) {
          new File(outDir, entry.getName()).mkdirs();
        } else {
          File entryFile = new File(outDir, entry.getName());
          // Make sure the directory this is in exists
          if (!entryFile.getParentFile().exists()) {
            entryFile.getParentFile().mkdirs();
          }
          
          InputStream content = zipFile.getInputStream(entry);          
          OutputStream os = new FileOutputStream(entryFile);
          IOUtils.copy(content, os);
          os.close();          
          content.close();
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      zipFile.close();
    }
    return outDir;
  }


  /**
   * Creates a zip entry for the path specified with a name built from the base passed in and the file/directory
   * name.  If the path is a directory, a recursive call is made such that the full directory is added to the tar.
   *
   * @param zipOut The zip file's output stream
   * @param f The filesystem path of the file/directory being added
   * @param base The base prefix to for the name of the tar file entry
   *
   * @throws IOException If anything goes wrong
   */
  private static void addFileToZip(ZipArchiveOutputStream zipOut, File f, String base) throws IOException {
    String entryName = base + f.getName();
    ZipArchiveEntry zipEntry = new ZipArchiveEntry(f, entryName);

    zipOut.putArchiveEntry(zipEntry);

    if (f.isFile()) {
      FileInputStream fis = new FileInputStream(f);
      IOUtils.copy(fis, zipOut);
      fis.close();

      zipOut.closeArchiveEntry();
    } else {
      zipOut.closeArchiveEntry();

      File[] children = f.listFiles();

      if (children != null) {
        for (File child : children) {
          addFileToZip(zipOut, child, entryName + "/");//File.separator);
        }
      }
    }
  }
  
  public static boolean removeDirectory(File directory) {
    // System.out.println("removeDirectory " + directory);

    if (directory == null) {
      return false;
    }
    if (!directory.exists()) {
      return true;
    }
    if (!directory.isDirectory()) {
      return false;
    }

    String[] list = directory.list();

    // Some JVMs return null for File.list() when the
    // directory is empty.
    if (list != null) {
      for (int i = 0; i < list.length; i++) {
        File entry = new File(directory, list[i]);

        //        System.out.println("\tremoving entry " + entry);

        if (entry.isDirectory()) {
          if (!removeDirectory(entry)) {
            return false;
          }
        } else {
          if (!entry.delete()) {
            return false;
          }
        }
      }
    }

    return directory.delete();
  }

/**
   * List directory contents for a resource folder. Not recursive.
   * This is basically a brute-force implementation.
   * Works for regular files and also JARs.
   *
   * @author Greg Briggs
   * @param clazz Any java class that lives in the same place as the resources you want.
   * @param path Should end with "/", but not start with one.
   * @return Just the name of each member item, not the full paths.
   * @throws URISyntaxException
   * @throws IOException
   */
  public static String[] getResourceListing(Class clazz, String path) throws URISyntaxException, IOException {
      URL dirURL = clazz.getClassLoader().getResource(path);
      System.out.println("Using RamFileMarshal to get to " + dirURL.getPath());
      if (dirURL != null && dirURL.getProtocol().equals("file")) {
        /* A file path: easy enough */
        return new File(dirURL.toURI()).list();
      }

      if (dirURL == null) {
        /*
         * In case of a jar file, we can't actually find a directory.
         * Have to assume the same jar as clazz.
         */
        String me = clazz.getName().replace(".", "/")+".class";
        dirURL = clazz.getClassLoader().getResource(me);
      }

      if (dirURL.getProtocol().equals("jar")) {
        /* A JAR path */
        String jarPath = dirURL.getPath().substring(5, dirURL.getPath().indexOf("!")); //strip out only the JAR file
        JarFile jar = new JarFile(URLDecoder.decode(jarPath, "UTF-8"));
        Enumeration<JarEntry> entries = jar.entries(); //gives ALL entries in jar
        Set<String> result = new HashSet<String>(); //avoid duplicates in case it is a subdirectory
        while(entries.hasMoreElements()) {
          String name = entries.nextElement().getName();
          if (name.startsWith(path)) { //filter according to the path
            String entry = name.substring(path.length());
            int checkSubdir = entry.indexOf("/");
            if (checkSubdir >= 0) {
              // if it is a subdirectory, we just return the directory name
              // entry = entry.substring(0, checkSubdir);
            }
            result.add(entry);
          }
        }
        return result.toArray(new String[result.size()]);
      }

      throw new UnsupportedOperationException("Cannot list files for URL "+dirURL);
  }

  // Test for archiving
  public static void main(String args[]) {
    try {
//      File tmp = File.createTempFile(UUID.randomUUID().toString(), null);
//      System.out.println(tmp);

      for (String s : RamFileMarshal.getResourceListing(RamFileMarshal.class, "")) {
        System.out.println(s);
      }

    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
