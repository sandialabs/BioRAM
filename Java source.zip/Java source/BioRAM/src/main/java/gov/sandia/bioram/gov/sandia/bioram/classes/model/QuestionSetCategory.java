/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gov.sandia.bioram.classes.model;

import java.text.NumberFormat;
import gov.sandia.bioram.xml.ObjectFactory;

/**
 *
 * @author danbowe
 */
public class QuestionSetCategory extends QuestionSetObject {
  public QuestionSetCategory(String title, double defaultWeight) {
    super(title);
    this.defaultWeight = defaultWeight;
  }


  @Override
  public String getJListString(int singleIndentSize, int listWidth) {
    int indentWidth = singleIndentSize * this.getLevel();
    int textWidth = listWidth - indentWidth;

    String text =
      "<html>" +
      "  <style type=\"text/css\">" +
      "    #indentOffset {" +
      "      width: " + indentWidth + "px;" +
      "    }" +
      "    #title {" +
      "      width: " + (textWidth - 175) + "px;" + // -175 = Hack to get text alignment
      "      color: rgb(" + this.getColor().getRed() + "," + this.getColor().getGreen() + "," + this.getColor().getBlue() + ");" +
      "      font-size: 120%;" +
      "    }" +
      "    #container {" +
      "      padding: 5px;" +
      "    }" +
      "  </style>" +
      "  <table>" +
      "    <tr>" +
      "      <td id=\"indentOffset\"></td>" +
      "      <td>" +
      "        <div id=\"container\">" +
      "          <div id=\"title\">" + this.getUserObject().toString().replace("\n", "<br/>") + "</div>" +
      "        </div>" +
      "      </td>" +
      "    </tr>" +
      "  </table>" +
      "</html>";

    return text;
  }


  @Override
  public String toString() {
    String weightStr = NumberFormat.getInstance().format(this.defaultWeight);
    return "<html><font color=\"rgb(136,136,136\">C (" + weightStr + ") " + super.toString() + "</font></html>";
  }

  @Override
  public void toJAXB(gov.sandia.bioram.xml.QuestionSetObject.Children children) {
    ObjectFactory of = new ObjectFactory();
    gov.sandia.bioram.xml.QuestionSetCategory qsc = of.createQuestionSetCategory();
    qsc.setTitle(this.getTitle());
    qsc.setUuid(this.getUUID().toString());
    qsc.setDefaultWeight(this.getDefaultWeight());
    qsc.setChildren(of.createQuestionSetObjectChildren());

    children.getQuestionSetObjectOrQuestionSetQuestionOrQuestionSetCategory().add(qsc);

    for (int i = 0; i < this.getChildCount(); i++) {
      QuestionSetObject qso = (QuestionSetObject)this.getChildAt(i);

      qso.toJAXB(qsc.getChildren());
    }
  }
}
