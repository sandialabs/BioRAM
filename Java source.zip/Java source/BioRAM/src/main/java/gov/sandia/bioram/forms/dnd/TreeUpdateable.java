/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gov.sandia.bioram.forms.dnd;

/**
 * Called by the drag and drop delegate to update trees
 * @author danbowe
 */
public interface TreeUpdateable {
  public void updateQuestionSetTree();
  public void updateResultProfileTree();
}