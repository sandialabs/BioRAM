/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gov.sandia.bioram.classes.model;

import gov.sandia.bioram.classes.model.randomclasses.ObservableTreeModel;
import gov.sandia.bioram.forms.dnd.UUIDIdentifiable;
import java.util.Enumeration;
import java.util.List;
import java.util.UUID;
import javax.swing.event.TreeModelListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;
import gov.sandia.bioram.xml.ObjectFactory;

/**
 *
 *
 * @author danbowe
 */
public class ResultProfile extends ObservableTreeModel
        implements UUIDIdentifiable, TreeModelListener {

  private double score = 0;
  private UUID uuid;


  public ResultProfile(String name) {
    // Super sends the TreeModel name as its root node name
    super(new ResultTitle(name));

    this.uuid = UUID.randomUUID();
  }

  /**
   *
   * @param model needs a reference to this so that it can find the
   * QuestionSetObjects in there
   * @param rp the JAXB version of a result profile
   */
  public ResultProfile(RamModel model, gov.sandia.bioram.xml.RamModel.ResultProfile rp) {
    this(rp.getResultTitle().getTitle());

    this.uuid = UUID.fromString(rp.getUuid());
    ResultObject root = (ResultObject)this.getRoot();
    root.setRawWeight(rp.getResultTitle().getRawWeight(), false);
    root.setNormalizeChildren(rp.getResultTitle().isNormalizeChildren());
    ResultObject.generateTreeFromJAXB(model, rp.getResultTitle().getChildren(), root);
  }

  public UUID getUuid() {
    return uuid;
  }

  public void setUuid(UUID uuid) {
    this.uuid = uuid;
  }


  /**
   * CURRENT score?  What does that mean?  It means there is emphasis on the fact that this
   * score is highly subject to the currently-selected SavedResponsesHashMap in each question's
   * QuestionSetModule.
   * @param recalculate
   * @return
   */
  public double getCurrentScore(boolean recalculate) {
    if (recalculate) {
      this.score = ((ResultObject)this.getRoot()).getScore();
    }
    return score;
  }

  @Override
  public String toString() {
    // ResultTitle - make sure this node is never replaced with anything else
    return ((ResultTitle)this.getRoot()).getTitle();
  }
  /**
   * @note This method should only be called by the RamModel
   *
  */
  public void removeQuestionSetFromResultProfile(QuestionSetModule questionSet) {
    // Don't need to check the dfs root because that won't be visible
    Enumeration e = ((QuestionSetObject)questionSet.getRoot()).depthFirstEnumeration();

    for (QuestionSetObject currQS = (QuestionSetObject)e.nextElement(); e.hasMoreElements(); currQS = (QuestionSetObject)e.nextElement()) {
      this.removeQuestionFromResultProfile(currQS);
    }
    this.notifyObservers();
  }

  public void swapNodes(ResultObject oldNode, ResultObject newNode) {
    while (oldNode.getChildCount() > 0) {
      newNode.add((ResultObject)oldNode.getChildAt(0));
    }
    ((ResultObject)oldNode.getParent()).add(newNode);
    ((ResultObject)oldNode.getParent()).remove(oldNode);

    this.notifyObservers();
  }

  /**
   * Depth-first-search recursive function to remove a question from a result profile.
   *
   * If this is a question being removed and the result object we're looking
   * at currently is a ResultQuestion AND that ResultQuestion is
   * referencing this same question set question object, then remove it.
   * OR
   * If this is a ResultReference pointing a ResultObject that points to the
   * question being removed, remove it.
   *
   * @note This method should only be called by the RamModel
   *
   * @param currNode
   * @param questionSetObj
   */
  public void removeQuestionFromResultProfile(QuestionSetObject questionSetObj) {
    // Changing the list changes the order of dfs, so we have to restart every time something is removed
    boolean rpHasChanged = true, debugDFS = false;
    while (rpHasChanged) {
      rpHasChanged = false;
      Enumeration e = ((ResultObject)this.getRoot()).depthFirstEnumeration();
      if (debugDFS) System.out.println("Enumerating from the start");

      for (ResultObject currRO = (ResultObject)e.nextElement(); e.hasMoreElements(); currRO = (ResultObject)e.nextElement()) {
        if (debugDFS) System.out.println("DFS: " + currRO.toString());
        if (((currRO instanceof ResultQuestion) &&
            (questionSetObj instanceof QuestionSetQuestion) &&
            (((ResultQuestion)currRO).referenceQuestion == questionSetObj))
            ||
            ((currRO instanceof ResultCategory) &&
            (questionSetObj instanceof QuestionSetCategory) &&
            (((ResultCategory)currRO).referenceCategory == questionSetObj))
           /* ||  // ResultReferences have been removed for now
            ((currRO instanceof ResultReference) &&
            (((ResultReference)currRO).refResultObject instanceof ResultQuestion) &&
            (questionSetObj instanceof QuestionSetQuestion) &&
            (((ResultQuestion)((ResultReference)currRO).refResultObject).referenceQuestion == questionSetObj))
            ||
            ((currRO instanceof ResultReference) &&
            (((ResultReference)currRO).refResultObject instanceof ResultCategory) &&
            (questionSetObj instanceof QuestionSetCategory) &&
            (((ResultCategory)((ResultReference)currRO).refResultObject).referenceCategory == questionSetObj))*/) {
          if (debugDFS) System.out.println("Removing \"" + questionSetObj.toString() + "\" from \"" + this.toString() + "\"");

          while (currRO.getChildCount() > 0) {
            ((ResultObject)currRO.getParent()).add((ResultObject)currRO.getChildAt(0));
          }
          ((ResultObject)currRO.getParent()).remove(currRO);
          rpHasChanged = true;
          break;
        }
      }
    }
    this.notifyObservers();
  }
  
  public void addResultObject(TreePath parentPath, ResultObject object) {
    ResultObject parent;
    if (object != null) {
      if (parentPath == null) {
        parent = (ResultObject)this.getRoot();
      } else {
        parent = (ResultObject)parentPath.getLastPathComponent();
      }
      // Truly insert this ResultMathOp - inherit children
      if ((object instanceof ResultMathOp) && !(object instanceof ResultMathOpConstant)) {
        while (parent.getChildCount() > 0) {
          object.add((ResultObject)parent.getChildAt(0));
        }
      }
      parent.add(object);
    }
    this.notifyObservers();
  }

  @Override
  public DefaultMutableTreeNode getNodeByUUID(Object nodeObject) {
    if (nodeObject instanceof ResultObject) {
      UUID id = ((ResultObject)nodeObject).getUUID();
      Enumeration e = ((ResultObject)this.getRoot()).depthFirstEnumeration();

      for (ResultObject currRO = (ResultObject)e.nextElement(); e.hasMoreElements(); currRO = (ResultObject)e.nextElement()) {
        if (currRO.getUUID().equals(id)) {
          return currRO;
        }
      }
      // ...because this dfs enumeration doesn't search the root
      return (((ResultObject)this.getRoot()).getUUID().equals(id)) ? (ResultObject)this.getRoot() : null;
    } else {
      return null;
    }
  }

  public gov.sandia.bioram.xml.RamModel.ResultProfile toJAXB() {
    ObjectFactory of = new ObjectFactory();
    gov.sandia.bioram.xml.RamModel.ResultProfile rp = of.createRamModelResultProfile();
    rp.setUuid(this.getUuid().toString());

    gov.sandia.bioram.xml.ResultMathOpExponent.Children children = of.createResultMathOpExponentChildren();
    ResultTitle rootRO = (ResultTitle)this.getRoot();
    rootRO.toJAXB(children); // Create the source tree here
    // A bit of a hack to get the root object out
    List<Object> c = children.getResultMathOpAddOrResultMathOpSubtractOrResultMathOpMultiply();
    if (c.size() > 0) {
      rp.setResultTitle((gov.sandia.bioram.xml.ResultTitle)c.get(0));
    }

    return rp;
  }

//
//  public ResultProfile clone() {
//    ResultProfile rp = new ResultProfile(((ResultTitle)this.getRoot()).getTitle());
//
//    return rp;
//  }
//
//  private void copyROTree(ResultObject roSrc, ResultObject roDest) {
//    Enumeration e = roSrc.children();
//    while (e.hasMoreElements()) {
//      ResultObject ro = (ResultObject)e.nextElement();
//
//
//    }
//  }
}
