/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gov.sandia.bioram.classes.model.charts;

import org.jfree.data.xy.XYDataItem;

/**
 *
 * @author danbowe
 */
public class ChartDataItem extends XYDataItem {
  /**
   * This is the text displayed by the interactive chart when you hover over it.
   * It contains more information since there's more space (the X/Y axis titles and
   * the legend series type)
   */
  private String toolTipText;
  
  /**
   * this is what's displayed in generated reports in the legend
   */
  private String legendHTML;

  public ChartDataItem(double x, double y, String toolTipText, String legendHTML) {
    super(x, y);
    this.toolTipText = toolTipText;
    this.legendHTML = legendHTML;
  }

  public String getLegendHTML() {
    return this.legendHTML;
  }

  public String getToolTipText() {
    return this.toolTipText;
  }

  @Override
  public String toString() {
    return this.getToolTipText();
  }
}
