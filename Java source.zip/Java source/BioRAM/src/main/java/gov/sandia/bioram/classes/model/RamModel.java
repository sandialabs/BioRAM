/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gov.sandia.bioram.classes.model;

import gov.sandia.bioram.classes.model.charts.ChartDataSeries;
import gov.sandia.bioram.classes.model.charts.RamChart;
import gov.sandia.bioram.classes.model.randomclasses.ObservableTreeModel.Observable;
import gov.sandia.bioram.classes.model.randomclasses.RamDataTable;
import gov.sandia.bioram.classes.model.randomclasses.SavedResponsesHashMap;
import java.awt.Image;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Observer;
import java.util.UUID;
import javax.swing.DefaultListModel;
import org.jfree.data.xy.XYSeriesCollection;


/**
 *
 * @author danbowe
 */
public class RamModel implements Observer {
  private Observable observableDelegate = new Observable();

  public void notifyObservers() {
    observableDelegate.notifyObservers();
  }

  public synchronized void addObserver(Observer o) {
    // TODO: remove this!
    if (this.observableDelegate == null)
      this.observableDelegate = new Observable();
    observableDelegate.addObserver(o);
  }

  public synchronized void deleteObserver(Observer o) {
    observableDelegate.deleteObserver(o);
  }

  private DefaultListModel modulesListModel = new DefaultListModel();
  private DefaultListModel resultProfilesListModel = new DefaultListModel();
  private DefaultListModel chartsListModel = new DefaultListModel();

  // Model preliminary information
  private Image frontImage;
  private String frontHTMLText = "";
  // Names and procedures do not belong to the model, but rather the responses.
  // They then possess a bit of a shaky middle ground being located in the
  // RamModel class.  ...just something to keep in mind.
  private String names = ""; // Be blank, not null, so Apache Velocity renders them regardless
  private String procedure = "";

  public String getNames() {
    return names;
  }

  public void setNames(String names) {
    this.names = names;
  }

  public String getProcedure() {
    return procedure;
  }

  public void setProcedure(String procedure) {
    this.procedure = procedure;
  }

  private RamDataTable cachedResults = null;

  public DefaultListModel getModulesListModel() {
    return this.modulesListModel;
  }

  public String getFrontHTMLText() {
    return frontHTMLText;
  }

  public void setFrontHTMLText(String frontHTMLText) {
    this.frontHTMLText = frontHTMLText;
  }

  public Image getFrontImage() {
    return frontImage;
  }

  public void setFrontImage(Image frontImage) {
    this.frontImage = frontImage;
  }

  public void addChart(RamChart chart) {
    this.chartsListModel.addElement(chart);

    this.notifyObservers();
  }

  public void removeChart(RamChart chart) {
    this.chartsListModel.removeElement(chart);

    this.notifyObservers();
  }
  
  public DefaultListModel getResultProfilesListModel() {
    return this.resultProfilesListModel;
  }

  public DefaultListModel getChartsListModel() {
    return this.chartsListModel;
  }

  public void addResultProfile(String title) {
    this.addResultProfile(new ResultProfile(title));
  }

  public void addResultProfile(ResultProfile rp) {
    this.resultProfilesListModel.addElement(rp);
    rp.addObserver(this);

    this.notifyObservers();
  }

  public void removeQuestionSetObject(QuestionSetObject currQSO) {
    for (Object rp : this.getResultProfilesListModel().toArray()) {
      ((ResultProfile)rp).removeQuestionFromResultProfile(currQSO);
    }

    // Let the module do this so it can also erase results belonging to this question
    ((QuestionSetRoot)currQSO.getRoot()).getModule().removeQuestionSetObject(currQSO);
    this.notifyObservers();
  }

  public void addModule(QuestionSetModule qsm) {
    this.getModulesListModel().addElement(qsm);
    qsm.addObserver(this);
    this.notifyObservers();
  }

  public void addModule(String title) {
    this.addModule(new QuestionSetModule(title));
  }

  public void removeResultObject(ResultObject ro) {
    if (!(ro instanceof ResultTitle)) { // Don't remove the root node
      while (ro.getChildCount() > 0) {
        ((ResultObject)ro.getParent()).add((ResultObject)ro.getChildAt(0));
      }
      ((ResultObject)ro.getParent()).remove(ro);
    }
    this.notifyObservers();
  }

  /**
   * Removes the module, but also goes through the result profiles and makes
   * sure all references to that module's question set are removed
   * @param module
   */
  public void removeModule(QuestionSetModule module) {
    for (Object rp : this.getResultProfilesListModel().toArray()) {
      ((ResultProfile)rp).removeQuestionSetFromResultProfile(module);
    }
    if (!this.getModulesListModel().removeElement(module)) {
      System.err.println("Warning - module list size not changed after removal");
    }
    module.deleteObservers();

    this.notifyObservers();
  }

  /**
   * If selectdResponses are supplied, it recomputes the data table, otherwise it
   * returns the cached data table.  This is the method that computes the cached
   * data table, via sending it some responses to construct it from.
   *
   * @param selectedResponses if null, the cached table is returned, else the
   * results are recomputed based on the selectedResponses
   * @return
   */
  //public RamDataTable getDataTableAndOrRecomputeCachedModelData(List<SavedResponsesHashMap> selectedResponses) {
//    if (selectedResponses != null) {
//      this.cachedResults = new RamDataTable(this, selectedResponses);
//    }
//    return (this.cachedResults == null) ? new RamDataTable(this, null) : this.cachedResults;
//  }

  public RamDataTable getCachedDataTable() {
    if (this.cachedResults == null) {
      // We shouldn't get to this situation
      System.err.println("Warning: something is asking me a data table, but I don't have one cached - setting to blank");
      this.cachedResults = new RamDataTable(this, new ArrayList<SavedResponsesHashMap>());
    }
    return this.cachedResults;
  }

  /**
   * This is what sets (computes) the data in the model.  It should be used wisely,
   * (I.E. only when the data selections have changed), as computing all the
   * data can potentially be an expensive operation.
   *
   * @param selectedResponses
   */
  public void setCachedModelResults(List<SavedResponsesHashMap> selectedResponses) {
    this.cachedResults = new RamDataTable(this, selectedResponses);
  }

  /**
   * This uses the cached data in this RamModel to populate the charts with all
   * data points.  For this reason, a cached data table should
   * exist in this model before this method is called.
   */
  public void plotAllDataPointsUsingCachedData() {
    for (int iChart = 0; iChart < this.getChartsListModel().getSize(); iChart++) {
      RamChart currChart = (RamChart)this.getChartsListModel().getElementAt(iChart);

      // For each series in each chart, plot it
      List<ChartDataSeries> selectedSeries = new ArrayList<ChartDataSeries>();
      for (int i = 0; i < currChart.getXYPlot().getSeriesCount(); i++) {
        selectedSeries.add((ChartDataSeries)((XYSeriesCollection)currChart.getXYPlot().getDataset()).getSeries(i));
      }
      currChart.setDataPoints(this.getCachedDataTable(), selectedSeries);
    }
  }

  /**
   * Removes the result profile
   * @param rp
   */
  public void removeResultProfile(ResultProfile rp) {
    // Remove ResultReferences that reference this rp
    for (Object obj : this.getResultProfilesListModel().toArray()) {
      ResultProfile rpIter = (ResultProfile) obj;

      Enumeration e = ((ResultTitle) rpIter.getRoot()).depthFirstEnumeration();
      for (ResultObject currRO = (ResultObject) e.nextElement(); e.hasMoreElements(); currRO = (ResultObject) e.nextElement()) {
        if (currRO instanceof ResultReference) {
          ResultReference rr = (ResultReference) currRO;

          // If this ResultReferences references the RP we're deleting, remove it too
          if (rr.getRefRP() == rp) {
            this.removeResultObject(rr);
          }
        }
      }
    }

    // TODO remove this from chart data points, result references
    for (int i = 0; i < this.chartsListModel.getSize(); i++) {
      RamChart rc = (RamChart)this.chartsListModel.get(i);
      
      // Now remove any data points that references this result profile
      List<ChartDataSeries> toRemove = new ArrayList<ChartDataSeries>();
      for (int j = 0; j < ((XYSeriesCollection)rc.getXYPlot().getDataset()).getSeriesCount(); j++) {
        ChartDataSeries cds = (ChartDataSeries)((XYSeriesCollection)rc.getXYPlot().getDataset()).getSeries(i);

        if (cds.getXRP() == rp || cds.getYRP() == rp) {
          toRemove.add(cds);
        }
      }
      for (ChartDataSeries seriesToRemove : toRemove) {
        ((XYSeriesCollection)rc.getXYPlot().getDataset()).removeSeries(seriesToRemove);
      }
    }

    if (!this.resultProfilesListModel.removeElement(rp)) {
      System.err.println("Warning - result profile list size not changed after removal");
    }

    rp.deleteObservers();
    this.notifyObservers();
  }

  public QuestionSetObject getQSOByUUID(UUID uuid) {
    QuestionSetObject qso = null;
    for (Object qsm : this.getModulesListModel().toArray()) {
      qso = ((QuestionSetModule)qsm).getQSOByUUID(uuid);
      
      if (qso != null) break;
    }
    return qso;
  }

  public ResultProfile getRPByUUID(UUID uuid) {
    ResultProfile rp = null;
    for (Object rpEntry : this.getResultProfilesListModel().toArray()) {
      if (((ResultProfile)rpEntry).getUuid().equals(uuid)) {
        rp = (ResultProfile)rpEntry;
        break; // up
      }
    }
    return rp;
  }

  /**
   * This class' task as an Observer is to notify anybody observing it when it
   * receives notice of a change.  Since the only objects this class Observes
   * are a part of its data model (the trees), any changes to those are a change
   * to the RamModel.
   *
   * @param o
   * @param arg
   */
  @Override
  public void update(java.util.Observable o, Object arg) {
    this.notifyObservers();
  }
}
