/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gov.sandia.bioram.classes.model;

import java.awt.Color;
import java.text.NumberFormat;
import gov.sandia.bioram.xml.ObjectFactory;

/**
 *
 * @author danbowe
 */
public class ResultCategory extends ResultObject {
  QuestionSetCategory referenceCategory;

  public ResultCategory(QuestionSetCategory referenceCategory, boolean normalizeChildren) {
    this(referenceCategory.getDefaultWeight(), referenceCategory, normalizeChildren);
  }

  public ResultCategory(Double rawWeight, QuestionSetCategory referenceCategory, boolean normalizeChildren) {
    super(rawWeight, normalizeChildren);
    this.referenceCategory = referenceCategory;

    this.normColor = new Color(80,80,80);
    this.rawColor = new Color(136,136,136);
  }

  @Override
  public String toString() {
    String weightStr = NumberFormat.getInstance().format(this.getWeight());
    return "<html><font color=\"rgb(" +
        this.getColor().getRed() + "," + this.getColor().getGreen() + "," + this.getColor().getBlue() +
        ")\">[" + weightStr + "] " + this.referenceCategory.getUserObject().toString() + "</font></html>";
  }

  @Override
  public void toJAXB(gov.sandia.bioram.xml.ResultMathOpExponent.Children children) {
    ObjectFactory of = new ObjectFactory();
    gov.sandia.bioram.xml.ResultCategory rc = of.createResultCategory();
    rc.setCategoryUUID(this.referenceCategory.getUUID().toString());
    rc.setRawWeight(this.getRawWeight());
    rc.setNormalizeChildren(this.getNormalizeChildren());
    rc.setChildren(of.createResultMathOpExponentChildren());

    children.getResultMathOpAddOrResultMathOpSubtractOrResultMathOpMultiply().add(rc);

    for (int i = 0; i < this.getChildCount(); i++) {
      ResultObject ro = (ResultObject)this.getChildAt(i);

      ro.toJAXB(rc.getChildren());
    }
  }
}
