/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gov.sandia.bioram.classes.model;

import gov.sandia.bioram.classes.model.randomclasses.Bounds;
import gov.sandia.bioram.classes.model.randomclasses.QuestionData;
import java.awt.Color;
import java.text.NumberFormat;
import gov.sandia.bioram.xml.ObjectFactory;

/**
 *
 * @author danbowe
 */
public class QuestionSetQuestion extends QuestionSetObject {
  Color estimateColor = new Color(255, 0, 0); // red
  Color respondedColor = new Color(170,170,170); // gray

  Bounds bounds;
  String detailText;

  public QuestionSetQuestion(String question, String detailText, double defaultWeight, Bounds bounds) {
    super(question);
    this.defaultWeight = defaultWeight;
    this.detailText = (detailText == null) ? "" : detailText;
    this.bounds = bounds;
  }
  
  public void invalidateResponse() {
    ((QuestionSetModule)((QuestionSetRoot)this.getRoot()).getModule()).removeDataItemForUUID(this.getUUID());
  }

  public void setBounds(Bounds bounds) {
    this.bounds = bounds;
  }

  public Bounds getBounds() {
    return this.bounds;
  }

  public void setDetailText(String newText) {
    this.detailText = newText;
  }

  public String getDetailText() {
    return this.detailText;
  }
  
  public void setScore(double newScore) {
    QuestionData qd = new QuestionData(newScore);
    ((QuestionSetModule)((QuestionSetRoot)this.getRoot()).getModule()).putDataItemForUUID(this.getUUID(), qd);
  }

  public double getScore() {
    QuestionData qd = ((QuestionSetModule)((QuestionSetRoot)this.getRoot()).getModule()).getDataItemForUUID(this.getUUID());
    if (qd != null) {
      return qd.score;
    }
    // Only gets to this point if a SavedResponsesHashMap wasn't selected in this question's QuestionSetModule
    return 0; 
  }

  public boolean isResponseProvided() {
    QuestionData qd = ((QuestionSetModule)((QuestionSetRoot)this.getRoot()).getModule()).getDataItemForUUID(this.getUUID());
    return (qd != null);
  }

  public void setEstimate(boolean estimate) {
    QuestionData qd = ((QuestionSetModule)((QuestionSetRoot)this.getRoot()).getModule()).getDataItemForUUID(this.getUUID());
    if (qd != null) {
      qd.isEstimate = estimate;
    }
  }

  public boolean isEstimate() {
    QuestionData qd = ((QuestionSetModule)((QuestionSetRoot)this.getRoot()).getModule()).getDataItemForUUID(this.getUUID());
    return ((qd != null) && (qd.isEstimate));
  }
  
  @Override
  public Color getColor() {
    return (this.isResponseProvided()) ? 
      ((this.isEstimate()) ? this.estimateColor : this.respondedColor) :
      super.getColor();
  }

  @Override
  public String getJListString(int indentSize, int listWidth) {
    int indentWidth = indentSize * this.getLevel();
    int textWidth = listWidth - indentWidth;

    String scoreStr = (this.isResponseProvided()) ? NumberFormat.getInstance().format(this.getScore()) : "";
    String text =
      "<html>" +
      "  <head>" +
      "  <style type=\"text/css\">" +
      "    #indentOffset {" +
      "      width: " + indentWidth + "px;" +
      "      text-align: center;" + 
      "    }" +
      "    #question, #details {" +
      "      color: rgb(" + this.getColor().getRed() + "," + this.getColor().getGreen() + "," + this.getColor().getBlue() + ");" +
      "    }" +
      "    #question {" +
      "      width: " + (textWidth * 0.9 - 175)+ "px;" +  // -175 = Hack to get text alignment
      "    }" +
      "    #details {" +
      "      width: " + (textWidth * 0.8 - 175) + "px;" +
      "      padding-left: 15px;" +
      "      padding-top: 7px;" +
      "    }" +
      "    #container {" +
      "      padding: 5px;" +
      "    }" +
      "  </style>" +
      "  </head><body>" +
      "  <table>" +
      "    <tr>" +
      "      <td id=\"indentOffset\">" + scoreStr + "</td>" +
      "      <td>" +
      "        <div id=\"container\">" +
      "          <div id=\"question\">" + this.getUserObject().toString().replace("\n", "<br/>") + "</div>" +
      (!(this.detailText != null && !this.detailText.trim().isEmpty()) ? "" :
        "          <div id=\"details\">" + this.getDetailText().replace("\n", "<br/>") + "</div>") +
      "        </div>" +
      "      </td>" +
      "    </tr>" +
      "  </table></body>" +
      "</html>";

    return text;
  }

  @Override
  public String toString() {
    String weightStr = NumberFormat.getInstance().format(this.defaultWeight);
    return "<html><font color=\"rgb(0,0,0)\">Q (" + weightStr + ") " + super.toString() + "</font></html>";
  }

  @Override
  public void toJAXB(gov.sandia.bioram.xml.QuestionSetObject.Children children) {
    ObjectFactory of = new ObjectFactory();
    gov.sandia.bioram.xml.QuestionSetQuestion qsq = of.createQuestionSetQuestion();
    qsq.setTitle(this.getTitle());
    qsq.setUuid(this.getUUID().toString());
    qsq.setDefaultWeight(this.getDefaultWeight());
    qsq.setDetailText(this.getDetailText());
    qsq.setChildren(of.createQuestionSetObjectChildren());

    gov.sandia.bioram.xml.QuestionSetQuestion.Bounds bounds = of.createQuestionSetQuestionBounds();
    bounds.setLower(this.getBounds().lower);
    bounds.setUpper(this.getBounds().upper);
    qsq.setBounds(bounds);

    children.getQuestionSetObjectOrQuestionSetQuestionOrQuestionSetCategory().add(qsq);

    for (int i = 0; i < this.getChildCount(); i++) {
      QuestionSetObject qso = (QuestionSetObject)this.getChildAt(i);

      qso.toJAXB(qsq.getChildren());
    }
  }
}
