/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * ResponseForm.java
 *
 * Created on Aug 12, 2011, 11:15:20 AM
 */
package gov.sandia.bioram.forms;

import gov.sandia.bioram.classes.model.randomclasses.SavedResponsesHashMap;
import gov.sandia.bioram.classes.model.RamModel;
import gov.sandia.bioram.classes.model.randomclasses.RamFileFilter;
import gov.sandia.bioram.classes.model.randomclasses.RamFileMarshal;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;
import java.util.Observable;
import java.util.Observer;
import java.util.ResourceBundle;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import org.apache.commons.lang.WordUtils;

/**
 *
 * @author danbowe
 */
public class ResponseForm extends javax.swing.JFrame implements Observer {

  public static final int ListIndentSize = 20;
  private RamModel model;

  public ResponseForm() {
    this(null);
  }

  /**
   * Creates a new ResponseForm using an existing RamModel.  This is used by the
   * ProfileEditorForm to pass in the already-active model.
   * @param model
   */
  public ResponseForm(RamModel model) {
    initComponents();
    this.initLocaleMenu();

    if (model == null) {
      // Look for a model
      for (File f : new File(".").listFiles()) {
        if (f.getName().endsWith(".raml")) {
          model = this.loadModelFromFile(f);
          break;
        }
      }
      // ...but for testing...
//      File f = new File("C:/Users/danbowe/Documents/testModel.raml");
//      if (f.exists()) {
//        model = this.loadModelFromFile(f);
//      }
    }

    this.setModel((model != null) ? model : new RamModel());
    this.setLocationRelativeTo(null);
  }

  /**
   * When the names are entered into the prelim info text boxes, when are they saved to the
   * underlying RamModel?  This method is used to do that and it's done on
   * response saves, editor mode switches, and report creation.
   */
  private void savePrelimInfoNamesAndProcedure() {
    this.model.setNames(this.preliminaryInformationPanel1.getNames());
    this.model.setProcedure(this.preliminaryInformationPanel1.getProcedure());
  }

  /**
   * Undefined behavior for null models
   */
  private void setModel(RamModel model) {
    this.model = model;
    this.model.addObserver(this);

    this.enterDataPanel1.setModel(model);
    this.viewResultsPanel1.setModel(model);
    this.modelStructurePanel1.setModel(model);

    // Set the preliminary information panel's data
    this.preliminaryInformationPanel1.setFrontImage(this.model.getFrontImage());
    this.preliminaryInformationPanel1.setFrontHTMLText(this.model.getFrontHTMLText());
    this.preliminaryInformationPanel1.setNames(this.model.getNames());
    this.preliminaryInformationPanel1.setProcedure(this.model.getProcedure());
  }

  /**
   * This looks in the standard package where I'm keeping properties files
   * (gov.sandia.bioram.resources) and checks which locales are available
   *
   * @return
   */
  public String[] getOtherAvailableLocales(String bundleName) {
//    List<String> localeList = new ArrayList<String>();
//    localeList.add("en"); // Add the default
//
//    try {
//      for (String f : RamFileMarshal.getResourceListing(ResponseForm.class, "")) {
//        String filename = new File(f).getName();
//        String localeName = filename.replaceAll(bundleName + "_(..).properties", "$1");
//
//        if (!localeName.equals(filename)) {
//          localeList.add(localeName);
//        }
//      }
//    } catch (Exception e) {
//      e.printStackTrace();
//    }

    //return localeList;
    // An awful hack to bypass trying to figure out classpath/JAR-resource scanning issues
    // that came from trying to dynamically figure this out, based on the extensions
    // of the property files.  Since JAR files aren't recognized by the file system,
    // it got hairy trying to read its files in the same way you would on a FS.
    return new String[] { "en", "de", "es", "fr", "it", "nl", "pt", "ar", "ja", "zh", "ru" };
  }

  private void initLocaleMenu() {
    for (String locale : this.getOtherAvailableLocales("lang/FormStrings")) {
      Locale currLocale = new Locale(locale);
      JMenuItem localeMenuItem = new JMenuItem(WordUtils.capitalize(currLocale.getDisplayName(currLocale)));
      localeMenuItem.getModel().setActionCommand(locale);
      localeMenuItem.addActionListener(new ActionListener() {

        /**
         * It is assumed that this actionPerformed will be returned on the same
         * computer that generated the actionCommand index, thus the indices
         * will match, even after regenerating the locales.
         */
        @Override
        public void actionPerformed(ActionEvent evt) {
          ResponseForm.this.savePrelimInfoNamesAndProcedure();

          String conf = ResourceBundle.getBundle("lang/FormStrings").getString("ResponseForm_ReloadLocale");
          if (JOptionPane.showConfirmDialog(ResponseForm.this, conf) == JOptionPane.YES_OPTION) {
            Locale newLocale = new Locale(evt.getActionCommand());
            Locale.setDefault(newLocale);

            String num = NumberFormat.getInstance().format(123215243.3352);
            System.out.println("Setting locale to " + newLocale + ", Number = " + num);
            new Thread(new ResponseFormReloader(ResponseForm.this.model, ResponseForm.this)).start();
          }
        }
      });

      this.localeMenu.add(localeMenuItem);
    }
  }

  /**
   * Loads either the XStream models (for now, soon to be @deprecated), or the
   * ramML style
   * @param fp
   * @return
   */
  public RamModel loadModelFromFile(File fp) {
    try {
//        XStream x = new XStream(new DomDriver());
//        return (RamModel) x.fromXML(fp);
      RamFileMarshal marshal = new RamFileMarshal(fp);
      return marshal.getRamModel();
    } catch (Exception e) {
      e.printStackTrace();
      String message = ResourceBundle.getBundle("lang/FormStrings").getString("FileOpenWarning");
      JOptionPane.showMessageDialog(this, message);
    }
    return new RamModel(); // An exception was caught.
  }

  
  /** This method is called from within the constructor to
   * initialize the form.
   * WARNING: Do NOT modify this code. The content of this method is
   * always regenerated by the Form Editor.
   */
  @SuppressWarnings("unchecked")
  // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
  private void initComponents() {

    tabbedPane = new javax.swing.JTabbedPane();
    preliminaryInformationPanel1 = new gov.sandia.bioram.forms.viewControllers.PreliminaryInformationPanel();
    enterDataPanel1 = new gov.sandia.bioram.forms.viewControllers.EnterDataPanel();
    viewResultsPanel1 = new gov.sandia.bioram.forms.viewControllers.ViewResultsPanel();
    modelStructurePanel1 = new gov.sandia.bioram.forms.viewControllers.ModelStructurePanel();
    jMenuBar1 = new javax.swing.JMenuBar();
    jMenu1 = new javax.swing.JMenu();
    openProfileMenuItem = new javax.swing.JMenuItem();
    loadResponsesMenuItem = new javax.swing.JMenuItem();
    saveResponsesMenuItem = new javax.swing.JMenuItem();
    createReportMenuItem = new javax.swing.JMenuItem();
    jSeparator1 = new javax.swing.JPopupMenu.Separator();
    switchModesMenuItem = new javax.swing.JMenuItem();
    exitMenuItem = new javax.swing.JMenuItem();
    jMenu2 = new javax.swing.JMenu();
    localeMenu = new javax.swing.JMenu();

    setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
    java.util.ResourceBundle bundle = java.util.ResourceBundle.getBundle("lang/FormStrings"); // NOI18N
    setTitle(bundle.getString("RiskAssessmentModel")); // NOI18N
    setIconImage(new ImageIcon("Resources/IBTRLogoSmall.png").getImage());
    setMinimumSize(new java.awt.Dimension(600, 259));

    tabbedPane.addTab(bundle.getString("PreliminaryInformationPanel_Title"), preliminaryInformationPanel1); // NOI18N
    tabbedPane.addTab(bundle.getString("EnterData"), enterDataPanel1); // NOI18N
    tabbedPane.addTab(bundle.getString("ViewResults"), viewResultsPanel1); // NOI18N
    tabbedPane.addTab(bundle.getString("ModelDetail"), modelStructurePanel1); // NOI18N

    getContentPane().add(tabbedPane, java.awt.BorderLayout.CENTER);

    jMenu1.setText(bundle.getString("File")); // NOI18N

    openProfileMenuItem.setText(bundle.getString("OpenProfile")); // NOI18N
    openProfileMenuItem.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        openProfileMenuItemActionPerformed(evt);
      }
    });
    jMenu1.add(openProfileMenuItem);

    loadResponsesMenuItem.setText(bundle.getString("ResponseForm_LoadResponses")); // NOI18N
    loadResponsesMenuItem.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        loadResponsesMenuItemActionPerformed(evt);
      }
    });
    jMenu1.add(loadResponsesMenuItem);

    saveResponsesMenuItem.setText(bundle.getString("ResponseForm_SaveResponses")); // NOI18N
    saveResponsesMenuItem.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        saveResponsesMenuItemActionPerformed(evt);
      }
    });
    jMenu1.add(saveResponsesMenuItem);

    createReportMenuItem.setText(bundle.getString("ResponseForm_CreateReport")); // NOI18N
    createReportMenuItem.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        createReportMenuItemActionPerformed(evt);
      }
    });
    jMenu1.add(createReportMenuItem);
    jMenu1.add(jSeparator1);

    switchModesMenuItem.setText(bundle.getString("SwitchToProfileEditorMode")); // NOI18N
    switchModesMenuItem.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        switchModesMenuItemActionPerformed(evt);
      }
    });
    jMenu1.add(switchModesMenuItem);

    exitMenuItem.setText(bundle.getString("Exit")); // NOI18N
    exitMenuItem.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        exitMenuItemActionPerformed(evt);
      }
    });
    jMenu1.add(exitMenuItem);

    jMenuBar1.add(jMenu1);

    jMenu2.setText(bundle.getString("ResponseForm_SettingsMenu")); // NOI18N

    localeMenu.setText(bundle.getString("ResponseForm_SettingsMenuLocale")); // NOI18N
    jMenu2.add(localeMenu);

    jMenuBar1.add(jMenu2);

    setJMenuBar(jMenuBar1);

    pack();
  }// </editor-fold>//GEN-END:initComponents

  private void switchModesMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_switchModesMenuItemActionPerformed
    this.savePrelimInfoNamesAndProcedure();
    this.model.deleteObserver(this); // ...in hopes that this ResponseForm will be GC'd
    new ProfileEditorForm(this.model).setVisible(true);
    this.dispose();
  }//GEN-LAST:event_switchModesMenuItemActionPerformed

  private void openProfileMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openProfileMenuItemActionPerformed
    JFileChooser jfc = new JFileChooser();
    jfc.setFileFilter(new RamFileFilter());
    if (jfc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
      this.setModel(this.loadModelFromFile(jfc.getSelectedFile()));
    }
  }//GEN-LAST:event_openProfileMenuItemActionPerformed

  private void exitMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitMenuItemActionPerformed
    System.exit(0);
  }//GEN-LAST:event_exitMenuItemActionPerformed


  /**
   * Tabbed pane 1: (view results) creates the tree model, selects the first three
   * items in each list, expands all nodes.
   * @param evt
   */      
  private void loadResponsesMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadResponsesMenuItemActionPerformed
    JFileChooser jfc = new JFileChooser();
    jfc.setFileFilter(new RamFileFilter());
    if (jfc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
      try {
        RamFileMarshal.addResponsesToModel(model, jfc.getSelectedFile());

        // Now the model has updated names/procedures...display them, unless they're empty
        if (model.getNames() != null && !model.getNames().isEmpty()) {
          this.preliminaryInformationPanel1.setNames(model.getNames());
        }
        if (model.getProcedure() != null && !model.getProcedure().isEmpty()) {
          this.preliminaryInformationPanel1.setProcedure(model.getProcedure());
        }
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
  }//GEN-LAST:event_loadResponsesMenuItemActionPerformed

  private void saveResponsesMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveResponsesMenuItemActionPerformed
    JFileChooser jfc = new JFileChooser();
    jfc.setFileFilter(new RamFileFilter());
    if (jfc.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
      this.savePrelimInfoNamesAndProcedure();
      try {
        File fp = jfc.getSelectedFile();

        if (!fp.getName().endsWith(".raml")) {
          fp = new File(fp.getAbsolutePath() + ".raml");
        }
        RamFileMarshal.writeResponsesToJAXB(this.model, fp);
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
  }//GEN-LAST:event_saveResponsesMenuItemActionPerformed

  private void createReportMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createReportMenuItemActionPerformed
    this.savePrelimInfoNamesAndProcedure();

    // Box up the selected responses and open the dialog
    List<SavedResponsesHashMap> selectedResponses = this.viewResultsPanel1.getSelectedResponseSets();
    GenerateReportDialog grd = new GenerateReportDialog(this, model, selectedResponses, true);
    grd.setVisible(true);

    // Now make sure the selected data points in that list in the ViewResultsPanel align with what's being plotted
    this.viewResultsPanel1.replotSelectedDataPoints();
  }//GEN-LAST:event_createReportMenuItemActionPerformed

  // Variables declaration - do not modify//GEN-BEGIN:variables
  private javax.swing.JMenuItem createReportMenuItem;
  private gov.sandia.bioram.forms.viewControllers.EnterDataPanel enterDataPanel1;
  private javax.swing.JMenuItem exitMenuItem;
  private javax.swing.JMenu jMenu1;
  private javax.swing.JMenu jMenu2;
  private javax.swing.JMenuBar jMenuBar1;
  private javax.swing.JPopupMenu.Separator jSeparator1;
  private javax.swing.JMenuItem loadResponsesMenuItem;
  private javax.swing.JMenu localeMenu;
  private gov.sandia.bioram.forms.viewControllers.ModelStructurePanel modelStructurePanel1;
  private javax.swing.JMenuItem openProfileMenuItem;
  private gov.sandia.bioram.forms.viewControllers.PreliminaryInformationPanel preliminaryInformationPanel1;
  private javax.swing.JMenuItem saveResponsesMenuItem;
  private javax.swing.JMenuItem switchModesMenuItem;
  private javax.swing.JTabbedPane tabbedPane;
  private gov.sandia.bioram.forms.viewControllers.ViewResultsPanel viewResultsPanel1;
  // End of variables declaration//GEN-END:variables

  @Override
  public void update(Observable o, Object arg) {
    System.out.println("Model changed! " + System.currentTimeMillis());
    // Reset everything in here - our model has changed
    this.viewResultsPanel1.setModel(this.model);
  }
}

/**
 * The purpose of this class is to reload the ResponseForm when a Locale 
 * change occurs.  Since this change requires all strings to be reloaded, it's
 * easiest to just reload all items.  It also needs to happen on a different
 * thread than the event-handling event dispatch thread.
 * 
 * @author danbowe
 */
class ResponseFormReloader implements Runnable {
  private RamModel model;
  private ResponseForm currentResponseForm;

  public ResponseFormReloader(RamModel model, ResponseForm currentResponseForm) {
    this.model = model;
    this.currentResponseForm = currentResponseForm;
  }

  @Override
  public void run() {
    currentResponseForm.dispose();
    new ResponseForm(model).setVisible(true);
  }
}