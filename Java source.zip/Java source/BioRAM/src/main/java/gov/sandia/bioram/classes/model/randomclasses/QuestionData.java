/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gov.sandia.bioram.classes.model.randomclasses;

import java.io.Serializable;

/**
 *
 * @author danbowe
 */
public class QuestionData implements Serializable {

  public double score;
  public boolean isEstimate;

  public QuestionData(double score) {
    this.score = score;
    this.isEstimate = false;
  }
}
