/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gov.sandia.bioram.forms.dnd;

import gov.sandia.bioram.classes.model.QuestionSetCategory;
import gov.sandia.bioram.classes.model.QuestionSetModule;
import gov.sandia.bioram.classes.model.QuestionSetObject;
import gov.sandia.bioram.classes.model.QuestionSetQuestion;
import gov.sandia.bioram.classes.model.ResultCategory;
import gov.sandia.bioram.classes.model.ResultMathOpConstant;
import gov.sandia.bioram.classes.model.ResultObject;
import gov.sandia.bioram.classes.model.ResultProfile;
import gov.sandia.bioram.classes.model.ResultQuestion;
import gov.sandia.bioram.classes.model.ResultReference;
import gov.sandia.bioram.forms.ProfileEditorForm.TreeType;
import java.util.Enumeration;
import java.util.LinkedList;
import javax.swing.JTree;
import javax.swing.TransferHandler;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;

/**
 *
 * @author danbowe
 */
public class ResultProfileTreeTransferHandler extends TreeTransferHandler {
  QuestionSetModule currModule;
  TreeUpdateable treeUpdateable;

  public ResultProfileTreeTransferHandler(QuestionSetModule currModule, ResultProfile rp, TreeUpdateable treeUpdateable) {
    super(rp, TreeType.ResultProfile);

    this.currModule = currModule;
    this.treeUpdateable = treeUpdateable;
  }

  @Override
  public boolean canImport(TransferHandler.TransferSupport ts) {
    try {
      TransferableTreePaths t = (TransferableTreePaths)ts.getTransferable().getTransferData(TransferableTreePaths.objFlavor);
      TreePath dropPath = ((JTree.DropLocation)ts.getDropLocation()).getPath();

      return (dropPath == null) ? true : 
        (!(dropPath.getLastPathComponent() instanceof ResultQuestion) &&
         !(dropPath.getLastPathComponent() instanceof ResultReference) &&
         !(dropPath.getLastPathComponent() instanceof ResultMathOpConstant));
    } catch (Exception e) {
      System.err.println(e.getMessage());
    }
    return false;
  }

  // TODO finish this hierarchy-saving dnd implementation
  // May need to make my own bfs implementation if this doesn't include the leaf nodes
  void bfsCreatePartialModule(ResultObject currParent, LinkedList<QuestionSetObject> selectedQS) {
    Enumeration e = ((DefaultMutableTreeNode)this.currModule.getRoot()).breadthFirstEnumeration();

    for (QuestionSetObject currQS = (QuestionSetObject)e.nextElement(); e.hasMoreElements(); currQS = (QuestionSetObject)e.nextElement()) {
      for (QuestionSetObject checkListQS : selectedQS) {
        if (currQS == checkListQS) {

        }
      }
    }


//        for (QuestionSetObject currQSO : selectedQS) {
//
//      ResultObject newChild;
//      if (currQSO instanceof QuestionSetQuestion) {
//        newChild = new ResultQuestion((QuestionSetQuestion)currQSO);
//      } else if (currQSO instanceof QuestionSetCategory) {
//        newChild = new ResultCategory((QuestionSetCategory)currQSO);
//      }
//
//      QuestionSetObject testParent = currQSO;
//      while (testParent.getParent() != null) {
//        if (selectedQS.contains(testParent)) {
//
//        }
//        testParent = (QuestionSetObject)testParent.getParent();
//      }
//
//    }
  }

  @Override
  public boolean importData(TransferHandler.TransferSupport ts) {
    if (this.canImport(ts)) {
      try {
        TransferableTreePaths t = (TransferableTreePaths)ts.getTransferable().getTransferData(TransferableTreePaths.objFlavor);
        TreePath[] treePaths = t.getTreePaths();
        TreePath dropPath = ((JTree.DropLocation)ts.getDropLocation()).getPath();

        // ADDING QUESTIONS/CATEGORIES TO A RESULT PROFILE
        if ((t.getOriginatingTree() == TreeType.QuestionSet) && (this.currModule != null)) {
          DefaultMutableTreeNode nodeTo;
          if (dropPath == null) {
            nodeTo = (DefaultMutableTreeNode)((JTree)ts.getComponent()).getModel().getRoot();
          } else {
            nodeTo = (DefaultMutableTreeNode)dropPath.getLastPathComponent();
          }

//
//          // Obtain a list of the selected nodes
//          LinkedList<QuestionSetObject> selectedQS = new LinkedList<QuestionSetObject>();
//          for (TreePath currPath : treePaths) {
//            selectedQS.add((QuestionSetObject)currModule.getNodeByUUID(currPath.getLastPathComponent()));
//          }
//          
//          // Search the entire Modules list for these items and create the hierarchy
//
          
          for (TreePath currPath : treePaths) {
            DefaultMutableTreeNode nodeFrom = currModule.getNodeByUUID(currPath.getLastPathComponent());
            if (nodeFrom instanceof QuestionSetQuestion) {
              nodeTo.add(new ResultQuestion((QuestionSetQuestion)nodeFrom));
            } else if (nodeFrom instanceof QuestionSetCategory) {
              ResultCategory rc = new ResultCategory((QuestionSetCategory)nodeFrom, true);
              nodeTo.add(rc);
              rc.setNormalizeChildren(true);
            }
          }
          ((ResultObject)nodeTo).setNormalizeChildren(true);  // By default, normalize after adding
          this.treeUpdateable.updateResultProfileTree();

        // REARRANGING A RESULT PROFILE
        } else if ((t.getOriginatingTree() == TreeType.ResultProfile) && (this.treeUpdateable != null)) {
          boolean importSuccessful = super.importData(ts);
          if (importSuccessful) {
            this.treeUpdateable.updateResultProfileTree();
            return importSuccessful;
          }
        }
      } catch (Exception e) {
        System.err.println(e.getMessage());
      }
    }

    return false;
  }
}