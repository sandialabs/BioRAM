/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gov.sandia.bioram.classes.model.randomclasses;

import gov.sandia.bioram.forms.viewControllers.ModelStructurePanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.LayoutManager;
import java.awt.Rectangle;
import java.io.File;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;
import java.util.ResourceBundle;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;

/**
 *
 * @author danbowe
 */
/**
 * ...so we can get our renderers to figure classes out
 */
public class BackgroundGraphTable extends AbstractTableModel {

  public static class ResponseHashMapTableCellRenderer extends DefaultTableCellRenderer {
    private static Color errorColor = new Color(255, 0, 0);
    private static Color responseColor = new Color(0, 138, 168);

    /**
     * Note that nullStr is really just a cached copy of the ResourceBundle's
     * copy.  It's cached here instead of just calling getString() on the resource
     * since this string is frequently-called method.
     */
    private static Locale currentLocale = Locale.getDefault();
    private static String nullStr = null;

    // TODO: put the bars to the side of the number

    @Override
    public Component getTableCellRendererComponent(
            JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
      JPanel panel = new JPanel(new BorderLayout());
      JLabel j = new JLabel(ResponseHashMapTableCellRenderer.getText(value));
      j.setForeground(ResponseHashMapTableCellRenderer.getTextColor(value));
      j.setHorizontalAlignment(JLabel.CENTER);
      panel.add(j);
      panel.setBackground(isSelected ? table.getSelectionBackground() : table.getBackground());
      return panel;
    }

    public static Color getTextColor(Object value) {
      return (value != null) ? ResponseHashMapTableCellRenderer.responseColor : ResponseHashMapTableCellRenderer.errorColor;
    }

    /**
     * Provides a default null string if there's no object
     *
     * @param value
     * @return
     */
    public static String getText(Object value) {
      if (!currentLocale.equals(Locale.getDefault()) || nullStr == null) {
        currentLocale = Locale.getDefault();
        nullStr = ResourceBundle.getBundle("lang/FormStrings").getString("NoneSelected");
      }
      return (value != null) ? value.toString() : nullStr;
    }
  }

  public class DoubleGraphTableCellRenderer extends DefaultTableCellRenderer {

    /**
     * Creates a JPanel that also renders a bar graph in the background
     */
    public class GraphPanel extends JPanel {

      private Color graphColor = new Color(235, 235, 235); // light gray
      int padding = 3;

      public GraphPanel(LayoutManager layout) {
        super(layout);
      }

      @Override
      public void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2d = (Graphics2D) g;
        Rectangle bounds = g2d.getClipBounds();
        Color oldColor = g2d.getColor();

        int graphWidth = (int) (columnWidth * currValue.doubleValue() / maxValue.doubleValue() - 2 * this.padding);
        if (graphWidth > 0) {
          g2d.setColor(this.graphColor);
          g2d.fillRect(bounds.x + this.padding, bounds.y + this.padding, graphWidth, bounds.height - 2 * this.padding);
          g2d.setColor(oldColor);
        }
        // System.out.println("paint component");
      }

      @Override
      public void paintImmediately(Rectangle r) {
        super.paintImmediately(r);
        System.out.println("paintImmediately");
      }

      @Override
      public void paintImmediately(int x, int y, int w, int h) {
        super.paintImmediately(x, y, w, h);
        System.out.println("paintImmediately xy");
      }

      @Override
      public void paint(Graphics g) {
        super.paint(g);
        // System.out.println("paint");
      }

      @Override
      public void repaint(Rectangle r) {
        super.repaint(r);
        System.out.println(String.format("Repaint r, x: %d, y: %d, w: %d, h: %d",
                r.x, r.y, r.width, r.height));
      }

      @Override
      public void repaint(long tm) {
        super.repaint(tm);
//        System.out.println("repaint tm");
      }

      @Override
      public void repaint(int x, int y, int w, int h) {
        super.repaint(x, y, w, h);
//        System.out.println("repaint xy");
      }

      @Override
      public void repaint(long tm, int x, int y, int width, int height) {
        super.repaint(tm, x, y, width, height);
//        System.out.println("repaint tm xy wh");
      }
    }
    Double currValue;  // ...so I can get the current value
    Double maxValue;   // ...so I can compare currObject's value to maxValue
    int columnWidth;

    @Override
    public Component getTableCellRendererComponent(
            JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
      column = table.convertColumnIndexToModel(column);
      row = table.convertRowIndexToModel(row);
      if ((value instanceof Double) && (this.maxValue = getLargestInColumn(column)) != null) {
        this.currValue = (Double) value;
        this.columnWidth = table.getColumnModel().getColumn(column).getWidth();

        JPanel bgPanel = this.new GraphPanel(new BorderLayout());

        bgPanel.setBackground(isSelected ? table.getSelectionBackground() : table.getBackground());

        // We get a strange NaN character, so just put "NaN" instead
        String numberString = "";
        if (value.equals(Double.NaN)) {
          numberString = value.toString();
        } else {
          numberString = NumberFormat.getInstance().format(value);
        }

        JLabel scoreLabel = new JLabel(numberString);
        scoreLabel.setHorizontalAlignment(JLabel.CENTER);
        bgPanel.add(scoreLabel, BorderLayout.CENTER);

        return bgPanel;
      }
      return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
    }
  }

  // Table ramModel begins
  ArrayList<ArrayList<?>> tableModel;
  ArrayList<Double> largestValueInColumn;
  ArrayList<Class> columnClasses;
  ArrayList<String> columnNames;

  public BackgroundGraphTable() {
    this.tableModel = new ArrayList<ArrayList<?>>();
    this.columnNames = new ArrayList<String>();
    this.largestValueInColumn = new ArrayList<Double>();
    this.columnClasses = new ArrayList<Class>();
  }

  public Double getLargestInColumn(int column) {
    if (column < this.getColumnCount()) {
      return this.largestValueInColumn.get(column);
    }
    return null;
  }

  @Override
  public String getColumnName(int column) {
    return (column < this.getColumnCount()) ? this.columnNames.get(column) : super.getColumnName(column);
  }

  @Override
  public int getRowCount() {
    return this.tableModel.size();
  }

  @Override
  public int getColumnCount() {
    // This assumes all rows are the same size as the first
    return (this.tableModel.size() > 0) ? this.tableModel.get(0).size() : 0;
  }

  @Override
  public Object getValueAt(int row, int column) {
    return this.tableModel.get(row).get(column);
  }

  @Override
  public final Class<?> getColumnClass(int columnIndex) {
    return this.columnClasses.get(columnIndex);
  }
}


class BackgroundGraphTester {

  public static void main(String args[]) {
    final JFrame frame = new JFrame("Main Window");
    
    ModelStructurePanel msp = new ModelStructurePanel();
    try {
      msp.setModel(new RamFileMarshal(new File("C:/Users/danbowe/Documents/testModel.raml")).getRamModel());
    } catch (IOException e) {
      e.printStackTrace();
    }
    frame.add(msp);

    frame.setPreferredSize(new Dimension(600, 600));
    frame.pack();
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setLocationRelativeTo(null);
    frame.setVisible(true);
  }
}
