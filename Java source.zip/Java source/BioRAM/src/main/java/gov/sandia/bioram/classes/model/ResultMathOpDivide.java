/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gov.sandia.bioram.classes.model;

import java.awt.Color;
import gov.sandia.bioram.xml.ObjectFactory;

/**
 *
 * @author danbowe
 */
public class ResultMathOpDivide extends ResultMathOp {
  public ResultMathOpDivide(double rawWeight, String title, boolean normalizeChildren) {
    super(rawWeight, title, normalizeChildren);
    this.mathOpTypeKey = "Divide";
  }
  
  @Override
  public double getScore() {
    if (this.getChildCount() == 2) {
      double numerator = ((ResultObject)this.getChildAt(0)).getScore();
      double denominator = ((ResultObject)this.getChildAt(1)).getScore();
      
      //denominator = (denominator == 0) ? 1 : denominator;
      
      return ((numerator/denominator) * this.getWeight());
    } else {
      return super.getScore();
    }
  }

  @Override
  public Color getColor() {
    return (this.children != null && this.children.size() != 2) ? this.errorColor : super.getColor();
  }

  @Override
  public void toJAXB(gov.sandia.bioram.xml.ResultMathOpExponent.Children children) {
    ObjectFactory of = new ObjectFactory();
    gov.sandia.bioram.xml.ResultMathOpDivide rmod = of.createResultMathOpDivide();
    rmod.setTitle(this.getTitle());
    rmod.setRawWeight(this.getRawWeight());
    rmod.setNormalizeChildren(this.getNormalizeChildren());
    rmod.setChildren(of.createResultMathOpExponentChildren());

    children.getResultMathOpAddOrResultMathOpSubtractOrResultMathOpMultiply().add(rmod);

    for (int i = 0; i < this.getChildCount(); i++) {
      ResultObject ro = (ResultObject)this.getChildAt(i);

      ro.toJAXB(rmod.getChildren());
    }
  }
}
