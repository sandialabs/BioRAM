/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gov.sandia.bioram.classes.model.randomclasses;

import java.io.File;
import javax.swing.filechooser.FileFilter;

/**
 *
 * @author danbowe
 */
public class RamFileFilter extends FileFilter {
  public static class CSVFileFilter extends FileFilter {

    @Override
    public boolean accept(File fp) {
      return fp.getName().endsWith(".csv") || fp.isDirectory();
    }

    @Override
    public String getDescription() {
      return "CSV Files (*.csv)";
    }
  }

  public static class ImageFileFilter extends FileFilter {

    @Override
    public boolean accept(File fp) {
      return fp.getName().matches(".*(png|bmp|jpg|jpeg)$") || fp.isDirectory();
    }

    @Override
    public String getDescription() {
      return "Images (png|bmp|jpg|jpeg)";
    }

  }

  @Override
  public boolean accept(File fp) {
    return fp.getName().matches(".*\\.(raml|zip)$") || fp.isDirectory();
  }

  @Override
  public String getDescription() {
    return "RAM Files (*.raml)";
  }
}


