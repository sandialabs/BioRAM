/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gov.sandia.bioram.classes.model;

import java.text.NumberFormat;
import gov.sandia.bioram.xml.ObjectFactory;

/**
 *
 * @author danbowe
 */
public class ResultMathOpExponent extends ResultMathOpAdd {
  double exponent;

  public ResultMathOpExponent(double rawWeight, String title, double exponent, boolean normalizeChildren) {
    super(rawWeight, title, normalizeChildren);
    this.exponent = exponent;
    this.mathOpTypeKey = "Exponent";
    
    String constStr = NumberFormat.getInstance().format(this.exponent);
    this.extraToStringInfo = ", ^" + constStr;
  }

  @Override
  public double getScore() {
    double tempScore = 0, eps = 1e-6;
    for (int i = 0; i < this.getChildCount(); i++) {
      tempScore += ((ResultObject)this.getChildAt(i)).getScore();
    }
    // This is for floating point error.  When I sum scores very close to zero,
    // I sometimes get an extremely small (1e-16 order) negative number instead
    // of zero.  This corrects that.
    if (tempScore < 0 && tempScore > -eps) {
      tempScore = 0.0;
    }

    double retVal = (Math.pow(tempScore, this.exponent) * this.getWeight());
    return retVal;
  }

  public double getExponent() {
    return this.exponent;
  }

  @Override
  public void toJAXB(gov.sandia.bioram.xml.ResultMathOpExponent.Children children) {
    ObjectFactory of = new ObjectFactory();
    gov.sandia.bioram.xml.ResultMathOpExponent rmoe = of.createResultMathOpExponent();
    rmoe.setTitle(this.getTitle());
    rmoe.setRawWeight(this.getRawWeight());
    rmoe.setNormalizeChildren(this.getNormalizeChildren());
    rmoe.setExponent(this.getExponent());
    rmoe.setChildren(of.createResultMathOpExponentChildren());

    children.getResultMathOpAddOrResultMathOpSubtractOrResultMathOpMultiply().add(rmoe);

    for (int i = 0; i < this.getChildCount(); i++) {
      ResultObject ro = (ResultObject)this.getChildAt(i);

      ro.toJAXB(rmoe.getChildren());
    }
  }
}
