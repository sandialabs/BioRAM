/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gov.sandia.bioram.classes.model.randomclasses;

import gov.sandia.bioram.classes.model.QuestionSetModule;
import gov.sandia.bioram.classes.model.RamModel;
import gov.sandia.bioram.classes.model.ResultProfile;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.table.AbstractTableModel;
import javax.swing.tree.DefaultMutableTreeNode;

/**
 * This is basically a 2D array of results calculated based on which response
 * sets have been selected.  Its data is used to display the tabulated and graphed
 * portions of the results.
 *
 * This creates a TableModel that has SavedResponsesHashMaps for each Module column
 * and Doubles for each Result Profile column, depicting that RP's score for that
 * row's combination of Response Sets.
 * @author danbowe
 */
public class RamDataTable extends AbstractTableModel {

  ArrayList<ArrayList<?>> tableModel;
  /**
   * columnObjects returns the actual object (not just the class) that each
   * column represents (such as the actual Module or Result Profile).
   */
  ArrayList<Object> columnObjects;

  public RamDataTable(RamModel model, List<SavedResponsesHashMap> selectedResponses) {
    this.tableModel = new ArrayList<ArrayList<?>>();
    this.columnObjects = new ArrayList<Object>();

    // Module column titles are reversed so they match the backwards tree traversal in addDataToTableModel
//    for (int i = model.getModulesListModel().getSize() - 1; i >= 0; i--) {
//      this.columnObjects.add(model.getModulesListModel().get(i));
//    }
    this.columnObjects.addAll(Arrays.asList(model.getModulesListModel().toArray()));
    this.columnObjects.addAll(Arrays.asList(model.getResultProfilesListModel().toArray()));

    // Create the tree where leaf nodes' paths to parent are all the selected selections
    ModuleCombinationCalculationNode root = new ModuleCombinationCalculationNode(null, null);
    this.addToTree(root, model.getModulesListModel(), 0, selectedResponses);
    this.addDataToTableModel(root, model);
  }

  /**
   * Recursively traverse that tree created by addToTree and add data rows to the model
   * @param currNode
   * @param model
   */
  private void addDataToTableModel(ModuleCombinationCalculationNode currNode, RamModel model) {
    if (currNode.getChildCount() == 0) {
      ArrayList<Object> newRow = new ArrayList<Object>();

      // Until I reach the root node, go up the tree and set each module to its saved response
      ArrayList<SavedResponsesHashMap> sr = new ArrayList<SavedResponsesHashMap>();
      for (; currNode.module != null; currNode = (ModuleCombinationCalculationNode) currNode.getParent()) {
        currNode.module.getSavedResponseComboBoxModel().setSelectedItem(currNode.savedResponses);
        sr.add(currNode.savedResponses);
      }
      Collections.reverse(sr); // Traversing up the tree gets us in the reverse order that we want.
      newRow.addAll(sr);
      for (int i = 0; i < model.getResultProfilesListModel().getSize(); i++) {
        double score = ((ResultProfile) model.getResultProfilesListModel().get(i)).getCurrentScore(true);
        newRow.add(new Double(score));
      }
      this.tableModel.add(newRow);
    } else {
      for (int i = 0; i < currNode.getChildCount(); i++) {
        this.addDataToTableModel((ModuleCombinationCalculationNode) currNode.getChildAt(i), model);
      }
    }
  }

  /**
   * Represents a node in the tree of calculating all possible combinations of RPs, which
   * contains a module and the response set it should use for calculation
   */
  public static class ModuleCombinationCalculationNode extends DefaultMutableTreeNode {

    public QuestionSetModule module;
    public SavedResponsesHashMap savedResponses;

    public ModuleCombinationCalculationNode(QuestionSetModule module, SavedResponsesHashMap savedResponses) {
      this.module = module;
      this.savedResponses = savedResponses;
    }
  }

  /**
   * Recursively create this calculation tree.  The leaf nodes' parental history tells which response sets for
   * each module should be enabled for that calculation.  Each leaf node represents a row in the modulesResponsesTable.
   * - Make sure the current module is not the last
   * @param currNode initially passed a root ModuleCombinationCalculationNode with null modules and responses
   * @param modules list of modules
   * @param iModules the current module index (for modules).  This gets incremented after each level, starts at 0
   * @param selections a list of selected SavedResponsesHashMaps
   */
  private void addToTree(ModuleCombinationCalculationNode currNode, DefaultListModel modules,
          int iModules, List<SavedResponsesHashMap> selections) {
    //DefaultListModel modules = this.getModulesListModel();
    // Continue recursing until you get to the end of the modules.
    if (iModules < modules.getSize()) {
      QuestionSetModule currModule = (QuestionSetModule) modules.get(iModules);

      // Loop through all saved responses in this module
      for (int i = 0; i < currModule.getSavedResponseComboBoxModel().getSize(); i++) {
        SavedResponsesHashMap currMap = (SavedResponsesHashMap) currModule.getSavedResponseComboBoxModel().getElementAt(i);

        if (selections.contains(currMap)) {
          ModuleCombinationCalculationNode newChild = new ModuleCombinationCalculationNode(currModule, currMap);
          currNode.add(newChild);
          this.addToTree(newChild, modules, iModules + 1, selections);
        }
      }
      // Either nothing was selected, or there were no SavedResponsesHashMaps.  Use a default [null] map (0 for all questions)
      if (currNode.getChildCount() == 0) {
        ModuleCombinationCalculationNode newChild = new ModuleCombinationCalculationNode(currModule, null);
        currNode.add(newChild);
        this.addToTree(newChild, modules, iModules + 1, selections);
      }
    }
  }

  public Object getObjectForColumn(int column) {
    if (column < this.getColumnCount()) {
      return this.columnObjects.get(column);
    }
    return null;
  }

  /**
   * A convenience method used to add items to a list
   * @param listModel
   * @param objectsToAdd
   */
  public static void addObjectsToListModel(DefaultListModel listModel, List<? extends Object> objectsToAdd) {
    for (Object obj : objectsToAdd) {
      listModel.addElement(obj);
    }
  }

  @Override
  public String getColumnName(int column) {
    if (column >= this.getColumnCount()) {
      return super.getColumnName(column);
    }
    return this.columnObjects.get(column).toString();
  }

  @Override
  public int getRowCount() {
    return this.tableModel.size();
  }

  @Override
  public int getColumnCount() {
    // This assumes all rows are the same size as the first
    return (this.tableModel.size() > 0) ? this.tableModel.get(0).size() : 0;
  }

  @Override
  public Object getValueAt(int row, int column) {
    return this.tableModel.get(row).get(column);
  }

  @Override
  public final Class<?> getColumnClass(int columnIndex) {
    if (columnIndex >= this.getColumnCount()) {
      return super.getColumnClass(columnIndex);
    }
    return this.columnObjects.get(columnIndex).getClass();
  }

  public void saveModelAsCSV(File file) {
    // A hack to localize this CSV.  In languages with "," decimal separators, ";" is the CSV delimiter
    String csvDelimiter = NumberFormat.getInstance().format(1.1).contains(",") ? ";" : ",";
    StringBuilder csvFile = new StringBuilder("");

    for (int col = 0; col < this.getColumnCount(); col++) {
      csvFile.append(this.getColumnClass(col).equals(SavedResponsesHashMap.class) ? "Module" : "Result");
      csvFile.append(csvDelimiter);
    }
    csvFile.append("\n");
    for (int col = 0; col < this.getColumnCount(); col++) {
      csvFile.append((this.getColumnName(col) + csvDelimiter).toString());
    }
    csvFile.append("\n");
    for (int row = 0; row < this.getRowCount(); row++) {
      for (int col = 0; col < this.getColumnCount(); col++) {
        Object val = this.getValueAt(row, col);
        if (val instanceof SavedResponsesHashMap) {
          csvFile.append(((val != null ? val.toString() : "") + csvDelimiter).toString());
        } else if (val instanceof Double) {
          String numString = (val != null) ? NumberFormat.getInstance().format(((Double) val).doubleValue()) : "";
          csvFile.append((numString + csvDelimiter).toString());
        } else if (val == null) {
          csvFile.append(("null" + csvDelimiter).toString());
        }
      }
      csvFile.append("\n");
    }
    try {
      BufferedWriter bw = new BufferedWriter(new FileWriter(file));
      bw.append(csvFile);
      bw.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
