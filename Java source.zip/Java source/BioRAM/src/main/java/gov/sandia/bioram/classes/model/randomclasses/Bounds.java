/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gov.sandia.bioram.classes.model.randomclasses;

import java.io.Serializable;

/**
 * Needs to explicitly implement serializable for drag and drop to work
 * @author danbowe
 */
public class Bounds extends Object implements Serializable {

  public double lower;
  public double upper;

  public Bounds(double lower, double upper) {
    this.lower = lower;
    this.upper = upper;
  }
}
