/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gov.sandia.bioram.classes.model;

import java.awt.Color;
import java.util.UUID;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.MutableTreeNode;
import gov.sandia.bioram.xml.ResultMathOpExponent.Children;

/**
 *
 * @author danbowe
 */
public abstract class ResultObject extends DefaultMutableTreeNode {
  Color normColor = new Color(0,0,0);
  Color rawColor = new Color(0,0,0);

  double rawWeight;
  boolean normalizeChildren;

  double score;
  double normWeight;
  // UUIDs are just used for DND (they're not saved in the raml file)
  private UUID uuid;

  public ResultObject(double rawWeight, boolean normalizeChildren) {
    this.rawWeight = rawWeight;
    this.normalizeChildren = normalizeChildren;
    this.uuid = UUID.randomUUID();
  }

  public Color getColor() {
    return (this.normalizeChildren) ? this.normColor : this.rawColor;
  }

  public abstract void toJAXB(gov.sandia.bioram.xml.ResultMathOpExponent.Children children);

  /**
   * This factory method hosts a big, ugly case statement that reads the
   * children of the current node and instantiates them appropriately.
   *
   * What mainly makes it difficult to break apart from this case structure is the fact that
   * the JAXB-generated classes for ResultObjects have no common superclass [ResultObject],
   * so you can't operate on them with common methods from a shared type using polymorphism.
   *
   *
   * Note! ResultReferences need a second stage of processing after this to
   * tie their refUUIDs to actual RP instances!
   * 
   * @param children
   * @param parent
   */
  public static void generateTreeFromJAXB(RamModel model, Children children, ResultObject parent) {
    if (children != null) {
      for (Object obj : children.getResultMathOpAddOrResultMathOpSubtractOrResultMathOpMultiply()) {
        if (obj instanceof gov.sandia.bioram.xml.ResultCategory) {
          gov.sandia.bioram.xml.ResultCategory rc = (gov.sandia.bioram.xml.ResultCategory)obj;

          QuestionSetObject refQSO = model.getQSOByUUID(UUID.fromString(rc.getCategoryUUID()));
          if (refQSO != null && refQSO instanceof QuestionSetCategory) {
            ResultCategory rcDest = new ResultCategory(rc.getRawWeight(), (QuestionSetCategory)refQSO, rc.isNormalizeChildren());
            parent.add(rcDest);
            generateTreeFromJAXB(model, rc.getChildren(), rcDest);
          } else {
            System.out.format("ResultObject.generateTreeFromJAXB: ResultCategory contains an invalid UUID ref\n");
          }
        } else if (obj instanceof gov.sandia.bioram.xml.ResultQuestion) {
          gov.sandia.bioram.xml.ResultQuestion rq = (gov.sandia.bioram.xml.ResultQuestion)obj;

          QuestionSetObject refQSO = model.getQSOByUUID(UUID.fromString(rq.getQuestionUUID()));
          if (refQSO != null && refQSO instanceof QuestionSetQuestion) {
            ResultQuestion rqDest = new ResultQuestion(rq.getRawWeight(), (QuestionSetQuestion)refQSO);
            parent.add(rqDest);
            generateTreeFromJAXB(model, null, rqDest);
          } else {
            System.out.format("ResultObject.generateTreeFromJAXB: ResultQuestion contains an invalid UUID ref\n");
          }
        } else if (obj instanceof gov.sandia.bioram.xml.ResultMathOpAdd) {
          gov.sandia.bioram.xml.ResultMathOpAdd rmo = (gov.sandia.bioram.xml.ResultMathOpAdd)obj;

          ResultMathOpAdd rmoDest = new ResultMathOpAdd(rmo.getRawWeight(), rmo.getTitle(), rmo.isNormalizeChildren());
          parent.add(rmoDest);
          generateTreeFromJAXB(model, rmo.getChildren(), rmoDest);
        } else if (obj instanceof gov.sandia.bioram.xml.ResultMathOpSubtract) {
          gov.sandia.bioram.xml.ResultMathOpSubtract rmo = (gov.sandia.bioram.xml.ResultMathOpSubtract)obj;

          ResultMathOpSubtract rmoDest = new ResultMathOpSubtract(rmo.getRawWeight(), rmo.getTitle(), rmo.isNormalizeChildren());
          parent.add(rmoDest);
          generateTreeFromJAXB(model, rmo.getChildren(), rmoDest);

        } else if (obj instanceof gov.sandia.bioram.xml.ResultMathOpMultiply) {
          gov.sandia.bioram.xml.ResultMathOpMultiply rmo = (gov.sandia.bioram.xml.ResultMathOpMultiply)obj;

          ResultMathOpMultiply rmoDest = new ResultMathOpMultiply(rmo.getRawWeight(), rmo.getTitle(), rmo.isNormalizeChildren());
          parent.add(rmoDest);
          generateTreeFromJAXB(model, rmo.getChildren(), rmoDest);

        } else if (obj instanceof gov.sandia.bioram.xml.ResultMathOpDivide) {
          gov.sandia.bioram.xml.ResultMathOpDivide rmo = (gov.sandia.bioram.xml.ResultMathOpDivide)obj;

          ResultMathOpDivide rmoDest = new ResultMathOpDivide(rmo.getRawWeight(), rmo.getTitle(), rmo.isNormalizeChildren());
          parent.add(rmoDest);
          generateTreeFromJAXB(model, rmo.getChildren(), rmoDest);

        } else if (obj instanceof gov.sandia.bioram.xml.ResultMathOpConstant) {
          gov.sandia.bioram.xml.ResultMathOpConstant rmo = (gov.sandia.bioram.xml.ResultMathOpConstant)obj;

          ResultMathOpConstant rmoDest = new ResultMathOpConstant(rmo.getRawWeight(), rmo.getTitle(), rmo.getConstant());
          parent.add(rmoDest);
          generateTreeFromJAXB(model, null, rmoDest);

        } else if (obj instanceof gov.sandia.bioram.xml.ResultMathOpExponent) {
          gov.sandia.bioram.xml.ResultMathOpExponent rmo = (gov.sandia.bioram.xml.ResultMathOpExponent)obj;

          ResultMathOpExponent rmoDest = new ResultMathOpExponent(rmo.getRawWeight(), rmo.getTitle(), rmo.getExponent(), rmo.isNormalizeChildren());
          parent.add(rmoDest);
          generateTreeFromJAXB(model, rmo.getChildren(), rmoDest);

        } else if (obj instanceof gov.sandia.bioram.xml.ResultMathOpMax) {
          gov.sandia.bioram.xml.ResultMathOpMax rmo = (gov.sandia.bioram.xml.ResultMathOpMax)obj;

          ResultMathOpMax rmoDest = new ResultMathOpMax(rmo.getRawWeight(), rmo.getTitle(), rmo.isNormalizeChildren());
          parent.add(rmoDest);
          generateTreeFromJAXB(model, rmo.getChildren(), rmoDest);

        } else if (obj instanceof gov.sandia.bioram.xml.ResultMathOpMin) {
          gov.sandia.bioram.xml.ResultMathOpMin rmo = (gov.sandia.bioram.xml.ResultMathOpMin)obj;

          ResultMathOpMin rmoDest = new ResultMathOpMin(rmo.getRawWeight(), rmo.getTitle(), rmo.isNormalizeChildren());
          parent.add(rmoDest);
          generateTreeFromJAXB(model, rmo.getChildren(), rmoDest);
        } else if (obj instanceof gov.sandia.bioram.xml.ResultReference) {
          gov.sandia.bioram.xml.ResultReference rr = (gov.sandia.bioram.xml.ResultReference)obj;

          ResultReference rmoDest = new ResultReference(null, rr.getRawWeight());
          // I need to wait until all RPs have been parsed before I can look for the RP instance
          rmoDest.setRefUUID(UUID.fromString(rr.getRpUUID()));
          parent.add(rmoDest);
          generateTreeFromJAXB(model, null, rmoDest);
        }
      }
    }
  }

  /**
   * ResultObjects use the addition math op method by default
   * @return
   */
  public double getScore() {
    double tempScore = 0;
    for (int i = 0; i < this.getChildCount(); i++) {
      tempScore += ((ResultObject)this.getChildAt(i)).getScore();
    }
    return (tempScore * this.getWeight());
  }

  /**
   * Weights here work by what the parent has decided for normalization.  To manipulate
   * which weight you're getting/setting here, turn normalization on/off in the parent
   * @return
   */
  public double getWeight() {
    return (this.getParent() == null) ? this.rawWeight :
      (((ResultObject)this.getParent()).getNormalizeChildren()) ? normWeight : rawWeight;
  }
  
  public void setRawWeight(double newWeight, boolean denormalizeParent) {
    ResultObject parentCaringAboutWeight = (ResultObject)this.getParent();

    if (denormalizeParent && parentCaringAboutWeight != null) {
      parentCaringAboutWeight.setNormalizeChildren(false);
    }
    this.rawWeight = newWeight;
  }
  
  /**
   * This method should only be called by its parent
   * @param normWeight
   */
  public void setNormWeight(double normWeight) {
    this.normWeight = normWeight;
  }
  
  /**
   * This method should only be called by its parent
   */
  public double getRawWeight() {
    return this.rawWeight;
  }
  
  public void setNormalizeChildren(boolean normalized) {
    this.normalizeChildren = normalized;
    
    if (this.normalizeChildren) {
      double totalWeights = 0;

      // Find the total weights
      for (int i = 0; i < this.getChildCount(); i++) {
        totalWeights += ((ResultObject)this.getChildAt(i)).getRawWeight();
      }
      // Now to set their normalized weights...
      totalWeights = (totalWeights == 0) ? 1 : totalWeights; // Don't divide by zero
      for (int i = 0; i < this.getChildCount(); i++) {
        double norm = ((ResultObject)this.getChildAt(i)).getRawWeight()/totalWeights;
        ((ResultObject)this.getChildAt(i)).setNormWeight(norm);
      }
    }      
  }

  /**
   * add, insert, and remove are overridden below so that any time nodes
   * are changed, their normalized weights are also changed
   * @param tn
   */
  @Override
  public void add(MutableTreeNode tn) {
    super.add(tn);
    this.setNormalizeChildren(this.normalizeChildren);
  }
  
  @Override
  public void insert(MutableTreeNode tn, int index) {
    super.insert(tn, index);
    this.setNormalizeChildren(this.normalizeChildren);
  }

  @Override
  public void remove(MutableTreeNode tn) {
    super.remove(tn);
    this.setNormalizeChildren(this.normalizeChildren);
  }
  
  public boolean getNormalizeChildren() {
    return this.normalizeChildren;
  }
  
  public UUID getUUID() {
    return this.uuid;
  }

  public void setUUID(UUID uuid) {
    this.uuid = uuid;
  }

  @Override
  public String toString() {
    return "ResultObject";
  }
}
