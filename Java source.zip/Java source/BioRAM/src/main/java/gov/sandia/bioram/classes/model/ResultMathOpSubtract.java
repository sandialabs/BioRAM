/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gov.sandia.bioram.classes.model;

import java.awt.Color;
import gov.sandia.bioram.xml.ObjectFactory;

/**
 *
 * @author danbowe
 */
public class ResultMathOpSubtract extends ResultMathOp {
  public ResultMathOpSubtract(double rawWeight, String title, boolean normalizeChildren) {
    super(rawWeight, title, normalizeChildren);
    this.mathOpTypeKey = "Subtract";
  }

  @Override
  public double getScore() {
    if (this.getChildCount() == 2) {
      double termA = ((ResultObject)this.getChildAt(0)).getScore();
      double termB = ((ResultObject)this.getChildAt(1)).getScore();
      return ((termA-termB) * this.getWeight());
    } else {
      return super.getScore();
    }
  }

  @Override
  public Color getColor() {
    return (this.children != null && this.children.size() != 2) ? this.errorColor : super.getColor();
  }

  @Override
  public void toJAXB(gov.sandia.bioram.xml.ResultMathOpExponent.Children children) {
    ObjectFactory of = new ObjectFactory();
    gov.sandia.bioram.xml.ResultMathOpSubtract rmod = of.createResultMathOpSubtract();
    rmod.setTitle(this.getTitle());
    rmod.setRawWeight(this.getRawWeight());
    rmod.setNormalizeChildren(this.getNormalizeChildren());
    rmod.setChildren(of.createResultMathOpExponentChildren());

    children.getResultMathOpAddOrResultMathOpSubtractOrResultMathOpMultiply().add(rmod);

    for (int i = 0; i < this.getChildCount(); i++) {
      ResultObject ro = (ResultObject)this.getChildAt(i);

      ro.toJAXB(rmod.getChildren());
    }

  }
}
