/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gov.sandia.bioram.classes.model.webother;


import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Stroke;
import javax.swing.border.LineBorder;

class DottedBorder extends LineBorder {

  public DottedBorder(Color c) {
    super(c);
  }

  @Override
  public void paintBorder(Component comp, Graphics g, int x, int y, int width, int height) {
    Stroke old = ((Graphics2D) g).getStroke();
    Color oldColor = g.getColor();
    BasicStroke bs = new BasicStroke(1.0f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10.0f, new float[]{1.0f}, 0.0f);

    ((Graphics2D) g).setStroke(bs);
    g.setColor(this.lineColor);
    g.drawRect(x, y-1, width-1, height);
    ((Graphics2D) g).setStroke(old);
    g.setColor(oldColor);
  }
}
