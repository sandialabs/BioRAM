/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gov.sandia.bioram.classes.model;

import gov.sandia.bioram.classes.model.randomclasses.ObservableTreeModel;
import gov.sandia.bioram.classes.model.randomclasses.SavedResponsesHashMap;
import gov.sandia.bioram.classes.model.randomclasses.QuestionData;
import gov.sandia.bioram.forms.dnd.UUIDIdentifiable;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.event.TreeModelListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;
import gov.sandia.bioram.xml.ObjectFactory;
import gov.sandia.bioram.xml.RamModel.QuestionModule.ResponseSet;
import gov.sandia.bioram.xml.RamModel.QuestionModule.ResponseSet.Response;

/**
 *
 * @author danbowe
 */
public class QuestionSetModule extends ObservableTreeModel implements UUIDIdentifiable, TreeModelListener {
  private DefaultComboBoxModel savedRespHashMaps; // Holds ModuleDataMaps
  private HashMap<UUID, QuestionData> tempRespHashMap; // Store responses here before they get saved to the comboboxmodel

  public QuestionSetModule(String title) {
    // Sets my root object as a QuestionSetRoot with title as its name
    super(new QuestionSetRoot(title));

    this.tempRespHashMap = new HashMap<UUID, QuestionData>();
    this.savedRespHashMaps = new DefaultComboBoxModel();
    ((QuestionSetRoot)this.getRoot()).setModule(this);
  }

  /**
   * The alternate way of creating a QuestionSetModule, reading it in from an
   * unmarshaled XML file.  This calls the static recursive method generateTreeFromJAXB
   * to basically duplicate the ramML tree using QSOs.
   *
   * @param module
   * @param ramBaseFile
   */
  public QuestionSetModule(gov.sandia.bioram.xml.RamModel.QuestionModule module) {
    this(module.getQuestionSetRoot().getTitle().trim().isEmpty() ? " " : module.getQuestionSetRoot().getTitle());
    QuestionSetRoot qsoRoot = (QuestionSetRoot)this.getRoot();

    // Create the question set
    gov.sandia.bioram.xml.QuestionSetRoot rootQSOML = module.getQuestionSetRoot();
    qsoRoot.setUUID(UUID.fromString(rootQSOML.getUuid()));
    // When this returns, we'll have the source tree duplicated in qsoRoot
    QuestionSetObject.generateTreeFromJAXB(rootQSOML.getChildren(), qsoRoot);
    
    // Now parse in the response sets
    for (ResponseSet rs : module.getResponseSet()) {
      this.saveResponses(new SavedResponsesHashMap(rs), true);
    }
  }

  public gov.sandia.bioram.xml.RamModel.QuestionModule toJAXB() {
    ObjectFactory of = new ObjectFactory();
    gov.sandia.bioram.xml.RamModel.QuestionModule qm = of.createRamModelQuestionModule();
    
    gov.sandia.bioram.xml.QuestionSetObject.Children children = of.createQuestionSetObjectChildren();
    QuestionSetRoot rootQSO = (QuestionSetRoot)this.getRoot();
    rootQSO.toJAXB(children); // Create the source tree here
    // A bit of a hack to get the root object out
    List<Object> c = children.getQuestionSetObjectOrQuestionSetQuestionOrQuestionSetCategory();
    if (c.size() > 0) {
      qm.setQuestionSetRoot((gov.sandia.bioram.xml.QuestionSetRoot)c.get(0));
    }

    // Save the responses
    for (int i = 0; i < this.savedRespHashMaps.getSize(); i++) {
      SavedResponsesHashMap respMap = (SavedResponsesHashMap)this.savedRespHashMaps.getElementAt(i);

      ResponseSet rs = of.createRamModelQuestionModuleResponseSet();
      rs.setResponseSetName(respMap.getName());
      for (UUID respUUID : respMap.keySet()) {
        Response resp = of.createRamModelQuestionModuleResponseSetResponse();
        resp.setUuid(respUUID.toString());
        resp.setValue(respMap.get(respUUID).score);
        rs.getResponse().add(resp);
      }
      qm.getResponseSet().add(rs);
    }

    return qm;
  }


  public DefaultComboBoxModel getSavedResponseComboBoxModel() {
    return this.savedRespHashMaps;
  }

  // <editor-fold defaultstate="collapsed" desc="Relating to editing in ResponseForm">
  /**
   * First check the temp map for relevant data.  If no dice, get the selected set's.
   * If it still doesn't exist, this returns null.
   *
   * When calculating for real, you need to make sure tempRespHashMap is empty!
   * @param question
   * @return
   */
  public QuestionData getDataItemForUUID(UUID uuid) {
    HashMap<UUID, QuestionData> selHashMap = (HashMap<UUID, QuestionData>) this.savedRespHashMaps.getSelectedItem();

    if ((this.tempRespHashMap.isEmpty()) && (selHashMap != null)) {
      return selHashMap.get(uuid);
    }
    return this.tempRespHashMap.get(uuid);
  }

  /**
   * Called by setScore().  Things are always set in the tempRespHashMap until they're saved
   * with saveTempMap, rather than being directly written to a question set.
   * Question sets are immutable.
   * @param uuidKey
   * @param value
   */
  public void putDataItemForUUID(UUID uuidKey, QuestionData qd) {
    SavedResponsesHashMap mdm = (SavedResponsesHashMap)this.savedRespHashMaps.getSelectedItem();
   
    // Check if we're modifying a set for the first time (transfer all questions over if so)
    if ((this.tempRespHashMap.isEmpty()) && (mdm != null)) {
      this.tempRespHashMap = new HashMap<UUID, QuestionData>(mdm);
    }
    this.tempRespHashMap.put(uuidKey, qd);
  }

  public void removeDataItemForUUID(UUID uuid) {
    SavedResponsesHashMap savedResps = (SavedResponsesHashMap)this.savedRespHashMaps.getSelectedItem();
    if ((this.tempRespHashMap.isEmpty()) && (savedResps != null)) {
      this.tempRespHashMap = new HashMap<UUID, QuestionData>(savedResps);
    }
    this.tempRespHashMap.remove(uuid);
  }

  public void removeActiveResponseSet() {
    SavedResponsesHashMap currResp = (SavedResponsesHashMap)this.savedRespHashMaps.getSelectedItem();

    if (currResp != null) {
      this.savedRespHashMaps.removeElement(currResp);
      this.tempRespHashMap.clear();
    }
    this.notifyObservers();
  }

  public void resetTempMap() {
    this.tempRespHashMap.clear();

    // this.notifyObservers();
  }

  public void saveResponses(SavedResponsesHashMap responses, boolean shouldOverwriteIfDuplicate) {
    boolean duplicateFound = false;
    // Iterate backwards so removing items doesn't mess up indices
    for (int i = this.savedRespHashMaps.getSize() - 1; i >= 0; i--) {
      // If you found an element with the same name that isn't the one I just added...
      if (this.savedRespHashMaps.getElementAt(i).toString().equals(responses.getName())) {
        duplicateFound = true;
        if (shouldOverwriteIfDuplicate) {
          this.savedRespHashMaps.removeElementAt(i);
        }
      }
    }
    if ((duplicateFound && shouldOverwriteIfDuplicate) || !duplicateFound) {
      this.savedRespHashMaps.addElement(responses);
    }

    // Check this
    this.notifyObservers();
  }

  /**
   * Go through the tree and make sure what's in the temp map is what's being
   * seen on screen, then save the temp map as a new SavedResponsesHashMap.
   * @param name
   */
  public void saveTempMap(String name, boolean shouldOverwriteIfDuplicate) {
    SavedResponsesHashMap selSavedResp = (SavedResponsesHashMap)this.savedRespHashMaps.getSelectedItem();

    // If my temp map is empty, but an existing map is selected, just resave that one
    if ((this.tempRespHashMap.isEmpty()) && (selSavedResp != null)) {
      this.tempRespHashMap = new HashMap<UUID, QuestionData>(selSavedResp);
    }

    this.saveResponses(new SavedResponsesHashMap(this.tempRespHashMap, name), shouldOverwriteIfDuplicate);
    this.resetTempMap();
  }
  // </editor-fold>

  @Override
  public String toString() {
    return this.getRoot().toString();
  }
  
  public void addQuestionSetObject(TreePath parentPath, QuestionSetObject object) {
    QuestionSetObject parent;
    if (parentPath == null) {
      parent = (QuestionSetObject)this.getRoot();
    } else {
      parent = (QuestionSetObject)parentPath.getLastPathComponent();
    }
    parent.add(object);

    this.notifyObservers();
  }

  public void removeQuestionSetObject(QuestionSetObject currQSO) {
    while (currQSO.getChildCount() > 0) {
      ((QuestionSetObject)currQSO.getParent()).add((QuestionSetObject)currQSO.getChildAt(0));
    }
    ((QuestionSetObject)currQSO.getParent()).remove(currQSO);

    // Now remove from results
    for (int i = this.savedRespHashMaps.getSize() - 1; i >= 0; i--) {
      ((SavedResponsesHashMap)this.savedRespHashMaps.getElementAt(i)).remove(currQSO.getUUID());
    }

    this.notifyObservers();
  }

  /**
   * System look and feels don't support custom Tree Cell renderers too well, so I have
   * to use a list to represent the question set in the ResponseForm.
   * @return
   */
  public DefaultListModel toListModel() {
    DefaultListModel listModel = new DefaultListModel();
    this.dfsCreateListModel((QuestionSetObject)this.getRoot(), listModel);

    return listModel;
  }

  private void dfsCreateListModel(QuestionSetObject currNode, DefaultListModel model) {
    for (int i = 0; i < currNode.getChildCount(); i++) {
      model.addElement(currNode.getChildAt(i));
      dfsCreateListModel((QuestionSetObject)currNode.getChildAt(i), model);
    }
  }

  @Override
  public DefaultMutableTreeNode getNodeByUUID(Object nodeObject) {
    if (nodeObject instanceof QuestionSetObject) {
      UUID id = ((QuestionSetObject)nodeObject).getUUID();
      return this.getQSOByUUID(id);
    } else {
      return null;
    }
  }

  public QuestionSetObject getQSOByUUID(UUID uuid) {
      Enumeration e = ((QuestionSetObject)this.getRoot()).depthFirstEnumeration();

      for (QuestionSetObject currQS = (QuestionSetObject)e.nextElement(); e.hasMoreElements(); currQS = (QuestionSetObject)e.nextElement()) {
        if (currQS.getUUID().equals(uuid)) {
          return currQS;
        }
      }
      // ...because this dfs enumeration doesn't search the root
      return (((QuestionSetObject)this.getRoot()).getUUID().equals(uuid)) ? (QuestionSetObject)this.getRoot() : null;
  }
}
