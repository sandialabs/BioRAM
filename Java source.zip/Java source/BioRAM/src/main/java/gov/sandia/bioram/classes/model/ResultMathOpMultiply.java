/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gov.sandia.bioram.classes.model;

import gov.sandia.bioram.xml.ObjectFactory;

/**
 *
 * @author danbowe
 */
public class ResultMathOpMultiply extends ResultMathOp {
  public ResultMathOpMultiply(double rawWeight, String title, boolean normalizeChildren) {
    super(rawWeight, title, normalizeChildren);
    this.mathOpTypeKey = "Multiply";
  }

  @Override
  public double getScore() {
    double tempScore = 1;
    if (this.getChildCount() > 0) {
      for (int i = 0; i < this.getChildCount(); i++) {
        tempScore *= ((ResultObject)this.getChildAt(i)).getScore();
      }
      return (tempScore * this.getWeight());
    } else {
      return 0;
    }
  }

  @Override
  public void toJAXB(gov.sandia.bioram.xml.ResultMathOpExponent.Children children) {
    ObjectFactory of = new ObjectFactory();
    gov.sandia.bioram.xml.ResultMathOpMultiply rmom = of.createResultMathOpMultiply();
    rmom.setTitle(this.getTitle());
    rmom.setRawWeight(this.getRawWeight());
    rmom.setNormalizeChildren(this.getNormalizeChildren());
    rmom.setChildren(of.createResultMathOpExponentChildren());

    children.getResultMathOpAddOrResultMathOpSubtractOrResultMathOpMultiply().add(rmom);

    for (int i = 0; i < this.getChildCount(); i++) {
      ResultObject ro = (ResultObject)this.getChildAt(i);

      ro.toJAXB(rmom.getChildren());
    }
  }
}
