/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gov.sandia.bioram.forms.dnd;

import gov.sandia.bioram.forms.ProfileEditorForm.TreeType;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;
import java.io.Serializable;
import javax.swing.tree.TreePath;

/**
 *
 * @author danbowe
 */
public class TransferableTreePaths implements Transferable, Serializable {

  public static final DataFlavor objFlavor = new DataFlavor(TransferableTreePaths.class, "Transferable Object");
  TreePath[] treePaths;
  TreeType originatingTree;

  public TransferableTreePaths(TreePath[] treePaths, TreeType originatingTree) {
    this.treePaths = treePaths;
    this.originatingTree = originatingTree;
  }

  public TreeType getOriginatingTree() {
    return this.originatingTree;
  }

  public TreePath[] getTreePaths() {
    return this.treePaths;
  }

  @Override
  public DataFlavor[] getTransferDataFlavors() {
    return new DataFlavor[]{ TransferableTreePaths.objFlavor };
  }

  @Override
  public boolean isDataFlavorSupported(DataFlavor flavor) {
    for (DataFlavor f : this.getTransferDataFlavors()) {
      if (f.equals(flavor)) {
        return true;
      }
    }
    return false;
  }

  @Override
  public Object getTransferData(DataFlavor flavor) throws UnsupportedFlavorException, IOException {
    if (this.isDataFlavorSupported(flavor)) {
      return this;
    } else {
      return new UnsupportedFlavorException(flavor);
    }
  }
}
