/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * ViewResultsPanel.java
 *
 * Created on Feb 10, 2012, 6:36:51 PM
 */
package gov.sandia.bioram.forms.viewControllers;

import gov.sandia.bioram.classes.model.RamModel;
import gov.sandia.bioram.classes.model.ResultProfile;
import gov.sandia.bioram.classes.model.charts.ChartDataSeries;
import gov.sandia.bioram.classes.model.charts.RamChart;
import gov.sandia.bioram.classes.model.randomclasses.BackgroundGraphTable.DoubleGraphTableCellRenderer;
import gov.sandia.bioram.classes.model.randomclasses.BackgroundGraphTable.ResponseHashMapTableCellRenderer;
import gov.sandia.bioram.classes.model.randomclasses.RamDataTable;
import gov.sandia.bioram.classes.model.randomclasses.RamFileFilter;
import gov.sandia.bioram.classes.model.randomclasses.RamFileMarshal;
import gov.sandia.bioram.classes.model.randomclasses.ResponsesTableModel;
import gov.sandia.bioram.classes.model.randomclasses.SavedResponsesHashMap;
import java.awt.CardLayout;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.ItemEvent;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;
import java.util.ResourceBundle;
import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.table.DefaultTableModel;
import org.jfree.chart.ChartPanel;
import org.jfree.data.xy.XYSeriesCollection;

/**
 *
 * @author danbowe
 */
public class ViewResultsPanel extends javax.swing.JPanel implements Observer {

  private RamModel model;

  public ViewResultsPanel() {
    initComponents();

    this.model = new RamModel();
    // Concatenate these strings together
    ResourceBundle bundle = java.util.ResourceBundle.getBundle("lang/FormStrings");
    String concatTitle = bundle.getString("SelectDataPoints") +  " " + bundle.getString("MultipleSelectHint");
    jPanel23.setBorder(BorderFactory.createTitledBorder(concatTitle));
    jPanel16.setBorder(BorderFactory.createTitledBorder(concatTitle));
  }

  /**
   * When I set the model, the following items need to change:
   * <ul>
   * <li>moduleResponsesTree (the left column)</li>
   * <li>Tabulated view (taken care of implicitly by
   * the selection events of the modulesResponsesTree)</li>
   * <li>Result profile tabulated display list</li>
   * <li>Chart panels</li>
   * <li>Chart select combo box</li>
   * <li>Chart data point list</li>
   * </ul>
   *
   * @param model
   */
  public void setModel(RamModel model) {
    this.model = model;

    this.moduleResponsesTree.setModel(model); // This line also clears the tabulated view

    // Load the charts into the combo box and chartPanel.  Changing the
    // combobox state implicitly redraws the chart data point list
    this.chartsComboBox.removeAllItems();
    this.chartPanel.removeAll();
    for (int i = 0; i < this.model.getChartsListModel().getSize(); i++) {
      RamChart rc = (RamChart)this.model.getChartsListModel().getElementAt(i);

      ChartPanel cp = new ChartPanel(rc);
      cp.setMouseZoomable(false);
      cp.setInitialDelay(0);
      cp.setDismissDelay(Integer.MAX_VALUE); // As long as possible
      this.chartPanel.add(cp, Integer.toString(i));
      ((DefaultComboBoxModel)this.chartsComboBox.getModel()).addElement(rc);
    }

    // Initialize the results list (select all results by default)
    this.resultProfileResultsList.setModel(model.getResultProfilesListModel());
    int rpSize = this.resultProfileResultsList.getModel().getSize();
    if (rpSize > 0) {
      int selList[] = new int[rpSize];
      for (int i = 0; i < rpSize; i++) {
        selList[i] = i;
      }
      this.resultProfileResultsList.setSelectedIndices(selList);
    }
  }

  /**
   * A delegate method for the module response tree - this returns the
   * currently-selected response sets from the tree.  It is used in report
   * creation to match selections in the report dialog with the ones already
   * selected in the response form.
   *
   * @return
   */
  public List<SavedResponsesHashMap> getSelectedResponseSets() {
    return this.moduleResponsesTree.getSelectedResponseSets();
  }

  /**
   * Note that this only queries the model to find its cached results, then
   * displays them
   */
  private void refreshResultsTable() {
    LinkedList<ResultProfile> selectedResults = new LinkedList<ResultProfile>();
    for (Object rp : this.resultProfileResultsList.getSelectedValues()) {
      selectedResults.add((ResultProfile) rp);
    }

    // Refresh the Tabulated view
    ResponsesTableModel tableModel = new ResponsesTableModel(this.model.getCachedDataTable(), selectedResults);
    this.resultsTable.setModel(tableModel);
    this.resultsTable.setDefaultRenderer(SavedResponsesHashMap.class, new ResponseHashMapTableCellRenderer());
    this.resultsTable.setDefaultRenderer(Double.class, tableModel.new DoubleGraphTableCellRenderer());
  }

  /**
   * Figures out which chart is being displayed, then looks at which points
   * are selected in the chartsDatAPointsList, and plots those series.
   */
  public void replotSelectedDataPoints() {
    RamChart currChart = (RamChart)chartsComboBox.getSelectedItem();

    if (currChart != null) {
      List<ChartDataSeries> selectedSeries = new ArrayList<ChartDataSeries>();
      for (int i = 0; i < currChart.getXYPlot().getSeriesCount(); i++) {
        if (this.chartDataPointList.isSelectedIndex(i)) {
          selectedSeries.add((ChartDataSeries)((XYSeriesCollection)currChart.getXYPlot().getDataset()).getSeries(i));
        }
      }
      currChart.setDataPoints(this.model.getCachedDataTable(), selectedSeries);
    }
  }

  /** This method is called from within the constructor to
   * initialize the form.
   * WARNING: Do NOT modify this code. The content of this method is
   * always regenerated by the Form Editor.
   */
  @SuppressWarnings("unchecked")
  // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
  private void initComponents() {

    resultsTablePopupMenu = new javax.swing.JPopupMenu();
    saveResultsTableMenuItem = new javax.swing.JMenuItem();
    jSplitPane2 = new javax.swing.JSplitPane();
    jPanel11 = new javax.swing.JPanel();
    jPanel15 = new javax.swing.JPanel();
    jLabel4 = new javax.swing.JLabel();
    jPanel13 = new javax.swing.JPanel();
    jScrollPane1 = new javax.swing.JScrollPane();
    moduleResponsesTree = new gov.sandia.bioram.forms.viewControllers.ModuleResponsesTree();
    jTabbedPane1 = new javax.swing.JTabbedPane();
    jSplitPane3 = new javax.swing.JSplitPane();
    chartPanel = new javax.swing.JPanel();
    jPanel10 = new javax.swing.JPanel();
    jPanel22 = new javax.swing.JPanel();
    jLabel6 = new javax.swing.JLabel();
    chartsComboBox = new javax.swing.JComboBox();
    newChartButton = new javax.swing.JButton();
    jPanel23 = new javax.swing.JPanel();
    jScrollPane8 = new javax.swing.JScrollPane();
    chartDataPointList = new javax.swing.JList();
    jSplitPane6 = new javax.swing.JSplitPane();
    jPanel16 = new javax.swing.JPanel();
    jScrollPane3 = new javax.swing.JScrollPane();
    resultProfileResultsList = new javax.swing.JList();
    jPanel12 = new javax.swing.JPanel();
    resultsTableScrollPane = new javax.swing.JScrollPane();
    resultsTable = new javax.swing.JTable();

    java.util.ResourceBundle bundle = java.util.ResourceBundle.getBundle("lang/FormStrings"); // NOI18N
    saveResultsTableMenuItem.setText(bundle.getString("SaveAsCSV")); // NOI18N
    saveResultsTableMenuItem.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        saveResultsTableMenuItemActionPerformed(evt);
      }
    });
    resultsTablePopupMenu.add(saveResultsTableMenuItem);

    setLayout(new java.awt.BorderLayout());

    jSplitPane2.setDividerLocation(220);

    jPanel11.setBorder(javax.swing.BorderFactory.createTitledBorder(bundle.getString("SelectResponseSets"))); // NOI18N
    jPanel11.setLayout(new java.awt.BorderLayout());

    jPanel15.setLayout(new javax.swing.BoxLayout(jPanel15, javax.swing.BoxLayout.PAGE_AXIS));

    jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
    jLabel4.setText(bundle.getString("MultipleSelectHint")); // NOI18N
    jPanel15.add(jLabel4);

    jPanel13.setMaximumSize(new java.awt.Dimension(10, 10));

    javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
    jPanel13.setLayout(jPanel13Layout);
    jPanel13Layout.setHorizontalGroup(
      jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
      .addGap(0, 10, Short.MAX_VALUE)
    );
    jPanel13Layout.setVerticalGroup(
      jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
      .addGap(0, 10, Short.MAX_VALUE)
    );

    jPanel15.add(jPanel13);

    moduleResponsesTree.addTreeSelectionListener(new javax.swing.event.TreeSelectionListener() {
      public void valueChanged(javax.swing.event.TreeSelectionEvent evt) {
        moduleResponsesTreeValueChanged(evt);
      }
    });
    jScrollPane1.setViewportView(moduleResponsesTree);

    jPanel15.add(jScrollPane1);

    jPanel11.add(jPanel15, java.awt.BorderLayout.CENTER);

    jSplitPane2.setLeftComponent(jPanel11);

    jSplitPane3.setBorder(null);
    jSplitPane3.setDividerLocation(0.9);
    jSplitPane3.setOrientation(javax.swing.JSplitPane.VERTICAL_SPLIT);
    jSplitPane3.setResizeWeight(0.95);
    jSplitPane3.addComponentListener(new java.awt.event.ComponentAdapter() {
      public void componentResized(java.awt.event.ComponentEvent evt) {
        jSplitPane3ComponentResized(evt);
      }
    });

    chartPanel.setLayout(new java.awt.CardLayout());
    jSplitPane3.setTopComponent(chartPanel);

    jPanel10.setLayout(new javax.swing.BoxLayout(jPanel10, javax.swing.BoxLayout.PAGE_AXIS));

    jPanel22.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 10, 1, 10));

    jLabel6.setText(bundle.getString("SelectChart")); // NOI18N

    chartsComboBox.setModel(new DefaultComboBoxModel());
    chartsComboBox.setPreferredSize(new java.awt.Dimension(250, 20));
    chartsComboBox.addItemListener(new java.awt.event.ItemListener() {
      public void itemStateChanged(java.awt.event.ItemEvent evt) {
        chartsComboBoxItemStateChanged(evt);
      }
    });

    newChartButton.setText(bundle.getString("NewChart")); // NOI18N
    newChartButton.setEnabled(false);

    javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
    jPanel22.setLayout(jPanel22Layout);
    jPanel22Layout.setHorizontalGroup(
      jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
      .addGroup(jPanel22Layout.createSequentialGroup()
        .addComponent(jLabel6)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(chartsComboBox, 0, 439, Short.MAX_VALUE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(newChartButton))
    );
    jPanel22Layout.setVerticalGroup(
      jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
      .addGroup(jPanel22Layout.createSequentialGroup()
        .addGap(6, 6, 6)
        .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
          .addComponent(jLabel6)
          .addComponent(chartsComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
      .addGroup(jPanel22Layout.createSequentialGroup()
        .addGap(5, 5, 5)
        .addComponent(newChartButton))
    );

    jPanel10.add(jPanel22);

    jPanel23.setBorder(javax.swing.BorderFactory.createTitledBorder(bundle.getString("SelectDataPoints"))); // NOI18N
    jPanel23.setLayout(new java.awt.BorderLayout());

    chartDataPointList.setModel(new DefaultListModel());
    chartDataPointList.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
      public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
        chartDataPointListValueChanged(evt);
      }
    });
    jScrollPane8.setViewportView(chartDataPointList);

    jPanel23.add(jScrollPane8, java.awt.BorderLayout.CENTER);

    jPanel10.add(jPanel23);

    jSplitPane3.setBottomComponent(jPanel10);

    jTabbedPane1.addTab(bundle.getString("Graphed"), jSplitPane3); // NOI18N

    jSplitPane6.setDividerLocation(0.9);
    jSplitPane6.setOrientation(javax.swing.JSplitPane.VERTICAL_SPLIT);
    jSplitPane6.setResizeWeight(0.95);

    jPanel16.setBorder(javax.swing.BorderFactory.createTitledBorder(bundle.getString("SelectResultsToDisplay"))); // NOI18N
    jPanel16.setLayout(new java.awt.BorderLayout());

    resultProfileResultsList.setModel(new DefaultListModel());
    resultProfileResultsList.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
      public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
        resultProfileResultsListValueChanged(evt);
      }
    });
    jScrollPane3.setViewportView(resultProfileResultsList);

    jPanel16.add(jScrollPane3, java.awt.BorderLayout.CENTER);

    jSplitPane6.setRightComponent(jPanel16);

    jPanel12.setLayout(new java.awt.BorderLayout());

    resultsTableScrollPane.addMouseWheelListener(new java.awt.event.MouseWheelListener() {
      public void mouseWheelMoved(java.awt.event.MouseWheelEvent evt) {
        resultsTableScrollPaneMouseWheelMoved(evt);
      }
    });

    resultsTable.setAutoCreateRowSorter(true);
    resultsTable.setModel(new DefaultTableModel());
    resultsTable.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
    resultsTable.setComponentPopupMenu(resultsTablePopupMenu);
    resultsTable.setGridColor(new java.awt.Color(231, 230, 230));
    resultsTable.setSelectionBackground(new java.awt.Color(214, 235, 255));
    resultsTable.setSelectionForeground(new java.awt.Color(0, 0, 0));
    resultsTable.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
    resultsTableScrollPane.setViewportView(resultsTable);

    jPanel12.add(resultsTableScrollPane, java.awt.BorderLayout.CENTER);

    jSplitPane6.setLeftComponent(jPanel12);

    jTabbedPane1.addTab(bundle.getString("Tabulated"), jSplitPane6); // NOI18N

    jSplitPane2.setRightComponent(jTabbedPane1);

    add(jSplitPane2, java.awt.BorderLayout.CENTER);
  }// </editor-fold>//GEN-END:initComponents

    private void resultProfileResultsListValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_resultProfileResultsListValueChanged
      if (!evt.getValueIsAdjusting()) {
        this.refreshResultsTable();
      }
}//GEN-LAST:event_resultProfileResultsListValueChanged

  /**
   * A hack to get the bar graphs to repaint on scrolls (only wheel scrolls)
   * @param evt
   */
    private void resultsTableScrollPaneMouseWheelMoved(java.awt.event.MouseWheelEvent evt) {//GEN-FIRST:event_resultsTableScrollPaneMouseWheelMoved
      this.resultsTable.repaint();
}//GEN-LAST:event_resultsTableScrollPaneMouseWheelMoved

    private void chartsComboBoxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_chartsComboBoxItemStateChanged
      int iChart = this.chartsComboBox.getSelectedIndex();

      if ((evt.getStateChange() == ItemEvent.SELECTED) && (iChart >= 0)) {
        ((CardLayout) this.chartPanel.getLayout()).show(this.chartPanel, Integer.toString(iChart));

        // Update the data point list
        RamChart rc = (RamChart) this.chartsComboBox.getSelectedItem();
        this.chartDataPointList.setModel(rc.getDataPointsAsListModel());
        // Select all data points by default
        int selIndices[] = new int[this.chartDataPointList.getModel().getSize()];
        for (int i = 0; i < this.chartDataPointList.getModel().getSize(); selIndices[i] = i++); // fill in selected indices (all of them)
        this.chartDataPointList.setSelectedIndices(selIndices);
      }
}//GEN-LAST:event_chartsComboBoxItemStateChanged

    private void chartDataPointListValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_chartDataPointListValueChanged
      if (!evt.getValueIsAdjusting()) {
        this.replotSelectedDataPoints();
      }
}//GEN-LAST:event_chartDataPointListValueChanged

    /**
     * We first refresh the results table to recompute all the points, then call
     * plotAll to plot them.
     * @param evt
     */
    private void moduleResponsesTreeValueChanged(javax.swing.event.TreeSelectionEvent evt) {//GEN-FIRST:event_moduleResponsesTreeValueChanged
      this.model.setCachedModelResults(this.getSelectedResponseSets());
      this.model.plotAllDataPointsUsingCachedData();

      // Now only plot the selected points in the list
      this.refreshResultsTable();
      this.replotSelectedDataPoints();
    }//GEN-LAST:event_moduleResponsesTreeValueChanged

    private void saveResultsTableMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveResultsTableMenuItemActionPerformed
      RamDataTable tm = this.model.getCachedDataTable();

      if (tm != null) {
        JFileChooser jfc = new JFileChooser();
        jfc.setFileFilter(new RamFileFilter.CSVFileFilter());
        if (jfc.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
          try {
            File fp = jfc.getSelectedFile();
            if (!(fp.getName().endsWith(".csv"))) {
              fp = new File(fp.getParentFile().getAbsolutePath() + File.separator + jfc.getSelectedFile().getName() + ".csv");
            }
            this.model.getCachedDataTable().saveModelAsCSV(fp);
          } catch (Exception e) {
            System.err.println(e);
          }
        }
      }
}//GEN-LAST:event_saveResultsTableMenuItemActionPerformed

    /**
     * Try to maintain a decent aspect ratio for the charts' background image's sake
     * @param evt
     */
    private void jSplitPane3ComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_jSplitPane3ComponentResized
      RamChart rc = (RamChart)chartsComboBox.getSelectedItem();

      if (rc != null && rc.getXYPlot().getBackgroundImage() != null) {
        Image im = rc.getXYPlot().getBackgroundImage();
        double imageAR = im.getWidth(null) / (double)im.getHeight(null); // aspect ratio

        // The 60 is the min valid pixel height of the chart data point list, determined by trial and error
        double nominalImageHeight = chartPanel.getWidth() / imageAR;
        if (nominalImageHeight < (jSplitPane3.getHeight() - 100)) {
          System.out.println("Setting JSplitPane (chart) height explicitly");
          jSplitPane3.setDividerLocation((int)nominalImageHeight);
        }
      }
    }//GEN-LAST:event_jSplitPane3ComponentResized

  // Variables declaration - do not modify//GEN-BEGIN:variables
  private javax.swing.JList chartDataPointList;
  private javax.swing.JPanel chartPanel;
  private javax.swing.JComboBox chartsComboBox;
  private javax.swing.JLabel jLabel4;
  private javax.swing.JLabel jLabel6;
  private javax.swing.JPanel jPanel10;
  private javax.swing.JPanel jPanel11;
  private javax.swing.JPanel jPanel12;
  private javax.swing.JPanel jPanel13;
  private javax.swing.JPanel jPanel15;
  private javax.swing.JPanel jPanel16;
  private javax.swing.JPanel jPanel22;
  private javax.swing.JPanel jPanel23;
  private javax.swing.JScrollPane jScrollPane1;
  private javax.swing.JScrollPane jScrollPane3;
  private javax.swing.JScrollPane jScrollPane8;
  private javax.swing.JSplitPane jSplitPane2;
  private javax.swing.JSplitPane jSplitPane3;
  private javax.swing.JSplitPane jSplitPane6;
  private javax.swing.JTabbedPane jTabbedPane1;
  private gov.sandia.bioram.forms.viewControllers.ModuleResponsesTree moduleResponsesTree;
  private javax.swing.JButton newChartButton;
  private javax.swing.JList resultProfileResultsList;
  private javax.swing.JTable resultsTable;
  private javax.swing.JPopupMenu resultsTablePopupMenu;
  private javax.swing.JScrollPane resultsTableScrollPane;
  private javax.swing.JMenuItem saveResultsTableMenuItem;
  // End of variables declaration//GEN-END:variables

  /**
   * Selects all result profiles in the result profile list and redraw from
   * scratch, the modules/result set window 
   * @param o
   * @param arg
   */
  @Override
  public void update(Observable o, Object arg) {

    // Select all the result profiles in the table and graph
    int rpSize = this.resultProfileResultsList.getModel().getSize();
    if (rpSize > 0) {
      int selList[] = new int[rpSize];
      for (int i = 0; i < rpSize; i++) {
        selList[i] = i;
      }
      this.resultProfileResultsList.setSelectedIndices(selList);
    }

    this.moduleResponsesTree.setModel(this.model);
  }
}

class ViewResultsPanelTester {

  public static void main(String args[]) {
    final JFrame frame = new JFrame("Main Window");
    ViewResultsPanel vrp = new ViewResultsPanel();
    try {
      vrp.setModel(new RamFileMarshal(new File("C:/Users/danbowe/Documents/testModel.raml")).getRamModel());
    } catch (IOException e) {
      e.printStackTrace();
    }
    frame.add(vrp);

    frame.setPreferredSize(new Dimension(600, 600));
    frame.pack();
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setLocationRelativeTo(null);
    frame.setVisible(true);
  }
}
