/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gov.sandia.bioram.classes.model;

import gov.sandia.bioram.classes.model.randomclasses.Bounds;
import java.awt.Color;
import java.util.UUID;
import javax.swing.tree.DefaultMutableTreeNode;
import gov.sandia.bioram.xml.QuestionSetObject.Children;

/**
 * userObject is a string (its name)
 *
 * @author danbowe
 */
public abstract class QuestionSetObject extends DefaultMutableTreeNode {
  Color normalColor = new Color(0,0,0); // black

  private UUID uuid;
  double defaultWeight;

  public QuestionSetObject(String name) {
    super(name);
    this.defaultWeight = 1.0;
    this.uuid = UUID.randomUUID();
  }

  /**
   * Works with a source tree and destination tree.  Uses DFS to recurse through
   * {@code children} and replicate its structure and data using QuestionSetObjects
   * in {@code parent}.
   *
   * @param children The root node of the source tree
   * @param parent The root node of the destination tree
   */
  public static void generateTreeFromJAXB(Children children, QuestionSetObject parent) {
    if (children != null) {
      for (Object child : children.getQuestionSetObjectOrQuestionSetQuestionOrQuestionSetCategory()) {
        if (child instanceof gov.sandia.bioram.xml.QuestionSetCategory) {
          gov.sandia.bioram.xml.QuestionSetCategory qsc = (gov.sandia.bioram.xml.QuestionSetCategory) child;

          QuestionSetCategory newQSO = new QuestionSetCategory(qsc.getTitle(), qsc.getDefaultWeight());
          newQSO.setUUID(UUID.fromString(qsc.getUuid()));
          parent.add(newQSO);

          generateTreeFromJAXB(qsc.getChildren(), newQSO);
        } else if (child instanceof gov.sandia.bioram.xml.QuestionSetQuestion) {
          gov.sandia.bioram.xml.QuestionSetQuestion qsq = (gov.sandia.bioram.xml.QuestionSetQuestion) child;
          String question = qsq.getTitle();
          String details = qsq.getDetailText();
          double dw = qsq.getDefaultWeight();
          Bounds bounds = new Bounds(qsq.getBounds().getLower(), qsq.getBounds().getUpper());

          // XXX Hack for loading
          if (!qsq.getTitle().isEmpty()) {
	          QuestionSetQuestion newQSO = new QuestionSetQuestion(question, details, dw, bounds);
	          newQSO.setUUID(UUID.fromString(qsq.getUuid()));
	          parent.add(newQSO);
	
	          generateTreeFromJAXB(qsq.getChildren(), newQSO);
          }
        }
      }
    }
  }
  
  public abstract void toJAXB(gov.sandia.bioram.xml.QuestionSetObject.Children children);

  public void setName(String newName) {
    super.setUserObject(newName);
  }

  public void setDefaultWeight(double newWeight) {
    this.defaultWeight = newWeight;
  }

  public Double getDefaultWeight() {
    return this.defaultWeight;
  }

  public UUID getUUID() {
    return this.uuid;
  }

  public void setUUID(UUID newUUID) {
    this.uuid = newUUID;
  }

  public Color getColor() {
    return this.normalColor;
  }

  public String getJListString(int singleIndentSize, int listWidth) {
    return this.toString();
  }
  
  /**
   * Since subclasses return HTML toString()s (for lists and trees), this 
   * returns the title of the object.  This is called by the XML Marshaler
   * when getting the title of everybody, as well as ReportGenerator.
   * 
   * @return the main text of this object.
   */
  public String getTitle() {
    return this.getUserObject().toString();
  }
}
