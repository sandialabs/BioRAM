/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gov.sandia.bioram.classes.model;

import gov.sandia.bioram.xml.ObjectFactory;

/**
 * What is the purpose of QuestionSetRoot?  When you want to find a question's
 * score, it depends on which data set is selected in a module, so finding first
 * the question's root (which contains the module), then asking the module for that
 * question's score (by UUID) returns the score.
 *
 * @author danbowe
 */
public class QuestionSetRoot extends QuestionSetObject {
  QuestionSetModule myModule;

  /**
   * Why don't you set the module in the constructor?  It requires passing "this" in
   * that constructor before its superconstructor is called
   * @param name
   */
  public QuestionSetRoot(String name) {
    super(name);
  }

  public void setModule(QuestionSetModule myModule) {
    this.myModule = myModule;
  }

  public QuestionSetModule getModule() {
    return this.myModule;
  }

  public void toJAXB(gov.sandia.bioram.xml.QuestionSetObject.Children children) {
    ObjectFactory of = new ObjectFactory();
    gov.sandia.bioram.xml.QuestionSetRoot qsr = of.createQuestionSetRoot();
    qsr.setTitle(this.getTitle());
    qsr.setUuid(this.getUUID().toString());
    qsr.setDefaultWeight(this.getDefaultWeight());
    qsr.setChildren(of.createQuestionSetObjectChildren());
    children.getQuestionSetObjectOrQuestionSetQuestionOrQuestionSetCategory().add(qsr);

    for (int i = 0; i < this.getChildCount(); i++) {
      QuestionSetObject qso = (QuestionSetObject)this.getChildAt(i);

      qso.toJAXB(qsr.getChildren());
    }
  }
}
