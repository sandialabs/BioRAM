/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gov.sandia.bioram.classes.model;

import gov.sandia.bioram.xml.ObjectFactory;

/**
 *
 * @author danbowe
 */
public class ResultMathOpAdd extends ResultMathOp {
  public ResultMathOpAdd(double rawWeight, String title, boolean normalizeChildren) {
    super(rawWeight, title, normalizeChildren);
  }

  @Override
  public void toJAXB(gov.sandia.bioram.xml.ResultMathOpExponent.Children children) {
    ObjectFactory of = new ObjectFactory();
    gov.sandia.bioram.xml.ResultMathOpAdd rmoa = of.createResultMathOpAdd();
    rmoa.setTitle(this.getTitle());
    rmoa.setRawWeight(this.getRawWeight());
    rmoa.setNormalizeChildren(this.getNormalizeChildren());
    rmoa.setChildren(of.createResultMathOpExponentChildren());

    children.getResultMathOpAddOrResultMathOpSubtractOrResultMathOpMultiply().add(rmoa);

    for (int i = 0; i < this.getChildCount(); i++) {
      ResultObject ro = (ResultObject)this.getChildAt(i);

      ro.toJAXB(rmoa.getChildren());
    }
  }
}
