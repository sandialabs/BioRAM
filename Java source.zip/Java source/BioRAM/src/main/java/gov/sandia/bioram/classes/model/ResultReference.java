/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gov.sandia.bioram.classes.model;

import java.awt.Color;
import java.text.NumberFormat;
import java.util.Enumeration;
import java.util.ResourceBundle;
import java.util.UUID;
import javax.swing.ListModel;
import org.apache.commons.lang.NotImplementedException;
import gov.sandia.bioram.xml.ObjectFactory;

/**
 *
 * @author danbowe
 */
public class ResultReference extends ResultObject {
  private ResultProfile refRP;
  private UUID refUUID;

  public ResultReference(ResultProfile refRP, double rawWeight) {
    super(rawWeight, false);

    this.refRP = refRP;
    this.normColor = new Color(255,80,80);
    this.rawColor = new Color(255,0,0);
  }

  /**
   * The refUUID parameter is ONLY valid for parsing items in and should be
   * generally regarded as not valid (test refRP's UUID instead, or test for
   * null).
   *
   * It solves a problem of parsing, where you don't yet have all RPs parsed in,
   * thus can't obtain a RP's uuid.  Rather, during parsing, the RP's UUID is
   * written to this intermediate variable (its only use), then read at the end
   * of parsing to obtain the actual reference to refRP.
   *
   * Note that this value should be valid at any given time and could in theory
   * be used when extracting the UUID, but this will not be rigorously tested, 
   * so refUUID should only be used during parsing.
   * 
   * @param uuid
   */
  public void setRefUUID(UUID uuid) {
    this.refUUID = uuid;
  }

  public UUID getRefUUID() {
    return this.refUUID;
  }

  public ResultProfile getRefRP() {
    return this.refRP;
  }

  public void setRefRP(ResultProfile rp) {
    this.refRP = rp;
  }

  @Override
  public String toString() {
    ResourceBundle rb = ResourceBundle.getBundle("lang/FormStrings");
    String weightStr = NumberFormat.getInstance().format(this.getWeight());
    String titleStr = rb.getString("ResultReference_ResultReference");
    String refStr = (this.refRP == null) ? rb.getString("ResultReference_InvalidReference") : this.refRP.toString();

    return "<html><font color=\"rgb(" +
        this.getColor().getRed() + "," + this.getColor().getGreen() + "," + this.getColor().getBlue() +
        ")\">[" + weightStr + "] (" + titleStr + ") " + refStr + "</font></html>";
  }

  /**
   * The naming of these colors doesn't quite elegantly follow their usage -
   * rather than have normalized children or not, the color depends on if the
   * reference is valid.
   * @return
   */
  @Override
  public Color getColor() {
    return (this.refRP == null) ? this.rawColor : this.normColor;
  }

  @Override
  public double getScore() {
    if (this.refRP == null) {
      return 0;
    } else {
      return this.getWeight() * this.refRP.getCurrentScore(true);
    }
  }

  @Override
  public void toJAXB(gov.sandia.bioram.xml.ResultMathOpExponent.Children children) {
    ObjectFactory of = new ObjectFactory();
    gov.sandia.bioram.xml.ResultReference ref = of.createResultReference();
    ref.setRawWeight(this.getRawWeight());
    if (this.refRP != null) {
      ref.setRpUUID(this.refRP.getUuid().toString());
    }

    children.getResultMathOpAddOrResultMathOpSubtractOrResultMathOpMultiply().add(ref);
  }

  /**
   * This is a utility method used upon ResultRef creation and file unmarshaling
   * that looks for circular references in ResultReferences.
   *
   * @param{fromRP} the RP in which the ResultReference node resides
   * @param{toRP} the RP that the ResultReference wants to reference
   *
   * @returns true if a circular reference was encountered and false otherwise
   */
  public static boolean isCircularResultReference(ResultProfile fromRP, ResultProfile toRP) {

    // for currRO in fromRP: # Python equivalent to the next two lines... :-\
    Enumeration e = ((ResultTitle)toRP.getRoot()).depthFirstEnumeration();
    for (ResultObject currRO = (ResultObject) e.nextElement(); e.hasMoreElements(); currRO = (ResultObject) e.nextElement()) {
      if (currRO instanceof ResultReference) {
        ResultReference rr = (ResultReference) currRO;

        if (rr.getRefRP() != null) {
          ResultProfile newRP = rr.getRefRP();

          // The big moment
          if (fromRP.getUuid().equals(newRP.getUuid())) {
            return true;
          }

          // Not a circular ref yet, keep recursively searching
          return isCircularResultReference(fromRP, newRP);
        }
      }
    }
    return fromRP == toRP; // Finally, test the trivial case
  }

}
