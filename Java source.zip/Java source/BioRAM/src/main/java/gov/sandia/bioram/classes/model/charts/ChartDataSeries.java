/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gov.sandia.bioram.classes.model.charts;

import gov.sandia.bioram.classes.model.ResultProfile;
import org.jfree.data.xy.XYSeries;

/**
 * ChartDataSeries represents one ResultProfile XY combo.  It doesn't actually contain
 * the data to plot.  That is calculated on-the-fly as additions to this series
 * (hence inheriting from XYSeries).
 * @author danbowe
 */
public class ChartDataSeries extends XYSeries {
  ResultProfile xRP;
  ResultProfile yRP;

  public ChartDataSeries(ResultProfile xRP, ResultProfile yRP, String title) {
    super(title);

    this.xRP = xRP;
    this.yRP = yRP;
  }
  
  public void setXRP(ResultProfile rp) {
    this.xRP = rp;
  }

  public void setYRP(ResultProfile rp) {
    this.yRP = rp;
  }

  public ResultProfile getXRP() {
    return this.xRP;
  }

  public ResultProfile getYRP() {
    return this.yRP;
  }

  @Override
  public String toString() {
    return this.getKey().toString();
  }

  @Override
  public boolean equals(Object obj) {
    if (obj instanceof ChartDataSeries) {
      ChartDataSeries cds = (ChartDataSeries)obj;

      return (super.equals(obj) &&
              this.xRP == cds.xRP &&
              this.yRP == cds.yRP);
    }
    return false;
  }

  @Override
  public int hashCode() {
    int hash = 5;
    hash = 47 * hash + (this.xRP != null ? this.xRP.hashCode() : 0);
    hash = 47 * hash + (this.yRP != null ? this.yRP.hashCode() : 0);
    return hash;
  }
}
