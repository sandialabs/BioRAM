/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gov.sandia.bioram.classes.model.randomclasses;

import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.URI;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.imageio.ImageIO;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.jfree.chart.ChartPanel;

import gov.sandia.bioram.classes.model.QuestionSetCategory;
import gov.sandia.bioram.classes.model.QuestionSetModule;
import gov.sandia.bioram.classes.model.QuestionSetQuestion;
import gov.sandia.bioram.classes.model.RamModel;
import gov.sandia.bioram.classes.model.ResultProfile;
import gov.sandia.bioram.classes.model.charts.RamChart;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.util.ResourceBundle;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;

/**
 * This class knows how to create an HTML report file, given a RamModel.
 *
 * Its main job is to put all the information necessary for the reports into
 * an Apache Velocity context.  With this information in the context, you can
 * plug in any template that uses its "API" (the variable names it uses in
 * the context) to create any report desired.
 *
 * @author danbowe
 */
public class ReportGenerator {

  private final RamModel model;

  public ReportGenerator(RamModel model) {
    this.model = model;
  }

  /**
   * The term "Merge" follows Apache Velocity semantics of merging a template
   * with the data in the context.
   *
   * This method creates an HTML report.  Note that the option to provide your
   * own template may make this non-obvious.  However, it is only the resulting
   * file extension and file layout that dictates this to be html.
   *
   * @param velocityTemplatePath the path to the template.  This is resolved against
   * Velocity's root folder, which should be the root of the app.
   * @param questionResponseSets the response sets to include
   * 
   * @return The absolute system path URI of the resulting HTML report
   */
  public String mergeHTML(
          String velocityTemplatePath,
          List<SavedResponsesHashMap> questionResponseSets,
          boolean includeCharts) throws IOException {
    String reportURL = "";
    File tmpDir = RamFileMarshal.createTempDirectory();
    reportURL = tmpDir + System.getProperty("file.separator") + "report.html";

    Velocity.setProperty("resource.loader", "class");
    Velocity.setProperty("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
    Velocity.init();
    VelocityContext context = new VelocityContext();

    this.writeCachedModelResultsDataToContext(context);

    // Now fill out the context
    context.put("includeCharts", includeCharts);
    context.put("questionResponseSets", questionResponseSets);

    context.put("cssStyle", "/Resources/reportStyle.css");
    context.put("model", this.model);
    context.put("date", new SimpleDateFormat().format(new Date()));

    // ...so that results data can have CSS class="numeric"
    context.put("ResultProfileClass", ResultProfile.class);
    // ...so that questions and categories can be differentiated (colspan)
    context.put("QuestionSetCategoryClass", QuestionSetCategory.class);
    context.put("QuestionSetQuestionClass", QuestionSetQuestion.class);
    // ...to access the static method to get QSM from a response hash map
    context.put("SavedResponseHashMapClass", SavedResponsesHashMap.class);
    // ...to access the static XML string escape methods.  This should be
    // used to write strings, rather than wrapping them in <![CDATA[...]]>
    context.put("StrEscCls", StringEscapeUtils.class);
    // Put the resource bundle in the context for internationalized strings
    context.put("rb", ResourceBundle.getBundle("lang/FormStrings"));

    this.writeImagesToContext(context, tmpDir);

    Template template = Velocity.getTemplate(velocityTemplatePath);
    FileOutputStream fis = new FileOutputStream(reportURL);
    BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(fis));
    if (template != null) {
      template.merge(context, writer);
    }
    writer.flush();
    writer.close();
    fis.close();
    return reportURL;
  }

  public String mergeDOCX(
          String velocityTemplatePath,
          String xslDirectoryPath,
          String docxTemplateDir,
          List<SavedResponsesHashMap> questionResponseSets,
          boolean includeCharts) {
    String docxPath = "";
    try {
      String htmlPath = this.mergeHTML(velocityTemplatePath, questionResponseSets, includeCharts);

      File tmpDir = RamFileMarshal.createTempDirectory();
      for (File f : new File(docxTemplateDir).listFiles()) {
        RamFileMarshal.deepCopy(f, tmpDir);
      }
      for (File f : new File(htmlPath.replaceAll("(.*/)", "$1")).listFiles()) {
        if (f.getName().endsWith(".png")) {
          RamFileMarshal.deepCopy(f, new File(tmpDir, "word/media/"));
        }
      }

    } catch (Exception e) {
      e.printStackTrace();
    }
    return "";
  }
  
  /**
   * This writes both the logo image and the plots to the context and to the temp
   * directory.
   * 
   * @param context
   */
  public void writeImagesToContext(VelocityContext context, File tmpDir) throws IOException {
    // Put the images the temp directory
    if (this.model.getFrontImage() != null) {
      File logoPath = new File(tmpDir, UUID.randomUUID().toString() + ".png");
      ImageIO.write((BufferedImage)this.model.getFrontImage(), "png", logoPath);
      context.put("logoPath", logoPath.getName());
    }
    
    List<String> chartPaths = new ArrayList<String>();
    List<String[]> chartSeriesLegendImagePaths = new ArrayList<String[]>();
    for (int iChart = 0; iChart < this.model.getChartsListModel().size(); iChart++) {
      RamChart rc = (RamChart)this.model.getChartsListModel().getElementAt(iChart);
      XYLineAndShapeRenderer r = (XYLineAndShapeRenderer)rc.getXYPlot().getRenderer();


      // This is all to get the series legend entries written to disk
      RamChart.NumberedXYItemLabelGenerator ng = new RamChart.NumberedXYItemLabelGenerator();

      chartSeriesLegendImagePaths.add(new String[rc.getXYPlot().getSeriesCount()]);
      for (int iSeries = 0; iSeries < rc.getXYPlot().getSeriesCount(); iSeries++) {
        // For the reports, we can't have tooltips showing details about the data
        // points, so the details need to laid out.  This is done by putting numbers
        // on each data point and putting the full details of each legend item
        // corresponding to that data item
        r.setSeriesItemLabelGenerator(iSeries, ng);
        r.setSeriesItemLabelsVisible(iSeries, true);

        Rectangle b = r.lookupSeriesShape(iSeries).getBounds();
        BufferedImage dpImage = new BufferedImage((int)b.getWidth()*2, (int)b.getHeight()*2, BufferedImage.TYPE_INT_ARGB);

        Graphics2D g = (Graphics2D)dpImage.getGraphics();
        g.scale(2, 2);
        g.translate(-b.getX(), -b.getY());
        g.setPaint(r.lookupSeriesPaint(iSeries));
        g.setStroke(r.lookupSeriesOutlineStroke(iSeries));
        g.fill(r.lookupSeriesShape(iSeries));

        try {
          // Write the legend image to disk and note the filename in chartSeriesLegendImagePaths
          String chartFilename = String.format("Chart%dSeries%d.png", iChart, iSeries);
          ImageIO.write(dpImage, "png", new File(tmpDir, chartFilename));
          chartSeriesLegendImagePaths.get(iChart)[iSeries] = chartFilename;
        } catch(Exception e) {
          e.printStackTrace();
        }
      }

      ChartPanel cp = new ChartPanel(rc);
      cp.setSize(new Dimension(600, 600));
      BufferedImage bi = new BufferedImage(cp.getWidth(), cp.getHeight(), BufferedImage.TYPE_INT_RGB);
      cp.paintComponent(bi.getGraphics());

      String chartPath = String.format("Chart%d.png", iChart);
      ImageIO.write(bi, "png", new File(tmpDir, chartPath));
      chartPaths.add(chartPath);

      // Now turn off numbered labels
      for (int iSeries = 0; iSeries < rc.getXYPlot().getSeriesCount(); iSeries++) {
        // Note that this leaves the Numbered item generator in there, but just disables it
        rc.getXYPlot().getRenderer().setSeriesItemLabelsVisible(iSeries, false);
      }
    }
    context.put("chartPaths", chartPaths);
    context.put("chartLegendPaths", chartSeriesLegendImagePaths);
  }
  
  public void writeCachedModelResultsDataToContext(VelocityContext context) {
    // Results table
    RamDataTable rdt = this.model.getCachedDataTable(); // Used the precomputed (cached) data table
    int columnIndices[] = new int[rdt.getColumnCount()];
    int rowIndices[] = new int[rdt.getRowCount()];
    String[][] results = new String[rdt.getRowCount()][rdt.getColumnCount()];

    // The following loops are to get results table data in the context in a
    // format more suitable for a template language (VTL) to use
    for (int y = 0; y < rdt.getRowCount(); rowIndices[y] = y, y++);
    for (int x = 0; x < rdt.getColumnCount(); columnIndices[x] = x, x++);

    for (int x = 0; x < rdt.getColumnCount(); x++) {
      for (int y = 0; y < rdt.getRowCount(); y++) {
        Object value = rdt.getValueAt(y,x);
        if (value instanceof Double) {
          // Localize this (commas for decimal points, etc...)
          value = NumberFormat.getInstance().format(value);
        }
        // It's null if no response set for a particular module was selected
        results[y][x] = ResponsesTableModel.ResponseHashMapTableCellRenderer.getText(value);
      }
    }
    
    context.put("resultsTable", rdt);
    context.put("columnIndices", columnIndices);
    context.put("rowIndices", rowIndices);
    context.put("results", results);
  }
}

class ReportGeneratorTester {

  public ReportGeneratorTester() {
    RamModel model = this.getRamModel();
    model.setNames("Daniel Bowen\nSue Caskey");
    model.setProcedure("This is\nThe new <procedure> & line\nspanning multiple\nlines");

    ReportGenerator gen = new ReportGenerator(model);
    List<SavedResponsesHashMap> resp = this.getResponses(model);
    model.setCachedModelResults(resp); // Sets the cached data table
    try {
      String path = gen.mergeHTML("./Resources/reportTemplate.vm", resp.subList(3, 20), true);
    
      URI uri = new URI("file", path, null);
      Desktop.getDesktop().browse(uri);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public static void main(String args[]) {
    new ReportGeneratorTester();
  }

  public List<SavedResponsesHashMap> getResponses(RamModel model) {
    List<SavedResponsesHashMap> respList = new ArrayList<SavedResponsesHashMap>();

    for(Object obj : model.getModulesListModel().toArray()) {
      QuestionSetModule qsm = (QuestionSetModule)obj;

      for (int i = 0; i < qsm.getSavedResponseComboBoxModel().getSize(); i++) {
        SavedResponsesHashMap savedResp =(SavedResponsesHashMap)qsm.getSavedResponseComboBoxModel().getElementAt(i);
        respList.add(savedResp);
      }
    }
    return respList;
  }

  public RamModel getRamModel() {
    try {
      File fp = new File("C:/Users/danbowe/Documents/testModel.raml");
      RamFileMarshal marshal = new RamFileMarshal(fp);
      return marshal.getRamModel();
    } catch (Exception e) {
      e.printStackTrace();
    }
    return null;
  }
}
