/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gov.sandia.bioram.forms.viewControllers;

import gov.sandia.bioram.classes.model.QuestionSetCategory;
import gov.sandia.bioram.classes.model.QuestionSetModule;
import gov.sandia.bioram.classes.model.QuestionSetQuestion;
import gov.sandia.bioram.classes.model.RamModel;
import gov.sandia.bioram.classes.model.randomclasses.RamFileMarshal;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.io.File;
import java.io.IOException;
import java.util.Random;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.tree.TreeCellRenderer;

/**
 *
 * @author danbowe
 */
public class QSMJTree extends JTree {
  public QSMJTree() {
    this.setCellRenderer(new TreeCellRenderer() {
      private Random rand = new Random();

      @Override
      public Component getTreeCellRendererComponent(JTree tree, Object value, boolean selected, boolean expanded, boolean leaf, int row, boolean hasFocus) {
        if (value instanceof QuestionSetQuestion) {

        } else if (value instanceof QuestionSetCategory) {
          JLabel label = new JLabel(((QuestionSetCategory)value).getTitle());
          //label.setFont(new Font());
        }
        JPanel jp = new JPanel();
        jp.setPreferredSize(new Dimension(500, 40 + (int)(rand.nextDouble()*200)));
        jp.setBackground(Color.YELLOW);
        jp.add(new JLabel(value.toString()));
        return jp;
      }

    });
  }

  public void setQSM(QuestionSetModule qsm) {
    this.setModel(qsm);

    for (int i = 0; i < this.getRowCount(); i++) {
      this.expandRow(i);
    }
  }
}

class QSMJTreeTester {

  public static void main(String args[]) {
    final JFrame frame = new JFrame("Main Window");
    JPanel panel = new JPanel(new BorderLayout());

    try {
      RamModel model = new RamFileMarshal(new File("C:/Users/danbowe/Documents/testModel.raml")).getRamModel();

      QSMJTree tree = new QSMJTree();
      tree.setQSM((QuestionSetModule)model.getModulesListModel().getElementAt(1));
      panel.add(new JScrollPane(tree));
    } catch (IOException e) {
      e.printStackTrace();
    }
    frame.add(panel);

    frame.setPreferredSize(new Dimension(600, 600));
    frame.pack();
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setLocationRelativeTo(null);
    frame.setVisible(true);
  }
}
