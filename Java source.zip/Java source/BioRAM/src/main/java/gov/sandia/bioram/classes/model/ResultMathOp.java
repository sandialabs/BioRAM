/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gov.sandia.bioram.classes.model;

import java.awt.Color;
import java.text.NumberFormat;
import java.util.ResourceBundle;

/**
 *
 * @author danbowe
 */
public abstract class ResultMathOp extends ResultObject {
  Color errorColor;
  String extraToStringInfo = ""; // A bit of a hack to make subclassing this bulky toString() easier
  String mathOpTypeKey = "Add"; // Lets toString know what kind of op this is
  String title = "";

  public ResultMathOp(double rawWeight, String title, boolean normalizeChildren) {
    super(rawWeight, normalizeChildren);
    this.title = title;

    this.normColor = new Color(0,0,255);
    this.rawColor = new Color(114,106,255);
    this.errorColor = new Color(168,234,255);
  }

  public String getTitle() {
    return this.title;
  }

  /**
   * Used in editing ResultMathOps - which tab should be selected?
   * @return
   */
  public String getMathOpTypeKey() {
    return this.mathOpTypeKey;
  }

  @Override
  public Color getColor() {
    return (this.children != null && !this.children.isEmpty()) ? super.getColor() : this.errorColor;
  }

  @Override
  public String toString() {
    String weightStr = NumberFormat.getInstance().format(this.getWeight());
    return "<html><font color=\"rgb(" +
        this.getColor().getRed() + "," + this.getColor().getGreen() + "," + this.getColor().getBlue() +
        ")\">[" + weightStr + "] " + "(" + ResourceBundle.getBundle("lang/FormStrings").getString(this.mathOpTypeKey) +
        this.extraToStringInfo + ") " + this.title + "</font></html>";
  }
}
