/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gov.sandia.bioram.classes.model;

import java.awt.Color;
import java.util.ResourceBundle;
import gov.sandia.bioram.xml.ObjectFactory;

/**
 *
 * @author danbowe
 */
public class ResultTitle extends ResultObject {

  String title;

  public ResultTitle(String title) {
    super(1.0, true); // Regular weight
    this.title = title;
    
    this.normColor = new Color(255,128,0);
    this.rawColor = new Color(220,110,0);
    this.setNormalizeChildren(true); // Normalize by default
  }

  public String getTitle() {
    return this.title;
  }

  public void setTitle(String newTitle) {
    this.title = newTitle;
  }

  /**
   * Note that this makes a call to rb.getString() on every toString and toString
   * is called for every refresh of a result profile list.  If this gets too
   * performance-intensive, it can be cached in the same way the ram data table
   * caches the "(none selected)" string.
   * @return
   */
  @Override
  public String toString() {
    return "<html><font color=\"rgb(" +
            this.getColor().getRed() + "," + this.getColor().getGreen() + "," + this.getColor().getBlue() + ")\">" +
            ResourceBundle.getBundle("lang/FormStrings").getString("ResultTitle_ResultProfile") +
            ": " + this.title + "</font></html>";
  }

  @Override
  public void toJAXB(gov.sandia.bioram.xml.ResultMathOpExponent.Children children) {
    ObjectFactory of = new ObjectFactory();
    gov.sandia.bioram.xml.ResultTitle rt = of.createResultTitle();
    rt.setTitle(this.getTitle());
    rt.setRawWeight(this.getRawWeight());
    rt.setNormalizeChildren(this.getNormalizeChildren());
    rt.setChildren(of.createResultMathOpExponentChildren());

    children.getResultMathOpAddOrResultMathOpSubtractOrResultMathOpMultiply().add(rt);

    for (int i = 0; i < this.getChildCount(); i++) {
      ResultObject ro = (ResultObject)this.getChildAt(i);

      ro.toJAXB(rt.getChildren());
    }
  }
}
