/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gov.sandia.bioram.classes.model.randomclasses;

import gov.sandia.bioram.classes.model.QuestionSetModule;
import gov.sandia.bioram.classes.model.QuestionSetRoot;
import gov.sandia.bioram.classes.model.ResultObject;
import gov.sandia.bioram.classes.model.ResultProfile;
import gov.sandia.bioram.classes.model.ResultQuestion;
import java.awt.Component;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.ResourceBundle;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.tree.DefaultMutableTreeNode;

/**
 *
 * @author danbowe
 */
public class QuestionSensitivityTableModel extends BackgroundGraphTable {

  public class QuestionTableCellRenderer extends DefaultTableCellRenderer {
    /**
     * A ResultQuestion's toString() doesn't give me the question it references...
     * @param table
     * @param value
     * @param isSelected
     * @param hasFocus
     * @param row
     * @param column
     * @return
     */
    @Override
    public Component getTableCellRendererComponent(
            JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
      Object newVal = value;
      if (value instanceof ResultQuestion) {
        newVal = ((ResultQuestion) value).getReferenceQuestion().getUserObject().toString();
      }
//        JPanel panel = new JPanel(new BorderLayout());
//        JLabel j = new JLabel(((ResultQuestion)value)
//        panel.add(j);
//        panel.setBackground(isSelected ? table.getSelectionBackground() : table.getBackground());
//        return panel;
//      } else {
      return super.getTableCellRendererComponent(table, newVal, isSelected, hasFocus, row, column);
    }
//    }
  }

  public QuestionSensitivityTableModel(ResultProfile rp) {
    double mostSensitive = 0; // ...so I can normalize them all

    Enumeration<ResultObject> e = (Enumeration<ResultObject>)((DefaultMutableTreeNode) rp.getRoot()).depthFirstEnumeration();
    for (ResultObject currRO = e.nextElement(); e.hasMoreElements(); currRO = e.nextElement()) {
      if (currRO instanceof ResultQuestion) {
        ResultObject testRO = currRO;
        double currentScore = 1;
        for (; testRO.getParent() != null; testRO = (ResultObject) testRO.getParent()) {
          currentScore *= testRO.getWeight();
        }
        mostSensitive = Math.max(mostSensitive, currentScore);

        ArrayList<Object> newRow = new ArrayList<Object>();
        newRow.add(new Double(currentScore));
        newRow.add(((QuestionSetRoot)((ResultQuestion)currRO).getReferenceQuestion().getRoot()).getModule().toString());
        newRow.add(currRO);
        this.tableModel.add(newRow);
      }
    }
    this.largestValueInColumn.addAll(Arrays.asList(new Double[] { new Double(mostSensitive), null, null }));
    this.columnClasses.addAll(Arrays.asList(new Class<?>[] { Double.class, QuestionSetModule.class, ResultQuestion.class }));
    this.columnNames.add(ResourceBundle.getBundle("lang/FormStrings").getString("CumulativeWeight"));
    this.columnNames.add(ResourceBundle.getBundle("lang/FormStrings").getString("Module"));
    this.columnNames.add(ResourceBundle.getBundle("lang/FormStrings").getString("Question"));
  }
}
