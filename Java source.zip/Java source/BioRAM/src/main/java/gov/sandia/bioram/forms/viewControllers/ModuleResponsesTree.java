/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gov.sandia.bioram.forms.viewControllers;

import gov.sandia.bioram.classes.model.QuestionSetModule;
import gov.sandia.bioram.classes.model.RamModel;
import gov.sandia.bioram.classes.model.randomclasses.SavedResponsesHashMap;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

/**
 * Shows the response sets as children of their modules and only allows selection
 * of SavedResponseHashMaps.
 *
 * @author danbowe
 */
public class ModuleResponsesTree extends JTree {

  private RamModel model;

  public ModuleResponsesTree() {
    super(new DefaultMutableTreeNode("Root"));
    this.initComponents();
  }

  public void setModel(RamModel model) {
    this.model = model;
    
    // Update the view results tab (create the tree model)
    DefaultMutableTreeNode root = new DefaultMutableTreeNode("Root");

    for (int i = 0; i < this.model.getModulesListModel().getSize(); i++) {
      QuestionSetModule currModule = (QuestionSetModule) this.model.getModulesListModel().getElementAt(i);
      currModule.resetTempMap(); // ...so we're not calculating with tempMap values
      DefaultMutableTreeNode moduleChild = new DefaultMutableTreeNode(currModule);

      for (int j = 0; j < currModule.getSavedResponseComboBoxModel().getSize(); j++) {
        moduleChild.add(new DefaultMutableTreeNode(currModule.getSavedResponseComboBoxModel().getElementAt(j)));
      }
      root.add(moduleChild);
    }

    // Expand all nodes
    this.setModel(new DefaultTreeModel(root));
    for (int i = 0; i < this.getRowCount(); i++) {
      this.expandRow(i);
    }

    // Start off with the first response set in each module selected
    for (int i = 0; i < root.getChildCount(); i++) {
      if (root.getChildAt(i).getChildCount() > 0) {
        this.getSelectionModel().addSelectionPath(
                new TreePath(((DefaultMutableTreeNode) root.getChildAt(i).getChildAt(0)).getPath()));
      }
    }
  }

  private void initComponents() {
    this.setModel(new DefaultTreeModel(null));
    this.setRootVisible(false);
    this.setShowsRootHandles(true);

    DefaultTreeCellRenderer renderer = (DefaultTreeCellRenderer) this.getCellRenderer();
    renderer.setLeafIcon(null);
    renderer.setClosedIcon(null);
    renderer.setOpenIcon(null);

    this.addTreeSelectionListener(new javax.swing.event.TreeSelectionListener() {
      @Override
      public void valueChanged(javax.swing.event.TreeSelectionEvent evt) {
        treeValueChanged(evt);
      }
    });
  }

  /**
   * The task of this method is to make sure only ResponseSets are selected
   * (not Modules themselves, which are at the top level in the tree).
   *
   * @param evt
   */
  private void treeValueChanged(javax.swing.event.TreeSelectionEvent evt) {
    System.out.format("Added: %s (%s)\n", new Date().getTime(), evt.isAddedPath());

    // TODO: Having the below line commented out means computing all these values twice when a module is automatically deselected
    //if (evt.isAddedPath()) {
    TreeSelectionModel selModel = this.getSelectionModel();
    if (selModel.getSelectionPaths() != null) {
      ArrayList<TreePath> pathsToRemove = new ArrayList<TreePath>();
      for (TreePath tp : selModel.getSelectionPaths()) {
        if (!(((DefaultMutableTreeNode) tp.getLastPathComponent()).getUserObject() instanceof SavedResponsesHashMap)) {
          pathsToRemove.add(tp);
        }
      }
      for (TreePath pathToRemove : pathsToRemove) {
        selModel.removeSelectionPath(pathToRemove);
      }
    }
  }

  /**
   * Returns a list of the selected response sets
   * @return
   */
  public List<SavedResponsesHashMap> getSelectedResponseSets() {
    List<SavedResponsesHashMap> selectedResponses = new ArrayList<SavedResponsesHashMap>();
    TreePath pathSelections[] = this.getSelectionPaths();

    if (pathSelections != null) {
      for (TreePath tp : pathSelections) {
        if ((tp != null) && (((DefaultMutableTreeNode) tp.getLastPathComponent()).getUserObject() instanceof SavedResponsesHashMap)) {
          selectedResponses.add((SavedResponsesHashMap) ((DefaultMutableTreeNode) tp.getLastPathComponent()).getUserObject());
        }
      }
    }
    return selectedResponses;
  }

  public void setSelectedResponseSets(List<SavedResponsesHashMap> selectedResultResponseSets) {
    // Select the selected rows
    int selRows[] = new int[selectedResultResponseSets.size()], iSelRow = 0;
    for (int i = 0; i < this.getRowCount(); i++) {
      Object obj = ((DefaultMutableTreeNode)this.getPathForRow(i).getLastPathComponent()).getUserObject();

      if (obj instanceof SavedResponsesHashMap) {
        for (SavedResponsesHashMap savedResp : selectedResultResponseSets) {
          if (savedResp == obj) {
            selRows[iSelRow++] = i;
            break;
          }
        }
      }
    }
    this.setSelectionRows(selRows);
  }
}
