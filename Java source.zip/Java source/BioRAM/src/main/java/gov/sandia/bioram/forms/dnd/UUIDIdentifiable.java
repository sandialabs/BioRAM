/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gov.sandia.bioram.forms.dnd;

import gov.sandia.bioram.classes.model.QuestionSetObject;
import java.util.UUID;
import javax.swing.tree.DefaultMutableTreeNode;

/**
 * When dnd deserializes objects, it instantiates new ones that need to be cross-referenced
 * to the original objects in the TreeModel via UUID matching.
 *
 * @author danbowe
 */
public interface UUIDIdentifiable {
  public DefaultMutableTreeNode getNodeByUUID(Object nodeObject);
  //public QuestionSetObject getQSOByUUID(UUID uuid);
}
