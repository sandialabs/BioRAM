/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gov.sandia.bioram.forms.dnd;

import gov.sandia.bioram.forms.ProfileEditorForm.TreeType;
import java.awt.datatransfer.Transferable;
import javax.swing.JComponent;
import javax.swing.JTree;
import javax.swing.TransferHandler;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;

/**
 *
 * @author danbowe
 */
/**
 * This class is meant to be overridden for both the question set tree and the
 * result profile tree
 * @author danbowe
 */
public class TreeTransferHandler extends TransferHandler {
  TreeType treeType;
  UUIDIdentifiable uuidIdentifiable;

  /**
   * @param uuidIdentifiable - Where can I go to match up serialized objects to their original?
   * @param treeType - What type of tree started the dnd?
   */
  public TreeTransferHandler(UUIDIdentifiable uuidIdentifiable, TreeType treeType) {
    this.treeType = treeType;
    this.uuidIdentifiable = uuidIdentifiable;
  }

  @Override
  public int getSourceActions(JComponent c) {
    return TransferHandler.COPY_OR_MOVE;
  }

  @Override
  protected Transferable createTransferable(JComponent c) {
    if (c instanceof JTree) {
      return new TransferableTreePaths(((JTree)c).getSelectionPaths(), this.treeType);
    } else {
      return null;
    }
  }

  /**
   * Default importData rearranges things
   * @param ts
   * @return
   */
  @Override
  public boolean importData(TransferHandler.TransferSupport ts) {
    if (this.canImport(ts) && (this.uuidIdentifiable != null)) {
      try {
        TransferableTreePaths t = (TransferableTreePaths)ts.getTransferable().getTransferData(TransferableTreePaths.objFlavor);
        TreePath[] sourcePaths = t.getTreePaths();
        TreePath dropPath = ((JTree.DropLocation)ts.getDropLocation()).getPath();

        DefaultMutableTreeNode nodeTo;
        if (dropPath == null) {
          nodeTo = (DefaultMutableTreeNode)((JTree)ts.getComponent()).getModel().getRoot();
        } else {
          nodeTo = (DefaultMutableTreeNode)dropPath.getLastPathComponent();
        }

        if (nodeTo != null) {
          for (TreePath tp : sourcePaths) {
            boolean amITryingToMakeMyChildMyParent = false;
            DefaultMutableTreeNode nodeFrom = (DefaultMutableTreeNode)this.uuidIdentifiable.getNodeByUUID(tp.getLastPathComponent());

            // Make sure I'm not parenting a parent
            DefaultMutableTreeNode testParent = nodeTo;
            while (testParent.getParent() != null) {
              if (testParent == nodeFrom) {
                amITryingToMakeMyChildMyParent = true;
              }
              testParent = (DefaultMutableTreeNode)testParent.getParent();
            }

            if (!amITryingToMakeMyChildMyParent) {
              nodeTo.insert(nodeFrom, 0);
            }
          }
        }
        return true;
      } catch (Exception e) {
        System.err.println(e.getMessage());
      }
    }
    return false;
  }
}
