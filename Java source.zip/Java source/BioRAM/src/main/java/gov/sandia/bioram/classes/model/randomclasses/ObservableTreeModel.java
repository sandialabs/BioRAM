/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gov.sandia.bioram.classes.model.randomclasses;

import java.io.Serializable;
import java.util.Observer;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;

/**
 * This class monitors its children (branches).  Whenever a change occurs, it
 * relays this information (that something changed) to whatever is observing 
 * this class.
 *
 * @author danbowe
 */
public class ObservableTreeModel extends DefaultTreeModel implements Serializable, TreeModelListener {

  /**
   * The point of overriding this class is to prevent having to explicitly call
   * setChanged() before calling notifyObservers().  This is mostly because you
   * can only call setChanged() from a subclass, thus eliminating the potential
   * to use the delegation design pattern with the Observable Object (in case there
   * already is a superclass for the desired Observable data object).
   *
   * @author danbowe
   */
  public static class Observable extends java.util.Observable implements Serializable {

    @Override
    public void notifyObservers() {
      this.setChanged();
      super.notifyObservers();
    }

    @Override
    public void notifyObservers(Object o) {
      this.setChanged();
      super.notifyObservers(o);
    }
  }
  private Observable observableDelegate = new Observable();

  public ObservableTreeModel(TreeNode root) {
    super(root);
  }

  public void notifyObservers() {
    // TODO: remove this!
    if (this.observableDelegate == null) {
      this.observableDelegate = new Observable();
    }
    observableDelegate.notifyObservers();
  }

  public synchronized void deleteObservers() {
    observableDelegate.deleteObservers();
  }

  public synchronized void addObserver(Observer o) {
    observableDelegate.addObserver(o);
  }

  @Override
  public void treeNodesChanged(TreeModelEvent e) {
    this.notifyObservers();
  }

  @Override
  public void treeNodesInserted(TreeModelEvent e) {
    this.notifyObservers();
  }

  @Override
  public void treeNodesRemoved(TreeModelEvent e) {
    this.notifyObservers();
  }

  @Override
  public void treeStructureChanged(TreeModelEvent e) {
    this.notifyObservers();
  }
}
