/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gov.sandia.bioram.classes.model.randomclasses;

import java.util.HashMap;
import java.util.UUID;

import gov.sandia.bioram.xml.RamModel.QuestionModule.ResponseSet.Response;
import gov.sandia.bioram.classes.model.QuestionSetModule;
import gov.sandia.bioram.classes.model.RamModel;

/**
 *
 * @author danbowe
 */
public class SavedResponsesHashMap extends HashMap<UUID, QuestionData> {
  String name;

  @Override
  public boolean equals(Object obj) {
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    final SavedResponsesHashMap other = (SavedResponsesHashMap) obj;
    if ((this.name == null) ? (other.name != null) : !this.name.equals(other.name)) {
      return false;
    }
    return super.equals(obj);
  }


  /**
   * hashCode needs to be overridden for a rare bug that occurs with
   * these items in the ComboBox model - it returns the same hashcode as the
   * hash map (the temp hashmap) if there are the same hashed items.
   * @return
   */
  @Override
  public int hashCode() {
   return super.hashCode() + (this.name != null ? this.name.hashCode() : 0);
  }

  public SavedResponsesHashMap(HashMap<UUID, QuestionData> currentMap, String name) {
    super(currentMap);

    this.name = name;
  }

  public SavedResponsesHashMap(gov.sandia.bioram.xml.RamModel.QuestionModule.ResponseSet responseSet) {
    this.name = responseSet.getResponseSetName();

    for (Response resp : responseSet.getResponse()) {
      this.put(UUID.fromString(resp.getUuid()), new QuestionData(resp.getValue()));
    }
  }

  public String getName() {
    return this.name;
  }

  @Override
  public String toString() {
    return this.name;
  }
  
  /**
   * Note: This performs pointer comparison, thus it requires that the resp
   * be pointing to the same object as the module, not just a copy.
   * 
   * @param model
   * @param resp
   * @return
   */
  public static QuestionSetModule getResponseSetModule(RamModel model, SavedResponsesHashMap resp) {
    // Loop through all modules 
    for (Object obj : model.getModulesListModel().toArray()) {
      QuestionSetModule qsm = (QuestionSetModule)obj;
      
      // Check all responses in this module.  If it matches, return it
      for (int i = 0; i < qsm.getSavedResponseComboBoxModel().getSize(); i++) {
        if (resp == qsm.getSavedResponseComboBoxModel().getElementAt(i)) {
          return qsm; 
        }
      }
    }
    return null; // Didn't find it
  }
}
