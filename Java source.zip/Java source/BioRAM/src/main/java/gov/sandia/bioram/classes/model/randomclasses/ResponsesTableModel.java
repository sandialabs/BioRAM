/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gov.sandia.bioram.classes.model.randomclasses;

import gov.sandia.bioram.classes.model.QuestionSetModule;
import gov.sandia.bioram.classes.model.ResultProfile;
import java.util.ArrayList;
import java.util.LinkedList;

/**
 * Pick and choose the data from the RamDataTable to display.  That is, only
 * show the selected ResultProfiles from the list
 * @author danbowe
 */
public class ResponsesTableModel extends BackgroundGraphTable {
  public ResponsesTableModel(RamDataTable dataTable, LinkedList<ResultProfile> selectedResults) {
    // Set up the header row
    for (int i = 0; i < dataTable.getColumnCount(); i++) {
      Object currObj = dataTable.getObjectForColumn(i);

      if (currObj instanceof QuestionSetModule) {
        this.columnNames.add(currObj.toString());
        this.columnClasses.add(SavedResponsesHashMap.class);
      } else if ((currObj instanceof ResultProfile) && selectedResults.contains((ResultProfile) currObj)) {
        this.columnNames.add(currObj.toString());
        this.columnClasses.add(Double.class);
      }
    }

    // Now add the data
    for (int row = 0; row < dataTable.getRowCount(); row++) {
      ArrayList<Object> newRow = new ArrayList<Object>();
      for (int col = 0; col < dataTable.getColumnCount(); col++) {
        Object currObj = dataTable.getValueAt(row, col);
        Object dataType = dataTable.getObjectForColumn(col);
        // If this column is a ResultProfile that has been selected
        if ((dataType instanceof ResultProfile) && (selectedResults.contains((ResultProfile)dataType))) {
          newRow.add(currObj);
        } else if (dataType instanceof QuestionSetModule) {
          newRow.add(currObj);
        }
      }
      this.tableModel.add(newRow);
    }

    // Calculate max values for columns of doubles
    if (tableModel.size() > 0) { // If there are any rows
      for (int col = 0; col < tableModel.get(0).size(); col++) { // Go through all the columns
        if (this.getColumnClass(col) == Double.class) {
          double currValue = 0;
          for (int row = 0; row < tableModel.size(); row++) {
            currValue = Math.max(((Double) tableModel.get(row).get(col)).doubleValue(), currValue);
          }
          this.largestValueInColumn.add(new Double(currValue));
        } else {
          this.largestValueInColumn.add(null);
        }
      }
    }
  }
}
