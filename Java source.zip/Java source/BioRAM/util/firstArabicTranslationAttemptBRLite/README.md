# How to structure this

I should recursively create categories.  Find all categories in base level 
(colspan=3), then for each category, find all its categories etc...

Each level could be a dictionary, so it'd look like:

{
  "title": "...",
  "items": [
    {
      "title": "...",
      "items": [
      {
        "sugg": "...",
        "question": "...",
      },
      {
        "sugg": "...",
        "question": "...",
      },
      {
        "sugg": "...",
        "question": "...",
      },
      ],
    "question": {
      "sugg": "...",
      "question": "...",
    },
    "question": {
      "sugg": "...",
      "question": "...",
    },
    "question": {
      "sugg": "...",
      "question": "...",
    },
  ]
}

[
  {
    "title": "...".
  }
  {
