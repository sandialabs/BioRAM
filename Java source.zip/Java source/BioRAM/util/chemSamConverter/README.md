# What is the structure of what I'm doing?

# QS RAML
Question Set Module (merely a tree model with saved responses)
    Question Set Root (sole root, contains module title)
        Question Set Category
            Question Set Question
        Question Set Category
            Question Set Question

# RP RAML
Result Profile
    Result Title (no uuid)
        Result Category (UUID)
            Result Question (UUID)
        Result Category (UUID)
            Result Question (UUID)

# QS Python
Module (module title)
    Category
        Questions
    Category
        Questions

# What happens
Result Profile (worksheet text)
    C (module title)
        C (category)
            Q (question)
        C (category)
            Q (question)
