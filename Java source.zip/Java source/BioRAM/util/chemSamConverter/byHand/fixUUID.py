import uuid
import lxml.etree

"""
This did what I intended it to do, but I realized later that it was pointless 
--- I ended up having to do what I wanted with this script by-hand.
"""

with open('model.xml') as fp:
    xmlText = fp.read()

# root = lxml.etree.XML(xmlText)
root = lxml.etree.parse('model.xml')

for elUUID in root.findall('//ResultProfile/uuid'):
    newUUID = str(uuid.uuid4())


    xmlText = xmlText.replace(elUUID.text, newUUID)

with open('model2.xml', 'w') as fp:
    fp.write(xmlText)
