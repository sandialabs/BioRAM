import xlrd1
import dict2xml
import lxml.etree
import json
import zipfile
import uuid

"""
Uses moduleStructure to describe locations of categories and questions.  
Understands how to parse a single question.  Recursively moves through 
moduleStructure to generate its data analogue in ramlProfile

Questions
- How do the colors affect categories?
- Some cells (F26, F44) have some funky calculations going on
- No response suggestions for questions 51, 53, and 55

- Chart "Theft risk with/without access" references reversed

Calculations
Only top-level module categories are summed, so:
    - 3 result profiles for the first module, based on different inputs 
      (categories)
    - 2 result profiles for the second module (insider/outsider), based on the 
      same inputs with different weights
"""

inHTML = 'intro.htm'
inXSLT = 'BioRAM.xsl'
inExcel = 'ChemSAMv2.xls'
outXML = 'model.xml'
debugModulesJSON = 'ChemSAM.json'
debugOutXML = 'ChemSAMDebug.xml'
ramlOut = 'ChemSAM.raml'
graphbg = 'graphbg.png'

# Result Profiles
# We make a few assumptions about the model representation, which this 
# worksheet coincidentaly adheres to:
#   1. A result profile only spans one module
#   2. A module only spans one worksheet
#   3. (foundational!) The hierarchy of the result profile exactly mirrors the 
#   question set's hierarchy

# RESULT PROFILE
# moduleIndex: The module whose structure to mirror (0-based index)
# weightCol: 0-based column holding weights
# titleRow: 1-based row that the title is on (implicitly weightCol column)
rpStructure = [
    { 'moduleIndex': 0, 'weightCol': 4, 'titleRow': 1},
    { 'moduleIndex': 0, 'weightCol': 6, 'titleRow': 1},
    { 'moduleIndex': 0, 'weightCol': 8, 'titleRow': 1},
    { 'moduleIndex': 1, 'weightCol': 4, 'titleRow': 3},
    { 'moduleIndex': 1, 'weightCol': 6, 'titleRow': 3},
]

# MODULESTRUCTURE
# wsIndex: the worksheet index in the Excel document (assumes 1 module/ws)
# categories: top-level categories for this module

# CATEGORY
# row: the row the question is on
# questions: a tuple with the inclusive bounds of a range of question #s
# children: a recursive structure of subcategories
moduleStructure = [
    {
        'wsIndex': 1,
        'categories': [
            { 'row': 2, 'questions': (1,8), },
            {
                'row': 57,
                'children': [
                    { 'row': 58, 'questions': (9,18), },
                    { 'row': 119, 'questions': (19,22), },
                ],
            },
            { 'row': 153, 'questions': (23, 25), }
        ],
    },
    {
        'wsIndex': 2,
        'categories': [
            {
                'row': 2,
                'children': [
                    { 'row': 3, 'questions': (1,11), },
                    { 'row': 70, 'questions': (12,15), },
                    { 'row': 95, 'questions': (16,37), },
                    { 'row': 228, 'questions': (38,45), },
                    { 'row': 277, 'questions': (46,50), },
                    { 'row': 308, 'questions': (51,55), },
                    { 'row': 339, 'questions': (56,66), },
                    { 'row': 406, 'questions': (67,73), },
                ],
            },
        ],
    },
]

# Graphs
# Since the xlrd package can't read Excel's graphs (where some information 
# lies, like data points and legend titles), I'll have to hard-code it here.

graphs = [
    {
        "title": "Facility Chemical Security Risk",
        "titlex": "Potential Consequence of Malicious Release " +
                  "(theft or sabotage)",
        "titley": "Likelihood of Success",
        "bg": graphbg,
        "datapoints": [
            {
                "title": "Theft Risk (without Access)",
            },
            {
                "title": "Theft Risk (with Access)",
            },
            {
                "title": "Sabotage Risk - Near Populated Area (without " +
                         "Access)",
            },
            {
                "title": "Sabotage Risk - Near Populated Area (with Access)",
            },
            {
                "title": "Sabotage Risk - Near Industrial Areas (without " +
                         "Access)",
            },
            {
                "title": "Sabotage Risk - Near Industrial Areas (with Access)",
            },
        ],
    },
]

# RAM PROFILE (implicit root)
# frontMatter: intro HTML
# modules: list of set modules
# resultProfiles: list of RPs
# graphs: list of graphs

# MODULE
# name: the name of a module
# children: contains the top-level categories for this module
# uuid: this question set module's UUID

# CATEGORY
# title: name of the category
# children: recursive structure of categories and questions
# uuid: this category's UUID

# QUESTION
# number: question number
# question: question text
# uuid: this question's UUID
# suggestions: list of suggestions (dict with value/description)
ramlProfile = { "root": { "modules": [], "graphs": graphs } }
resultProfiles = []
with open(inHTML) as fp:
    # CDATA is a bit of an implementation detail for the XML format...
    fm = fp.read().decode('iso-8859-1').encode('ascii', 'xmlcharrefreplace')
    ramlProfile['root']['frontMatter'] = "<![CDATA[%s]]>" % fm

def findQuestionRow(qNum, ws):
    for row in range(ws.nrows):
        if ws.cell(row, 0).value == qNum:
            return row
    return -1

def parseQuestion(ws, row):
    cell = lambda r, c: ws.cell(r, c).value
    isStrType = lambda r, c: ws.cell(r, c).ctype == 0
    isCellEmpty = lambda r, c: isStrType(r, c) and cell(r, c).strip() == ""
    isQuestionRow = lambda r: not isCellEmpty(r, 0)

    question = {
        'number': int(cell(row, 0)),
        'question': cell(row, 1).strip(),
        'uuid': str(uuid.uuid4()),
        'suggestions': [], }

    def getResponseSuggestion(r):
        if not isQuestionRow(r):
            if not isCellEmpty(r, 2):
                question['suggestions'].append({
                    'value': cell(r, 1),
                    'description': cell(r, 2)
                })
            getResponseSuggestion(r+1)

    getResponseSuggestion(row+1)
    return question

# Generate the question sets
wb = xlrd1.open_workbook(inExcel)
for moduleIndex, m in enumerate(moduleStructure):
    ws = wb.sheet_by_index(m['wsIndex'])
    questions = []
    for r in range(ws.nrows):
        if ws.cell(r, 0).ctype == 2:
            questions.append(parseQuestion(ws, r))

    module = { 'name': ws.name, 'children': [], 'uuid': str(uuid.uuid4()) }
    def parseCategory(data, parentResult):
        """
        data: current category data
        parentResult: parent category result
        """
        qs = []
        if 'questions' in data:
            qs = range(data['questions'][0], data['questions'][1] + 1)
        category = {
            'title': ws.cell(data['row'] - 1, 0).value.strip(),
            'children': [q for q in questions if q['number'] in qs],
            'uuid': str(uuid.uuid4()),
        }
        parentResult['children'].append(category)

        for c in data['children'] if 'children' in data else []:
            parseCategory(c, category)
    for c in m['categories']:
        parseCategory(c, module)

    ramlProfile['root']['modules'].append(module)

    # RESULT PROFILE
    # title: The name of the RP (ResultRoot title)
    # uuid: UUID for the RP
    # children: categories and questions

    # RESULT CATEGORY
    # uuid: referenced category UUID
    # children: categories and questions

    # RESULT QUESTION
    # uuid: referenced question UUID
    # weight: weight to give question (category weights are implicitly 1.0)
    for rp in [r for r in rpStructure if r['moduleIndex'] == moduleIndex]:
        def traverseQS(qsNode, parentRO):
            ro = { 'uuid': qsNode['uuid'], }
            if 'question' in qsNode:
                qr = findQuestionRow(qsNode['number'], ws)
                ro['weight'] = ws.cell(qr, rp['weightCol']).value
            else:
                ro['children'] = []

            parentRO['children'].append(ro)
            for child in qsNode['children'] if 'children' in qsNode else []:
                traverseQS(child, ro)

        resultProfile = {
            'title': ws.cell(rp['titleRow']-1, rp['weightCol']).value,
            'uuid': str(uuid.uuid4()),
            'children': [],
        }
        traverseQS(module, resultProfile)
        resultProfiles.append(resultProfile)

ramlProfile['root']['resultProfiles'] = resultProfiles

with open(debugModulesJSON, 'w') as fp:
    fp.write(json.dumps(ramlProfile, indent=2))

xml = lxml.etree.XML(dict2xml.dict2xml(ramlProfile))
with open(debugOutXML, 'w') as fp:
    fp.write(lxml.etree.tostring(xml, pretty_print=True, xml_declaration=True))
with open(inXSLT) as fp:
    xslt = lxml.etree.XSLT(lxml.etree.parse(fp))
with open(outXML, 'w') as fp:
    fp.write(lxml.etree.tostring(xslt(xml),
        pretty_print=True,
        xml_declaration=True))
with zipfile.ZipFile(ramlOut, 'w') as fp:
    fp.write(outXML, 'model.xml')
    fp.write(graphbg, 'media/' + graphbg)
