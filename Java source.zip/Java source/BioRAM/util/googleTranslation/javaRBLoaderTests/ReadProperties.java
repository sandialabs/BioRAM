import java.util.Enumeration;
import java.util.Locale;
import java.util.ResourceBundle;

public class ReadProperties {
  static public void main(String[] args) throws Exception {
    for (String arg : args) {
      Locale.setDefault(new Locale(arg));
      ResourceBundle rb = ResourceBundle.getBundle("FormStrings");

      Enumeration<String> e = rb.getKeys();
      while (e.hasMoreElements()) {
        String key = e.nextElement();
        System.out.format("%s = \"%s\"\n", key, rb.getString(key));
      }
    }
  }
  
  public void readProperties() {
  }

}
