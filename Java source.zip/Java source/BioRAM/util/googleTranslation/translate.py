#!/usr/bin/python

import urllib
import urllib2
import json
import time
import random
import logging
import re

def translateViaGoogle(strToTranslate, langTo, langFrom="en", shouldSleepFirst=True):
    """
    This acts like a function call that internally queries Google Translate to 
    perform the actual translation service.  It sets the User-Agent to something
    low-key.
    
    NOTE: Google is very sensitive to bots.  You should always sleep first unless you're
    only doing a query or two 
    """
    args = {'client': 't',
            'text': strToTranslate,
            'hl': langFrom,
            'sl': langFrom,
            'tl': langTo,
            'ie': 'UTF-8',
            'oe': 'UTF-8',
            'multires': 1,
            'prev': 'btn',
            'ssel': 4,
            'tsel': 4,
            'sc': 1}
    baseURL = "http://translate.google.com/translate_a/t?" 
    req = urllib2.Request(baseURL + urllib.urlencode(args).replace('+','%20'))
    # Google blocks the request if they don't think it's coming from a browser
    req.add_header('User-Agent', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/536.5 (KHTML, like Gecko) Chrome/19.0.1084.56 Safari/536.5')
    
    if shouldSleepFirst:
        time.sleep(random.uniform(0.8, 1.6)) # ...so Google doesn't block us
    urlObj = urllib2.urlopen(req)
    # What Google gives us is almost a valid json array, but needs one little tweak
    transList = json.loads(re.sub(r',(?=,)', r',null', urlObj.read()))
    
    translation = "".join(i[0] for i in transList[0])
    return translation

def translateJavaProperties(filenameIn, langTo, langFrom="en", logLevel=logging.INFO):
    """
    This translates a Java Properties file, assuming key/values are only on one line.
    It writes a file based on the input filename with _[langTo] appended, rather than
    returning a string, with the translated key/value pairs.  For example, a filenameIn
    of "FormProps.properties" to Arabic produces the file "FormProps_ar.properties"
    
    BUGS: Multi-line key/value pairs, which are legal in JProps 
    if their newlines are properly escaped, are not correctly parsed here.
    """
    logging.basicConfig(level=logLevel)
    
    translated = []
    with open(filenameIn) as fp:
        strIn = fp.read()
        
        matches = re.findall(r"^(.*?)\s*=\s*(.*)\s*$", strIn, re.MULTILINE)
        for prop in matches:
            logging.info("Translating (%s->%s): %s" % (langFrom, langTo, prop[1]))
            translated.append((prop[0], translateViaGoogle(prop[1], langTo, langFrom)))

    filenameOut=re.sub(r"(.*)\.(.*?)", r"\1_%s.\2" % langTo, filenameIn)
    with open(filenameOut, "w") as fp:
        for prop in translated:
            fp.write("%s=%s\n" % (prop[0], prop[1].encode('ascii', 'backslashreplace')))
    
    
#translateViaGoogle("This is a single string that I want to translate.", "ar")

for lang in ["ar", "de", "es", "fr", "it", "ja", "nl", "pt", "ru", "zh"]:
    translateJavaProperties("inputProperties/FormStrings.properties", lang)

# This changes '\xff' to '\u00ff'
import changeHexRefsToUnicode
