import re
import os

inputDir = 'inputProperties/'
for file in os.listdir(inputDir):
    with open(inputDir + file) as fp:
	replaced = re.sub(r'\\x', r'\\u00', fp.read())

    with open(inputDir + file, 'w') as fp:
	fp.write(replaced)
