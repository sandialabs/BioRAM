"""
This scans response XML nodes in a "From" file, notes its content, looks for 
the corresponding content in the "to" file (in a response node), then notes 
that node's UUID attribute.  A dictionary is created mapping the UUIDs of the 
questions in the two files.

This assumes that you've gone through and by-hand uniquely identified a 
question by providing a unique response.  Doing this in both files lets you 
match questions up by response, then create a mapping between their UUIDs with 
this routine.
"""

import lxml.etree
import json

fromFile = 'from_refResp.xml'
toFile = 'to_refResp.xml'

with open(fromFile) as fpFrom, open(toFile) as fpTo:
    xmlFrom = lxml.etree.XML(fpFrom.read())
    xmlTo = lxml.etree.XML(fpTo.read())

# Keys: from UUID, as a string
# Values: to UUID, as a string 
mapping = {}

for elemFrom in xmlFrom.xpath('//response'):
    elemToList = xmlTo.xpath('//response[.="%s"]' % elemFrom.text)

    assert len(elemToList) == 1  # Otherwise I made an error in the responses

    mapping[elemFrom.attrib['uuid']] = elemToList.pop().attrib['uuid']

dataFile = 'mappings.json'
with open(dataFile, 'w') as fp:
    json.dump(mapping, fp, indent=2)
