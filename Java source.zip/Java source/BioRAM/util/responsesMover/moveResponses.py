"""
This takes a JSON mappings file created by mapQuestions.py (UUIDfrom -> UUIDto) 
and changes the UUIDs in the responsesFilename accordingly, saving it to 
outFilename.
"""

import json
import lxml.etree

def moveResponses(jsonMappingsFilename, responsesFilename, outFilename):
    with open(jsonMappingsFilename) as fp:
	mappings = json.load(fp)

    with open(responsesFilename) as fp:
	respXML = lxml.etree.XML(fp.read())

    for respElem in respXML.xpath('//response[@uuid]'):
	try:
	  respElem.attrib['uuid'] = mappings[respElem.attrib['uuid']]
	except:
	  name = respElem.getparent().find('responseSetName').text
	  print('UUID in RS "%s" not in the mappings dictionary' % name)

    with open(outFilename, 'w') as fp:
	fp.write(lxml.etree.tostring(respXML, pretty_print=True))

moveResponses('mappings.json', 'from_dataResp.xml', 'to_dataResp.xml')
