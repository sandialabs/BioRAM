# On operation of moveQuestions

Fill in the input and template model in `moveQuestions.py` (follow the pattern 
of what's already in there).  Note that in the HTML questionnaire, the top row 
is culled --- it should contain column headings, not model data.

# Notes 9/30/13 4:31pm

French version of BioRAMLite's HTML (html v1) required many by-hand changes to 
correct MS Word's funky export tendencies.  ...mostly on question numbering --- 
it would place "(34" and ") ..." in different spans, for example, putting them 
on separate lines in the RAML

French Biosafety (html v1) required similar touch-up to remove apparent Martine 
edits.  The following Vim macro helped clear these up:

    /Martine^M?span^MF<v/datetime^Mf>xf<d2f>

French Biosecurity (html v1) also required touch-up.  To fix this, I searched 
for "\v\<\/span\>\<span lang\=FR" and deleted until the end of the span.
