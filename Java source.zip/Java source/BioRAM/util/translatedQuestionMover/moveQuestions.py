#!/usr/bin/python

from scrapy.selector import HtmlXPathSelector
from scrapy.http import HtmlResponse
from xml.sax.saxutils import escape
import lxml.etree
import shutil
import logging
import unittest
import itertools
import os
import os.path
import dict2xml
import zipfile
import uuid
import re

def convertHTMLToBioRAM(htmlModelFromMSWord,
        htmlMSWordFormatType,
        outputBioRAMFile = "bioRAMModel.raml",
        pyDictToBioRAMXSLT = "dictToBioRAM.xsl"):
    """
    This requires an MSWord-generated HTML document.  It looks for tables
    in this HTML document and assumes they're a BioRAM model (according to a 
    certain format for spacing).  The intent is to convert the Word model into 
    a BioRAM-comptatible model (outputBioRAMFile) that I can then go in
    and edit (rearrange categories) in the BioRAM software.
    
    No tree structure is copied from the HTML, as it is a flat, ambiguous 
    table.  The resulting model in BioRAM is thus a flat list of the 
    questions/categories in a single Module called "Facilities".

    There are two formats of input:
        Type 1 (original)
        Type 2 (v2, completely F'd MS Word table exports)
    """
    model = []

    enc = lambda x: escape(x)
    delEmpties = lambda xs: [x.strip() for x in xs if x.strip() != ""]
    with open(htmlModelFromMSWord) as fp:
        sel = HtmlXPathSelector(HtmlResponse(url="", body=fp.read()))

        if htmlMSWordFormatType == 1:
            for row in sel.select('//table//tr'):
                # MS Word added the \r\n breaks seemingly arbitrarily.  We only want 
                # line breaks on different span elements (hence the replacement)
                d = {}
                if len(row.select('td')) == 1:
                    d["category"] = enc("\n".join(re.sub("\r|\n", "", i) for i in row.select('td[@colspan="3"]//text()').extract()).strip())
                    logging.info("%s: t1 category %s" % (htmlModelFromMSWord, d["category"]))
                if len(row.select('td')) >= 3:
                    questionParts = delEmpties(row.select('td[1]//text()').extract())
                    d["question"] = enc("\n".join(re.sub("\r|\n", "", i) for i in questionParts).strip())
                    suggs = delEmpties(row.select('td[2]//text()').extract())
                    d["sugg"] = enc("\n".join(re.sub("\r|\n", "", i) for i in suggs).strip())
                    logging.info("%s: question %s" % (htmlModelFromMSWord, 
                        d["question"]))
                model.append(d)
        elif htmlMSWordFormatType == 2:
            # Create the list of questions/categories
            i = 0
            selList = sel.select('//table//tr')
            while i < len(selList):
                d = {}
                # Category row
                if selList[i].select('td[1][@colspan="2" or @colspan="3"]'):
                    d["category"] = enc("\n".join(re.sub("\r|\n", "", i) for i in selList[i].select('td[@colspan]//text()').extract()).strip())
                    logging.info("%s: t2 category %s" % (htmlModelFromMSWord, d["category"]))
                    i += 1
                # Question row with multiple rows
                elif selList[i].select('td[@rowspan]'):
                    numRows = int(selList[i].select('td/@rowspan')[0].extract())
                    d["question"] = enc("\n".join(re.sub("\r|\n", "", i) for i in selList[i].select('td[1]//text()').extract()).strip())
                    suggElems = selList[i].select('td[2]//text()').extract()
                    for k in xrange(1, numRows):
                        suggElems += selList[i+k].select('td[1]//text()').extract()
                    d["sugg"] = enc("\n".join(re.sub("\r|\n", "", i) for i in suggElems).strip())
                    d["sugg"] = re.sub('\n *\n *\n', '\n\n', d["sugg"])
                    i += numRows
                    logging.info("%s: t2 question_2 %s" % (htmlModelFromMSWord, d["question"]))
                # Old-style question row
                elif len(selList[i].select('td')) == 3:
                    d["question"] = enc("\n".join(re.sub("\r|\n", "", i) for i in selList[i].select('td[1]//text()').extract()).strip())
                    d["sugg"] = enc("\n".join(re.sub("\r|\n", "", i) for i in selList[i].select('td[2]//text()').extract()).strip())
                    logging.info("%s: t2 question_1 %s" % (htmlModelFromMSWord, d["question"]))
                    i += 1
                else:
                    logging.warning("%s: row %d unrecognized" % (htmlModelFromMSWord, i))
                    i += 1
                model.append(d)


    xmlStr = "<root>%s</root>" % dict2xml.dict2xml(model, indent='')
    
    xsltTransform = lxml.etree.XSLT(lxml.etree.parse(pyDictToBioRAMXSLT))
    bioRAMTree = xsltTransform(lxml.etree.XML(xmlStr))
    
    # Since little old XSLT 1.0 can't add the UUIDs, I'll have to do it here
    for uuidElem in bioRAMTree.xpath("//uuid"):
        uuidElem.text = str(uuid.uuid4())

    # The first row is just a header, but gets interpreted as a Question - remove it
    headerQuestion = bioRAMTree.xpath('//QuestionSetQuestion[1]').pop()
    headerQuestion.getparent().remove(headerQuestion)
    
    bioRAMXMLStr = lxml.etree.tostring(bioRAMTree.getroot(), pretty_print=True)
    # print(bioRAMXMLStr) # ...just so we know something's happening
    with zipfile.ZipFile(outputBioRAMFile, "w") as fp:
        fp.writestr("model.xml", bioRAMXMLStr)


def moveQuestionsBetweenModels(fromModelFilename, toModelFilename, outFilename):
    """
    :param fromModelFilename: The raml file to take question/category text from.  This will
    be the translated model
    
    :param toModelFilename: The raml file to insert question/category text into.  This will be
    a completed model.
    
    :param outFileName: The raml file to create with the first two models merged.
    
    When this HTML file is converted, it creates a flat list of questions/categories.  If
    you already have a model that's been tied to the math/etc and want these questions over
    there, this function assumes they're in the same order and goes through the questions
    in fromModelFilename from top to bottom and tries to match them to the corersponding
    question in toModelFilename
    
    NOTE: This effort has been abandoned!
    """
    with zipfile.ZipFile(fromModelFilename) as fpFrom, zipfile.ZipFile(toModelFilename) as fpTo:
        logging.basicConfig(level=logging.INFO)
        xmlFrom = lxml.etree.XML(fpFrom.read("model.xml"))
        xmlTo = lxml.etree.XML(fpTo.read("model.xml"))
        
        listFrom = xmlFrom.xpath("//QuestionSetRoot/Children//*[uuid]")
        listTo = xmlTo.xpath("//QuestionSetRoot/Children//*[uuid]")
        
        #for i, elFrom in enumerate(listFrom):
            
        for i, elFrom, elTo in zip(itertools.count(), listFrom, listTo):
            if elFrom.tag == elTo.tag:
                # print('%3d: (%s -> %s) Overwriting "%s"' % (i, elFrom.tag, elTo.tag, elTo.xpath("title")[0].text))
                elTo.xpath("title")[0].text = elFrom.xpath("title")[0].text
                if elFrom.tag == "QuestionSetQuestion":
                    elTo.xpath("detailText")[0].text = elFrom.xpath("detailText")[0].text
            else:
                logging.warning('%3d: ("%s"->"%s") element name mismatch' % (i, elFrom.tag, elTo.tag))

        shutil.copy(toModelFilename, outFilename)
        with zipfile.ZipFile(outFilename, "a") as fpOut:
            fpOut.writestr("model.xml", lxml.etree.tostring(xmlTo, pretty_print=True))


def moveHTMLQuestionsIntoTemplateRAMModel(htmlInput, modelTemplate, htmlType):
    """
    Writes the resulting merged file in a directory output/[modelname].raml
    
    Moves questions from the HTML file into a flat RAML file, then 
    copies them over to the template file in order.  It's assumed that
    the HTML input and RAML template file's questions and categories are
    in the exact same order, as direct matching based on order is all this
    function does.
    """
    output = os.path.join('ramlOutput', os.path.splitext(os.path.split(htmlInput)[-1])[0]) + ".raml"
    flatRAML = "flat.raml"
    convertHTMLToBioRAM(htmlInput, htmlType, flatRAML)
    moveQuestionsBetweenModels(flatRAML, modelTemplate, output)
    os.remove(flatRAML) # This was just an intermediate file


filesToConvert = [
    { 'htmlInput': 'htmlInput/BiosafetyRAM_ar.htm',
      'modelTemplate': 'modelTemplates/Biosafety.raml',
      'version': 1,
    },
    { 'htmlInput': 'htmlInput/BiosecurityRAM_ar.htm',
      'modelTemplate': 'modelTemplates/Biosecurity.raml',
      'version': 1,
    },

    { 'htmlInput': 'htmlInput/BioRAMLite_es.htm',
      'modelTemplate': 'modelTemplates/BioRAMLite.raml',
      'version': 1,
    },
    { 'htmlInput': 'htmlInput/BiosafetyRAM_es.htm',
      'modelTemplate': 'modelTemplates/Biosafety.raml',
      'version': 1,
    },
    { 'htmlInput': 'htmlInput/BiosecurityRAM_es.htm',
      'modelTemplate': 'modelTemplates/Biosecurity.raml',
      'version': 1,
    },

    { 'htmlInput': 'htmlInput/BiosecurityRAM_v2_en.htm',
      'modelTemplate': 'modelTemplates/Biosecurity.raml',
      'version': 2,
    },
    { 'htmlInput': 'htmlInput/BiosecurityRAM_v2_ru.htm',
      'modelTemplate': 'modelTemplates/Biosecurity.raml',
      'version': 2,
    },
    { 'htmlInput': 'htmlInput/BiosecurityRAM_v2_id.htm',
      'modelTemplate': 'modelTemplates/Biosecurity.raml',
      'version': 2,
    },
    { 'htmlInput': 'htmlInput/BiosafetyRAM_v2_ru.htm',
      'modelTemplate': 'modelTemplates/Biosafety.raml',
      'version': 2,
    },
    { 'htmlInput': 'htmlInput/BiosafetyRAM_v2_id.htm',
      'modelTemplate': 'modelTemplates/Biosafety.raml',
      'version': 2,
    },
];
frenchFiles = [
#     { 'htmlInput': 'htmlInput/BioRAMLite_fr.htm',
#       'modelTemplate': 'modelTemplates/BioRAMLite.raml',
#       'version': 1,
#     },
#     { 'htmlInput': 'htmlInput/BiosafetyRAM_fr.htm',
#       'modelTemplate': 'modelTemplates/Biosafety.raml',
#       'version': 1,
#     },
    { 'htmlInput': 'htmlInput/BiosecurityRAM_fr.htm',
      'modelTemplate': 'modelTemplates/Biosecurity.raml',
      'version': 1,
    },
];

logging.basicConfig(level=logging.WARNING)
for d in frenchFiles:
    # mCC = re.search(r'_(..)\.htm(l)?$', d['htmlInput'])
    # assert mCC
    moveHTMLQuestionsIntoTemplateRAMModel(
            d['htmlInput'],
            d['modelTemplate'],
            d['version'])


class test_conversion(unittest.TestCase):
    
    def testMovingUUIDs(self):
#        moveQuestionsBetweenModels("bioRAMModel.raml", "referenceModel.raml")
        moveQuestionsBetweenModels("bioRAMLiteTranslatedQuestions.raml", "bioRAMLite.raml", "bioRAMLiteArabic.raml")
            
    def test_convertHTML(self):
        pass
#        convertHTMLToBioRAM("BRArabicFiltered.htm", "bioRAMModel.raml")
#        convertHTMLToBioRAM("bioRAMLiteUntranslated.htm", "bioRAMLiteUntranslated.raml")
        
#        self.assertTrue(os.path.exists(outputFile), "Output file wasn't created")
#        with zipfile.ZipFile(outputFile, "r") as fp:
#            self.assertTrue("model.xml" in fp.namelist())
