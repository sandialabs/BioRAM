import zipfile
import re
import argparse
import uuid
import lxml.etree
from copy import deepcopy

# Configure program arguments
parser = argparse.ArgumentParser(description="Converts a *.ram file to a *.raml file using a reference XML file with blank nodes in it.  Preserves hierarchy.")
parser.add_argument('netFile',
    help='*.ram file to convert')
parser.add_argument('-o', '--out', default='converted.raml',
    help='The .raml filename to create')
parser.add_argument('-r', '--refModel', default='refModel2.xml',
    help='The reference RAML model.xml file to use')
args = parser.parse_args()

def getSortedListOfNETREMatches(mapsDict, netText):
    """
    Return the .NET items as RE matches (defined in mapsDict elements) in
    order of their definition in the .ram file
    """
    netItems = []
    for d in mapsDict.itervalues():
       netItems += list(re.finditer(d['regex'], netText))

    # Sort the .NET RE matches by where they appear in the file
    return sorted(netItems, lambda m1,m2: cmp(m1.start(), m2.start()))

def getListOfXMLTemplatesMirroringNETItems(mapsDict, netItems):
    """
    Create the ramlItems to mirror netItems as XML nodes.  This relies on
    a convention of the "regex" match group 1 indexing the .NET node name.

    This uses the mapsDict to get the XML templates for a particular NET
    file (RE match) element type
    """
    ramlItems = []
    for m in netItems:
        d = mapsDict[m.group(1)]
        template = deepcopy(d['refXMLNode'](m))
        # Now instantiate the template (replace relevant values)
        for xmlChild, iRE in d['elementMap'].iteritems():
            # print ("%s (%s) %d" % (m.group(1), xmlChild, iRE))
            template.find(xmlChild).text = unicode(m.group(iRE))
        # Perform post-processing (like UUID generation)
        if d.has_key('postProcFunc'):
            d['postProcFunc'](m, template)
        ramlItems.append(template)
    return ramlItems

def separateResultProfilesFromFlatRAMLList(ramlItems, netItems):
    """
    Returns a list dictionaries each containing a list of ramlItems in the RP
    and a list of equivalent NET match objects for that RP.
    
    Also partially sets up
    the XML hierarchy by assigning ResultTitles in the ResultProfile's 
    RT tag.  This is implicitly defined - there are no child indices in the
    ResultProfile object specifying its children.

    Returns a list of dictionaries representing a single RP with the elements
    "ramlItems", "netItems", and "rpXML" (containing the base XML node)
    """
    assert len(ramlItems) == len(netItems) # These lists should be analogues

    resultProfiles = []
    for i in xrange(len(ramlItems)):
        if ramlItems[i].tag == 'ResultProfile':
            # Look for the closest ResultTitle and assign it to this RP
            for iTitle in xrange(i, len(ramlItems)):
                if ramlItems[iTitle].tag == 'ResultTitle':
                    ramlItems[i].append(ramlItems[iTitle])
                    break;

            # Get the items in the list
            resultProfiles.append({
                'ramlItems': [],
                'netItems': [],
                'rpXML': ramlItems[i]
            })
            for iRP in xrange(i+1, len(ramlItems)):
                if ramlItems[iRP].tag == 'ResultProfile':
                    break;
                resultProfiles[-1]['ramlItems'].append(ramlItems[iRP])
                resultProfiles[-1]['netItems'].append(netItems[iRP])
    return resultProfiles

def replaceiMLRefsWithUUIDRefs(xmlQS, xmlRP):
    """
    For result objects, the call to getListOfXMLTemplatesMirroringNETItems
    only puts the iML into the categoryUUID or questionUUID spots in
    the RAML templates, so that must be replaced with the equivalent iML's
    UUID (a fundamental difference in the Java version vs .NET version)
    """
    for xmlRO in xmlRP:
        for uuidReferencingElemNames in ['categoryUUID', 'questionUUID']:
            for iElem in xmlRO.findall(uuidReferencingElemNames):
                iML = int(iElem.text)
                iElem.text = xmlQS[iML].find('uuid').text
                print("%s, %d, %s" % (xmlRO.tag, iML, iElem.text))


def assignHierarchyToXMLItemsFromNETMatches(mapsDict, netItems, ramlItems):
    """
    Set up the hierarchy within the XML items.  Relies on convention of the
    RAML elements havin a "Children" XML node for this.  Returns the top-level
    elements in a list.

    Uses the mapsDict to get the childIndices index to index the match objects

    Uses netItems to index mapsDict to get the correct dictionary to get the
    child indices index to the RE object (the other use of netItems)
    """
    assert len(netItems) == len(ramlItems)

    for m, ramlElem in zip(netItems, ramlItems):
        d = mapsDict[m.group(1)]
        if d.has_key('childIndicesiRE') and ramlElem.find('Children') is not None:
            for i in m.group(d['childIndicesiRE']).strip().split(' '):
                if len(i) > 0:
                    # print("%s, %s, %s" % (m.group(1), len(ramlItems), i))
                    ramlElem.find('Children').append(ramlItems[int(i)])

    topLevelElems = []
    # Now find the root elem with this extremely inefficient n^2 algorithm
    for elem in ramlItems:
        doIHaveAParent = False;
        for parent in ramlItems:
            for child in parent.xpath('Children/*'):
                if id(child) == id(elem):
                    doIHaveAParent = True
        if doIHaveAParent == False:
            topLevelElems.append(elem)

    return topLevelElems

with open(args.refModel) as fpRAMRef, open(args.netFile) as fpNET:
    # Loads a template file, makes copies of the nodes, and edits them
    rRAMLRef = lxml.etree.XML(fpRAMRef.read()) # Root
    netText = re.sub(r'\r', '', fpNET.read())

def generateUUIDForXMLElement(m, x):
    x.find('uuid').text = str(uuid.uuid4())
    print("%s, %s, %s" % (m.group(1), x.tag, x.find('uuid').text))

# Specifies the XML element -> regex group mapping
qsNETtoXMLMappings = {
    'ListQuestion': {
        'refXMLNode': lambda m: rRAMLRef.xpath('//QuestionSetQuestion').pop(),
        'elementMap': {
            'uuid': 2,
            'detailText': 3,
            'title': 4,
            'defaultWeight': 5,
        },
        'regex': """(ListQuestion)
(.*)
((?:\n|.)*?)
>>End Response Suggestions<<
(.*)
(.*)""",
    },
    'ListCategory': {
        'refXMLNode': lambda m: rRAMLRef.xpath('//QuestionSetCategory').pop(),
        'childIndicesiRE': 4,
        'elementMap': {
            'title': 2,
            'defaultWeight': 3,
        },
        'postProcFunc': generateUUIDForXMLElement,
        'regex': """(ListCategory)
(.*)
(.*)
(.*)""",
    }
}

#def getMathOpXMLTemplateFromMatchObject(m):
#    types = {
#        'Add': '//ResultMathOpAdd',
#        'Subtract': '//ResultMathOpSubtract',
#        'Multiply': '//ResultMathOpMultiply',
#        'Divide': '//ResultMathOpDivide',
#        'Constant': '//ResultMathOpConstant',
#        'Exponent': '//ResultMathOpExponent',
#        'Min': '//ResultMathOpMin',
#        'Max': '//ResultMathOpMax',
#    }
#    for k in types.keys():
#        if m.group(2) == k:
#            return rRAMLRef.xpath(types[k]).pop()
def getMathOpXMLTemplateFromMatchObject(m):
    if m.group(2) == 'Add':
        return rRAMLRef.xpath('//ResultMathOpAdd').pop()
    if m.group(2) == 'Subtract':
        return rRAMLRef.xpath('//ResultMathOpSubtract').pop()
    if m.group(2) == 'Multiply':
        return rRAMLRef.xpath('//ResultMathOpMultiply').pop()
    if m.group(2) == 'Divide':
        return rRAMLRef.xpath('//ResultMathOpDivide').pop()
    if m.group(2) == 'Max':
        return rRAMLRef.xpath('//ResultMathOpMax').pop()
    if m.group(2) == 'Min':
        return rRAMLRef.xpath('//ResultMathOpMin').pop()
    if m.group(2) == 'Constant':
        return rRAMLRef.xpath('//ResultMathOpConstant').pop()
    if m.group(2) == 'Exponent':
        return rRAMLRef.xpath('//ResultMathOpExponent').pop()

def performSpecificMathOpMappings(m, x):
    """
    m: The match object for the current .NET-parsed item
    x: The RAML XML template corresponding to the current match
    """
    if m.group(2) == 'Exponent':
        x.find('exponent').text = m.group(6)
    elif m.group(2) == 'Constant':
        x.find('constant').text = m.group(6)

    if m.group(2) != 'Constant':
        x.find('normalizeChildren').text = m.group(9)


# NOTE!  ResultObjects require post-processing with the QuestionSet's list
# to turn their iMLs into UUIDs from the QuestionSet* list indices!
rpNETtoXMLMappings = {
    'ResultProfile': {
        'refXMLNode': lambda m: rRAMLRef.xpath('//ResultProfile').pop(),
        'elementMap': {},
        'postProcFunc': generateUUIDForXMLElement,
        'regex': """(ResultProfile)
(.*)""",
    },
    'ResultTitle': {
        'refXMLNode': lambda m: rRAMLRef.xpath('//ResultTitle').pop(),
        'childIndicesiRE': 6,
        'elementMap': {
            'title': 2,
            'rawWeight': 4,
            'normalizeChildren': 5,
        },
        'regex': """(ResultTitle)
(.*)
(.*)
(.*)
(.*)
(.*)""",
    },
    'ResultCategory': {
        'refXMLNode': lambda m: rRAMLRef.xpath('//ResultCategory').pop(),
        'childIndicesiRE': 5,
        'elementMap': {
            'categoryUUID': 2,
            'rawWeight': 3,
            'normalizeChildren': 4,
        },
        'regex': """(ResultCategory)
(.*)
(.*)
(.*)
(.*)""",
    },
    'ResultQuestion': {
        'refXMLNode': lambda m: rRAMLRef.xpath('//ResultQuestion').pop(),
        'elementMap': {
            'questionUUID': 2,
            'rawWeight': 3,
        },
        'regex': """(ResultQuestion)
(.*)
(.*)
(.*)
(.*)""",
    },
    'ResultMathOp': {
        'refXMLNode': getMathOpXMLTemplateFromMatchObject,
        'childIndicesiRE': 10,
        'elementMap': {
            'title': 3,
            'rawWeight': 8,
        },
        'postProcFunc': performSpecificMathOpMappings,
        'regex': """(ResultMathOp)
(.*)
(.*)
(.*)
(.*)
(.*)
(.*)
(.*)
(.*)
(.*)""",
    },
    'ResultReference': {
        'refXMLNode': lambda m: rRAMLRef.xpath('//ResultMathOpAdd').pop(),
        'childIndicesiRE': 7,
        'elementMap': {
            'title': 3,
            'rawWeight': 5,
            'normalizeChildren': 6
        },
        'regex': """(ResultReference)
(.*)
(.*)
(.*)
(.*)
(.*)
(.*)""",
    },
}

def getTopLevelQSOs(mapsDict, netText):
    netItems = getSortedListOfNETREMatches(mapsDict, netText)
    xmlQSItems = getListOfXMLTemplatesMirroringNETItems(mapsDict, netItems)

    topLevelItems = assignHierarchyToXMLItemsFromNETMatches(
        mapsDict, netItems, xmlQSItems)
    return { 'topLevelItems': topLevelItems,
	     'flatML': xmlQSItems }

def getResultProfiles(MLXML, rpMapsDict, netText):
    netRPItems = getSortedListOfNETREMatches(rpMapsDict, netText)
    xmlRPItems = getListOfXMLTemplatesMirroringNETItems(rpMapsDict, netRPItems)

    replaceiMLRefsWithUUIDRefs(MLXML, xmlRPItems)

    rpLists = separateResultProfilesFromFlatRAMLList(xmlRPItems, netRPItems)
    for d in rpLists:
        assignHierarchyToXMLItemsFromNETMatches(
            rpMapsDict, d['netItems'], d['ramlItems'])
    return rpLists

# Insert the items into the pseudo-template and remove dummy elements
qsDict = getTopLevelQSOs(qsNETtoXMLMappings, netText)
xmlQSTopLevel = qsDict['topLevelItems']
rpLists = getResultProfiles(qsDict['flatML'], rpNETtoXMLMappings, netText)

dummyElements = rRAMLRef.xpath('//ExtraElements').pop()
dummyElements.getparent().remove(dummyElements)

questionModuleChildren = rRAMLRef.xpath('//QuestionSetRoot/Children').pop()
# Create a new UUID (since there's no analogue in the NET version for a QS root)
rRAMLRef.xpath('//QuestionSetRoot/uuid').pop().text = str(uuid.uuid4())
for elem in xmlQSTopLevel:
    questionModuleChildren.append(elem)

# Insert the Result Profiles into the main XML tree
modelRoot = rRAMLRef.xpath('//RamModel').pop()
for dRPs in rpLists:
    modelRoot.append(dRPs['rpXML'])

    with open("testing.xml", "a") as fp:
        fp.write(lxml.etree.tostring(dRPs['rpXML']))


ramlXMLStr = lxml.etree.tostring(rRAMLRef, pretty_print=True)
# print(ramlXMLStr) # ...just so we know something's happening

with zipfile.ZipFile(args.out, "w") as fp:
    fp.writestr("model.xml", ramlXMLStr)
